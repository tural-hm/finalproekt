﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MagazaProqramiDEA
{
    public partial class YeniMal : Form
    {//hazir 

        public static string kt = "";
        public static bool redakteOlunur=false;
        public static string ad = ""; 
        public static string bk = "";

        public static long plukodu = 0;
        public static string code = "";
        public static string kodsuzMalinBK;

        public YeniMal( )
        {
            InitializeComponent();

            
        }
        
        //hazir 
        public YeniMal(string ad, string bk, double md, double sq,double sqtek,int qutusayi,int plukodu)
        {
            InitializeComponent();
            redakteOlunur = true; 
            tesdiqle_button1.Enabled = false;
            malin_adi_textBox1.Text = ad;
            YeniMal.ad = ad;
            YeniMal.bk = bk;
            malin_bar_kodu_textBox1.Text = bk;
            malin_bar_kodu_textBox1.ReadOnly = true;
            malin_adi_textBox1.ReadOnly = true;
  
            maya_deyeri_textBox1.ReadOnly = true;
            malin_faizi_textBox1.ReadOnly = true;
            satis_qiymeti_textBox1.ReadOnly = true;



            maya_deyeri_textBox1.Text = "" + md;
            satis_qiymeti_textBox1.Text = "" + sq;
            tek_sayi_textBox1.Text = "" + qutusayi;
            tek_satis_qiymeti_textBox1.Text = "" + sqtek;
            plu_kodu_textBox1.Text = "" + plukodu;
        }

        //hazir 
        public YeniMal(string ad, string bk, double md, double sq)
        {
            InitializeComponent();
            redakteOlunur = false;
            yadda_saxla_button2.Enabled = false;
            malin_adi_textBox1.Text = ad;
            malin_bar_kodu_textBox1.Text = bk;
            maya_deyeri_textBox1.Text = "" + md;
            satis_qiymeti_textBox1.Text = "" + sq;
            plu_kodu_textBox1.Text = "" + plukodu;
            if(Baza.yeni_malin_mal_tipi_qlobal==10){
                malin_bar_kodu_textBox1.Text = code;
                malin_bar_kodu_textBox1.ReadOnly = true;
            }
            else if (Baza.yeni_malin_mal_tipi_qlobal == 11)
            {
                malin_bar_kodu_textBox1.Text = kodsuzMalinBK.PadLeft(13, '0');
                malin_bar_kodu_textBox1.ReadOnly = true;
            }
        }




        //hazir 
        private void YeniMal_Load(object sender, EventArgs e)
        {
            if (redakteOlunur)
            {
                status_label2.Text = "\"" + ad + "\" REDAKTƏ EDİLMƏSİ";
            }
            else
            {
 status_label2.Text = "\"" + kt + "\" MALLARINA YENİ MALIN DAXİL EDİLMƏSİ";
            }
           
        }
        //hazir 
        private void tesdiqle_button1_Click(object sender, EventArgs e)
        {

            malinMelumatlariniTesdiqleYaddaSaxla();




        }
        //hazir 
        private void malinMelumatlariniTesdiqleYaddaSaxla()
        {

            string ad = "";
            string bk = "";
            string md = "";
            string sq = "";
            string sqtek = "";
            string qutusayi = "";




            ad = malin_adi_textBox1.Text.Trim();

            if (ad.Equals(""))
            {
                Baza.msg("Malın adı boş ola bilməz", Baza.adminAdi);


            }
            else
            {



                bk = malin_bar_kodu_textBox1.Text.Trim();
                if (bk.Equals(""))
                {
                    Baza.msg("Malın bar kodu boş ola bilməz", Baza.adminAdi);


                }
                else
                {
                    bool bu_bk_varmi = Baza.cedvelde_serti_odeyen_setir_sayi("mallar", "where bk='" + bk + "'") == 1;

                    if (redakteOlunur) { bu_bk_varmi = false; }

                    if (bu_bk_varmi)
                    {
                        Baza.msg("Bu bar kod bazada var", Baza.adminAdi);

                    }
                    else
                    {
                        md = maya_deyeri_textBox1.Text.Trim();
                        if (md.Equals(""))
                        {
                            Baza.msg("Malın maya dəyəri boş ola bilməz", Baza.adminAdi);


                        }
                        else
                        {
                            sq = satis_qiymeti_textBox1.Text.Trim();
                            if (sq.Equals(""))
                            {
                                Baza.msg("Malın satış qiyməti boş ola bilməz", Baza.adminAdi);


                            }
                            else
                            {
                                if (Baza.yeni_malin_tipi_qlobal == 4)
                                {
                                    sqtek = tek_satis_qiymeti_textBox1.Text.Trim();

                                    if (sqtek.Equals(""))
                                    {
                                        Baza.msg("Malın tək satış qiyməti boş ola bilməz", Baza.adminAdi);


                                    }
                                    else
                                    {
                                        qutusayi = tek_sayi_textBox1.Text.Trim();
                                        if (qutusayi.Equals(""))
                                        {
                                            Baza.msg("Malın tək sayı boş ola bilməz", Baza.adminAdi);


                                        }
                                        else
                                        {
                                            int plu = 0;

                                            if (redakteOlunur)
                                            {
                                                Baza.iud("update mallar set ad='" + ad + "',md='" + md + "',sq='" + sq + "',sqtek='" + sqtek + "',qutusayi=" + qutusayi + " where bk='" + bk + "'");
                                                Baza.msg("Mal redaktə edildi");

                                            }
                                            else
                                            {
                                                bool ugurlu = Baza.yeni_mali_qeydiyyat_et(ad, bk, Convert.ToDouble(md), Convert.ToDouble(sq), Convert.ToDouble(sqtek), Convert.ToInt32(qutusayi), Baza.yeni_malin_tipi_qlobal, Baza.yeni_malin_mal_tipi_qlobal, plu);
                                                if (ugurlu)
                                                {
                                                    Baza.msg("Yeni mal qeydiyyat edildi");
                                                    this.Dispose();
                                                }
                                                else
                                                {
                                                    Baza.msg("Yeni malın qeydiyyat edilməsində problem oldu");
                                                }
                                            }

                                        }



                                    }

                                }
                                else
                                {

                                    sqtek = "0"; qutusayi = "0";
                                    int plu = 0;

                                    if (Baza.yeni_malin_tipi_qlobal == 3)
                                    { plu = Convert.ToInt32(plu_kodu_textBox1.Text); }
                                    if (redakteOlunur) {
                                        Baza.iud("update mallar set ad='" + ad + "',md='" + md + "',sq='" + sq + "',sqtek='" + sqtek + "',qutusayi=" + qutusayi + " where bk='"+bk+"'");
                                        Baza.msg("Mal redaktə edildi");
                                    
                                    }
                                    else
                                    {
                                        bool ugurlu = Baza.yeni_mali_qeydiyyat_et(ad, bk, Convert.ToDouble(md), Convert.ToDouble(sq), Convert.ToDouble(sqtek), Convert.ToInt32(qutusayi), Baza.yeni_malin_tipi_qlobal, Baza.yeni_malin_mal_tipi_qlobal, plu);
                                        if (ugurlu)
                                        {
                                            Baza.msg("Yeni mal qeydiyyat edildi");
                                            this.Dispose();
                                        }
                                        else
                                        {
                                            Baza.msg("Yeni malın qeydiyyat edilməsində problem oldu");
                                        }
                                    }
                                }











                            }


                        }


                    }


                }




            }


        }
        // hazir 
        private void malin_adi_textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {

            Baza.adYazmagaIcaze(sender,e);


          
        }
        // hazir
        private void maya_deyeri_textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            Baza.doubleYazmagaIcaze(sender,e);
        }
        // hazir
        private void malin_faizi_textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            Baza.doubleYazmagaIcaze(sender, e);
        }
        // hazir
        private void satis_qiymeti_textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            Baza.doubleYazmagaIcaze(sender, e);
        }
        // hazir
        private void tek_satis_qiymeti_textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            Baza.doubleYazmagaIcaze(sender, e);
        }
        // hazir
        private void tek_sayi_textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            Baza.intYazmagaIcaze(sender, e);
        }
        // hazir
        private void malin_adi_textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                malin_bar_kodu_textBox1.Focus();

            }
        }
        // hazir
        private void malin_bar_kodu_textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                maya_deyeri_textBox1.Focus();

            }
        }
        // hazir
        private void maya_deyeri_textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                malin_faizi_textBox1.Focus();

            }
        }
        // hazir
        private void malin_faizi_textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                satis_qiymeti_textBox1.Focus();

            }
        }
        // hazir
        private void satis_qiymeti_textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                tek_satis_qiymeti_textBox1.Focus();

            }
        }
        // hazir
        private void tek_satis_qiymeti_textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                tek_sayi_textBox1.Focus();

            }
        }
        // hazir
        private void tek_sayi_textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                plu_kodu_textBox1.Focus();

            }
        }
        // hazir
        private void yadda_saxla_button2_Click(object sender, EventArgs e)
        {
            malinMelumatlariniTesdiqleYaddaSaxla();
        }
        //hazir 
        private void malin_faizi_textBox1_KeyUp(object sender, KeyEventArgs e)
        {
            string faizs = malin_faizi_textBox1.Text.Trim();
            if (faizs.Equals(""))
            {

            }
            else
            {
                string mds = maya_deyeri_textBox1.Text.Trim();
                if (mds.Equals(""))
                {

                }
                else
                {
                    double md = double.Parse(mds);
                    double faiz = double.Parse(faizs);

                    double sq = (md / 100.0) * (100 + faiz);
                    satis_qiymeti_textBox1.Text = "" + sq;



                }
              
            }
        }

       

    }
}
