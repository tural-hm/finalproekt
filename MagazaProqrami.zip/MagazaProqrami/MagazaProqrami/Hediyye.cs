﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MagazaProqramiDEA
{
    public partial class Hediyye : Form
    {//   //hazir 
        public string adSoyad;
        //hazir 
        public double bonus;
        //hazir 
        public string bk;

        //hazir 
        int hediyyeBali = 0;
        //hazir 
        public Hediyye()
        { 
            InitializeComponent(); 
        }


        //hazir 
        public   void hediyye_ad_basildi()
        {
            try
            {
                string hediyye_bali_string = hediyye_bali_text.Text;


                if (hediyye_bali_string.Equals("")) { Hide(); }
                else
                {



                    int hediyye_bali = Convert.ToInt32(hediyye_bali_text.Text);

                    if (hediyye_bali <= bonus && hediyye_bali > 0)
                    {
                        bonus -= hediyye_bali;
                        balans_label.Text = "" + Math.Round(bonus, 3);

                        hediyyeBali = hediyye_bali;

                        bool hediyye_verildi =  Baza.aliciya_hediyye_ver(hediyye_bali, bk);

                        if (hediyye_verildi)
                        {
                            MessageBox.Show("Təbrik edirik.\n \nSiz "+Baza.magazaAdi+" - dən \n" + hediyyeBali + " - Ballıq hədiyyə qazandınız.");
                            Hide();
                        }
                    }
                    else { MessageBox.Show("Çox məbləğ daxil edildi"); }




                }


            }
            catch { Baza.msg("Düzgün ədəd daxil edilməyib"); }


        }

        //hazir 
        private void Hediyye_Load(object sender, EventArgs e)
        {
            ad_soyad_label.Text = adSoyad;
            bonus = Math.Round(bonus, 3);
            balans_label.Text = "" + bonus;
        }
        //hazir 
        private void hediyye_bali_text_KeyDown(object sender, KeyEventArgs e)
        {

        }
        //hazir 
        private void hediyye_bali_text_KeyDown_1(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                hediyye_ad_basildi();
            }
        }
        //hazir 
        private void hediyye_al_button_Click(object sender, EventArgs e)
        {
         hediyye_ad_basildi();
        }
        //hazir 
        private void hediyye_bali_text_KeyPress(object sender, KeyPressEventArgs e)
        {
            Baza.intYazmagaIcaze(sender,e);
        }
    }
}
