﻿namespace MagazaProqramiDEA
{
    partial class YeniMal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(YeniMal));
            this.esas_tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.adlar_tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.tek_sayi_textBox1 = new System.Windows.Forms.TextBox();
            this.tek_satis_qiymeti_textBox1 = new System.Windows.Forms.TextBox();
            this.satis_qiymeti_textBox1 = new System.Windows.Forms.TextBox();
            this.malin_faizi_textBox1 = new System.Windows.Forms.TextBox();
            this.maya_deyeri_textBox1 = new System.Windows.Forms.TextBox();
            this.malin_bar_kodu_textBox1 = new System.Windows.Forms.TextBox();
            this.malin_adi_textBox1 = new System.Windows.Forms.TextBox();
            this.plu_kodu_textBox1 = new System.Windows.Forms.TextBox();
            this.yazilar_tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.tek_sayi_passiv_label13 = new System.Windows.Forms.Label();
            this.sq_tek_passiv_label11 = new System.Windows.Forms.Label();
            this.sq_passiv_label9 = new System.Windows.Forms.Label();
            this.faiz_passiv_label7 = new System.Windows.Forms.Label();
            this.md_passiv_label5 = new System.Windows.Forms.Label();
            this.bk_passiv_label3 = new System.Windows.Forms.Label();
            this.ad_passiv_label1 = new System.Windows.Forms.Label();
            this.plukodu_passiv_label2 = new System.Windows.Forms.Label();
            this.duymeler_tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.yadda_saxla_button2 = new System.Windows.Forms.Button();
            this.tesdiqle_button1 = new System.Windows.Forms.Button();
            this.status_label2 = new System.Windows.Forms.Label();
            this.esas_tableLayoutPanel1.SuspendLayout();
            this.adlar_tableLayoutPanel2.SuspendLayout();
            this.yazilar_tableLayoutPanel3.SuspendLayout();
            this.duymeler_tableLayoutPanel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // esas_tableLayoutPanel1
            // 
            this.esas_tableLayoutPanel1.ColumnCount = 2;
            this.esas_tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 300F));
            this.esas_tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.esas_tableLayoutPanel1.Controls.Add(this.adlar_tableLayoutPanel2, 0, 1);
            this.esas_tableLayoutPanel1.Controls.Add(this.yazilar_tableLayoutPanel3, 1, 1);
            this.esas_tableLayoutPanel1.Controls.Add(this.duymeler_tableLayoutPanel4, 0, 0);
            this.esas_tableLayoutPanel1.Controls.Add(this.status_label2, 1, 0);
            this.esas_tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.esas_tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.esas_tableLayoutPanel1.Name = "esas_tableLayoutPanel1";
            this.esas_tableLayoutPanel1.RowCount = 3;
            this.esas_tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.esas_tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 500F));
            this.esas_tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.esas_tableLayoutPanel1.Size = new System.Drawing.Size(1073, 642);
            this.esas_tableLayoutPanel1.TabIndex = 1;
            // 
            // adlar_tableLayoutPanel2
            // 
            this.adlar_tableLayoutPanel2.ColumnCount = 1;
            this.adlar_tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.adlar_tableLayoutPanel2.Controls.Add(this.tek_sayi_textBox1, 0, 6);
            this.adlar_tableLayoutPanel2.Controls.Add(this.tek_satis_qiymeti_textBox1, 0, 5);
            this.adlar_tableLayoutPanel2.Controls.Add(this.satis_qiymeti_textBox1, 0, 4);
            this.adlar_tableLayoutPanel2.Controls.Add(this.malin_faizi_textBox1, 0, 3);
            this.adlar_tableLayoutPanel2.Controls.Add(this.maya_deyeri_textBox1, 0, 2);
            this.adlar_tableLayoutPanel2.Controls.Add(this.malin_bar_kodu_textBox1, 0, 1);
            this.adlar_tableLayoutPanel2.Controls.Add(this.malin_adi_textBox1, 0, 0);
            this.adlar_tableLayoutPanel2.Controls.Add(this.plu_kodu_textBox1, 0, 7);
            this.adlar_tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.adlar_tableLayoutPanel2.Location = new System.Drawing.Point(3, 103);
            this.adlar_tableLayoutPanel2.Name = "adlar_tableLayoutPanel2";
            this.adlar_tableLayoutPanel2.RowCount = 13;
            this.adlar_tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.adlar_tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.adlar_tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.adlar_tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.adlar_tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.adlar_tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.adlar_tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.adlar_tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.adlar_tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.adlar_tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.adlar_tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.adlar_tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.adlar_tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.adlar_tableLayoutPanel2.Size = new System.Drawing.Size(294, 494);
            this.adlar_tableLayoutPanel2.TabIndex = 0;
            // 
            // tek_sayi_textBox1
            // 
            this.tek_sayi_textBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tek_sayi_textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tek_sayi_textBox1.Location = new System.Drawing.Point(3, 243);
            this.tek_sayi_textBox1.Name = "tek_sayi_textBox1";
            this.tek_sayi_textBox1.Size = new System.Drawing.Size(288, 26);
            this.tek_sayi_textBox1.TabIndex = 6;
            this.tek_sayi_textBox1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tek_sayi_textBox1_KeyDown);
            this.tek_sayi_textBox1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tek_sayi_textBox1_KeyPress);
            // 
            // tek_satis_qiymeti_textBox1
            // 
            this.tek_satis_qiymeti_textBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tek_satis_qiymeti_textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tek_satis_qiymeti_textBox1.Location = new System.Drawing.Point(3, 203);
            this.tek_satis_qiymeti_textBox1.Name = "tek_satis_qiymeti_textBox1";
            this.tek_satis_qiymeti_textBox1.Size = new System.Drawing.Size(288, 26);
            this.tek_satis_qiymeti_textBox1.TabIndex = 5;
            this.tek_satis_qiymeti_textBox1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tek_satis_qiymeti_textBox1_KeyDown);
            this.tek_satis_qiymeti_textBox1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tek_satis_qiymeti_textBox1_KeyPress);
            // 
            // satis_qiymeti_textBox1
            // 
            this.satis_qiymeti_textBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.satis_qiymeti_textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.satis_qiymeti_textBox1.Location = new System.Drawing.Point(3, 163);
            this.satis_qiymeti_textBox1.Name = "satis_qiymeti_textBox1";
            this.satis_qiymeti_textBox1.Size = new System.Drawing.Size(288, 26);
            this.satis_qiymeti_textBox1.TabIndex = 4;
            this.satis_qiymeti_textBox1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.satis_qiymeti_textBox1_KeyDown);
            this.satis_qiymeti_textBox1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.satis_qiymeti_textBox1_KeyPress);
            // 
            // malin_faizi_textBox1
            // 
            this.malin_faizi_textBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.malin_faizi_textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.malin_faizi_textBox1.Location = new System.Drawing.Point(3, 123);
            this.malin_faizi_textBox1.Name = "malin_faizi_textBox1";
            this.malin_faizi_textBox1.Size = new System.Drawing.Size(288, 26);
            this.malin_faizi_textBox1.TabIndex = 3;
            this.malin_faizi_textBox1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.malin_faizi_textBox1_KeyDown);
            this.malin_faizi_textBox1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.malin_faizi_textBox1_KeyPress);
            this.malin_faizi_textBox1.KeyUp += new System.Windows.Forms.KeyEventHandler(this.malin_faizi_textBox1_KeyUp);
            // 
            // maya_deyeri_textBox1
            // 
            this.maya_deyeri_textBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.maya_deyeri_textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maya_deyeri_textBox1.Location = new System.Drawing.Point(3, 83);
            this.maya_deyeri_textBox1.Name = "maya_deyeri_textBox1";
            this.maya_deyeri_textBox1.Size = new System.Drawing.Size(288, 26);
            this.maya_deyeri_textBox1.TabIndex = 2;
            this.maya_deyeri_textBox1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.maya_deyeri_textBox1_KeyDown);
            this.maya_deyeri_textBox1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.maya_deyeri_textBox1_KeyPress);
            // 
            // malin_bar_kodu_textBox1
            // 
            this.malin_bar_kodu_textBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.malin_bar_kodu_textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.malin_bar_kodu_textBox1.Location = new System.Drawing.Point(3, 43);
            this.malin_bar_kodu_textBox1.Name = "malin_bar_kodu_textBox1";
            this.malin_bar_kodu_textBox1.Size = new System.Drawing.Size(288, 26);
            this.malin_bar_kodu_textBox1.TabIndex = 1;
            this.malin_bar_kodu_textBox1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.malin_bar_kodu_textBox1_KeyDown);
            // 
            // malin_adi_textBox1
            // 
            this.malin_adi_textBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.malin_adi_textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.malin_adi_textBox1.Location = new System.Drawing.Point(3, 3);
            this.malin_adi_textBox1.Name = "malin_adi_textBox1";
            this.malin_adi_textBox1.Size = new System.Drawing.Size(288, 26);
            this.malin_adi_textBox1.TabIndex = 0;
            this.malin_adi_textBox1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.malin_adi_textBox1_KeyDown);
            this.malin_adi_textBox1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.malin_adi_textBox1_KeyPress);
            // 
            // plu_kodu_textBox1
            // 
            this.plu_kodu_textBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.plu_kodu_textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.plu_kodu_textBox1.Location = new System.Drawing.Point(3, 283);
            this.plu_kodu_textBox1.Name = "plu_kodu_textBox1";
            this.plu_kodu_textBox1.ReadOnly = true;
            this.plu_kodu_textBox1.Size = new System.Drawing.Size(288, 26);
            this.plu_kodu_textBox1.TabIndex = 7;
            // 
            // yazilar_tableLayoutPanel3
            // 
            this.yazilar_tableLayoutPanel3.ColumnCount = 2;
            this.yazilar_tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 200F));
            this.yazilar_tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.yazilar_tableLayoutPanel3.Controls.Add(this.tek_sayi_passiv_label13, 0, 6);
            this.yazilar_tableLayoutPanel3.Controls.Add(this.sq_tek_passiv_label11, 0, 5);
            this.yazilar_tableLayoutPanel3.Controls.Add(this.sq_passiv_label9, 0, 4);
            this.yazilar_tableLayoutPanel3.Controls.Add(this.faiz_passiv_label7, 0, 3);
            this.yazilar_tableLayoutPanel3.Controls.Add(this.md_passiv_label5, 0, 2);
            this.yazilar_tableLayoutPanel3.Controls.Add(this.bk_passiv_label3, 0, 1);
            this.yazilar_tableLayoutPanel3.Controls.Add(this.ad_passiv_label1, 0, 0);
            this.yazilar_tableLayoutPanel3.Controls.Add(this.plukodu_passiv_label2, 0, 7);
            this.yazilar_tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.yazilar_tableLayoutPanel3.Location = new System.Drawing.Point(303, 103);
            this.yazilar_tableLayoutPanel3.Name = "yazilar_tableLayoutPanel3";
            this.yazilar_tableLayoutPanel3.RowCount = 13;
            this.yazilar_tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.yazilar_tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.yazilar_tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.yazilar_tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.yazilar_tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.yazilar_tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.yazilar_tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.yazilar_tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.yazilar_tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.yazilar_tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.yazilar_tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.yazilar_tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.yazilar_tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.yazilar_tableLayoutPanel3.Size = new System.Drawing.Size(767, 494);
            this.yazilar_tableLayoutPanel3.TabIndex = 1;
            // 
            // tek_sayi_passiv_label13
            // 
            this.tek_sayi_passiv_label13.AutoSize = true;
            this.tek_sayi_passiv_label13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tek_sayi_passiv_label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tek_sayi_passiv_label13.Location = new System.Drawing.Point(3, 240);
            this.tek_sayi_passiv_label13.Name = "tek_sayi_passiv_label13";
            this.tek_sayi_passiv_label13.Size = new System.Drawing.Size(194, 40);
            this.tek_sayi_passiv_label13.TabIndex = 12;
            this.tek_sayi_passiv_label13.Text = "Tək-Sayı";
            this.tek_sayi_passiv_label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // sq_tek_passiv_label11
            // 
            this.sq_tek_passiv_label11.AutoSize = true;
            this.sq_tek_passiv_label11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sq_tek_passiv_label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sq_tek_passiv_label11.Location = new System.Drawing.Point(3, 200);
            this.sq_tek_passiv_label11.Name = "sq_tek_passiv_label11";
            this.sq_tek_passiv_label11.Size = new System.Drawing.Size(194, 40);
            this.sq_tek_passiv_label11.TabIndex = 10;
            this.sq_tek_passiv_label11.Text = "Tək-Satış qiyməti";
            this.sq_tek_passiv_label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // sq_passiv_label9
            // 
            this.sq_passiv_label9.AutoSize = true;
            this.sq_passiv_label9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sq_passiv_label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sq_passiv_label9.Location = new System.Drawing.Point(3, 160);
            this.sq_passiv_label9.Name = "sq_passiv_label9";
            this.sq_passiv_label9.Size = new System.Drawing.Size(194, 40);
            this.sq_passiv_label9.TabIndex = 8;
            this.sq_passiv_label9.Text = "Satış qiyməti";
            this.sq_passiv_label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // faiz_passiv_label7
            // 
            this.faiz_passiv_label7.AutoSize = true;
            this.faiz_passiv_label7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.faiz_passiv_label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.faiz_passiv_label7.Location = new System.Drawing.Point(3, 120);
            this.faiz_passiv_label7.Name = "faiz_passiv_label7";
            this.faiz_passiv_label7.Size = new System.Drawing.Size(194, 40);
            this.faiz_passiv_label7.TabIndex = 6;
            this.faiz_passiv_label7.Text = "Faiz (%)";
            this.faiz_passiv_label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // md_passiv_label5
            // 
            this.md_passiv_label5.AutoSize = true;
            this.md_passiv_label5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.md_passiv_label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.md_passiv_label5.Location = new System.Drawing.Point(3, 80);
            this.md_passiv_label5.Name = "md_passiv_label5";
            this.md_passiv_label5.Size = new System.Drawing.Size(194, 40);
            this.md_passiv_label5.TabIndex = 4;
            this.md_passiv_label5.Text = "Maya dəyəri";
            this.md_passiv_label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // bk_passiv_label3
            // 
            this.bk_passiv_label3.AutoSize = true;
            this.bk_passiv_label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bk_passiv_label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bk_passiv_label3.Location = new System.Drawing.Point(3, 40);
            this.bk_passiv_label3.Name = "bk_passiv_label3";
            this.bk_passiv_label3.Size = new System.Drawing.Size(194, 40);
            this.bk_passiv_label3.TabIndex = 2;
            this.bk_passiv_label3.Text = "Bar kodu";
            this.bk_passiv_label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ad_passiv_label1
            // 
            this.ad_passiv_label1.AutoSize = true;
            this.ad_passiv_label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ad_passiv_label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ad_passiv_label1.Location = new System.Drawing.Point(3, 0);
            this.ad_passiv_label1.Name = "ad_passiv_label1";
            this.ad_passiv_label1.Size = new System.Drawing.Size(194, 40);
            this.ad_passiv_label1.TabIndex = 0;
            this.ad_passiv_label1.Text = "Malın adı";
            this.ad_passiv_label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // plukodu_passiv_label2
            // 
            this.plukodu_passiv_label2.AutoSize = true;
            this.plukodu_passiv_label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.plukodu_passiv_label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.plukodu_passiv_label2.Location = new System.Drawing.Point(3, 280);
            this.plukodu_passiv_label2.Name = "plukodu_passiv_label2";
            this.plukodu_passiv_label2.Size = new System.Drawing.Size(194, 40);
            this.plukodu_passiv_label2.TabIndex = 13;
            this.plukodu_passiv_label2.Text = "Plu kodu";
            this.plukodu_passiv_label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // duymeler_tableLayoutPanel4
            // 
            this.duymeler_tableLayoutPanel4.ColumnCount = 1;
            this.duymeler_tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.duymeler_tableLayoutPanel4.Controls.Add(this.yadda_saxla_button2, 0, 1);
            this.duymeler_tableLayoutPanel4.Controls.Add(this.tesdiqle_button1, 0, 0);
            this.duymeler_tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.duymeler_tableLayoutPanel4.Location = new System.Drawing.Point(3, 3);
            this.duymeler_tableLayoutPanel4.Name = "duymeler_tableLayoutPanel4";
            this.duymeler_tableLayoutPanel4.RowCount = 2;
            this.duymeler_tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.duymeler_tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.duymeler_tableLayoutPanel4.Size = new System.Drawing.Size(294, 94);
            this.duymeler_tableLayoutPanel4.TabIndex = 2;
            // 
            // yadda_saxla_button2
            // 
            this.yadda_saxla_button2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.yadda_saxla_button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.yadda_saxla_button2.ForeColor = System.Drawing.Color.Red;
            this.yadda_saxla_button2.Location = new System.Drawing.Point(3, 50);
            this.yadda_saxla_button2.Name = "yadda_saxla_button2";
            this.yadda_saxla_button2.Size = new System.Drawing.Size(288, 41);
            this.yadda_saxla_button2.TabIndex = 1;
            this.yadda_saxla_button2.Text = "Yadda saxla";
            this.yadda_saxla_button2.UseVisualStyleBackColor = true;
            this.yadda_saxla_button2.Click += new System.EventHandler(this.yadda_saxla_button2_Click);
            // 
            // tesdiqle_button1
            // 
            this.tesdiqle_button1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tesdiqle_button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tesdiqle_button1.ForeColor = System.Drawing.Color.Red;
            this.tesdiqle_button1.Location = new System.Drawing.Point(3, 3);
            this.tesdiqle_button1.Name = "tesdiqle_button1";
            this.tesdiqle_button1.Size = new System.Drawing.Size(288, 41);
            this.tesdiqle_button1.TabIndex = 0;
            this.tesdiqle_button1.Text = "Təsdiqlə";
            this.tesdiqle_button1.UseVisualStyleBackColor = true;
            this.tesdiqle_button1.Click += new System.EventHandler(this.tesdiqle_button1_Click);
            // 
            // status_label2
            // 
            this.status_label2.AutoSize = true;
            this.status_label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.status_label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.status_label2.ForeColor = System.Drawing.Color.Red;
            this.status_label2.Location = new System.Drawing.Point(303, 0);
            this.status_label2.Name = "status_label2";
            this.status_label2.Size = new System.Drawing.Size(767, 100);
            this.status_label2.TabIndex = 3;
            this.status_label2.Text = "MALIN BÖLMƏSİ SEÇİLMƏYİB";
            this.status_label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // YeniMal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1073, 642);
            this.Controls.Add(this.esas_tableLayoutPanel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "YeniMal";
            this.Text = "Yeni Mal";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.YeniMal_Load);
            this.esas_tableLayoutPanel1.ResumeLayout(false);
            this.esas_tableLayoutPanel1.PerformLayout();
            this.adlar_tableLayoutPanel2.ResumeLayout(false);
            this.adlar_tableLayoutPanel2.PerformLayout();
            this.yazilar_tableLayoutPanel3.ResumeLayout(false);
            this.yazilar_tableLayoutPanel3.PerformLayout();
            this.duymeler_tableLayoutPanel4.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel esas_tableLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel adlar_tableLayoutPanel2;
        private System.Windows.Forms.TextBox tek_sayi_textBox1;
        private System.Windows.Forms.TextBox tek_satis_qiymeti_textBox1;
        private System.Windows.Forms.TextBox satis_qiymeti_textBox1;
        private System.Windows.Forms.TextBox malin_faizi_textBox1;
        private System.Windows.Forms.TextBox maya_deyeri_textBox1;
        private System.Windows.Forms.TextBox malin_bar_kodu_textBox1;
        private System.Windows.Forms.TextBox malin_adi_textBox1;
        private System.Windows.Forms.TextBox plu_kodu_textBox1;
        private System.Windows.Forms.TableLayoutPanel yazilar_tableLayoutPanel3;
        private System.Windows.Forms.Label tek_sayi_passiv_label13;
        private System.Windows.Forms.Label sq_tek_passiv_label11;
        private System.Windows.Forms.Label sq_passiv_label9;
        private System.Windows.Forms.Label faiz_passiv_label7;
        private System.Windows.Forms.Label md_passiv_label5;
        private System.Windows.Forms.Label bk_passiv_label3;
        private System.Windows.Forms.Label ad_passiv_label1;
        private System.Windows.Forms.Label plukodu_passiv_label2;
        private System.Windows.Forms.TableLayoutPanel duymeler_tableLayoutPanel4;
        private System.Windows.Forms.Button yadda_saxla_button2;
        private System.Windows.Forms.Button tesdiqle_button1;
        private System.Windows.Forms.Label status_label2;
    }
}