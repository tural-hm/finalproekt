﻿namespace MagazaProqramiDEA
{
    partial class Admin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.TreeNode treeNode1 = new System.Windows.Forms.TreeNode("Ərzaq");
            System.Windows.Forms.TreeNode treeNode2 = new System.Windows.Forms.TreeNode("Çaylar Kofelər");
            System.Windows.Forms.TreeNode treeNode3 = new System.Windows.Forms.TreeNode("Dondurma");
            System.Windows.Forms.TreeNode treeNode4 = new System.Windows.Forms.TreeNode("Paltar");
            System.Windows.Forms.TreeNode treeNode5 = new System.Windows.Forms.TreeNode("Parfumeriya");
            System.Windows.Forms.TreeNode treeNode6 = new System.Windows.Forms.TreeNode("Şirniyat");
            System.Windows.Forms.TreeNode treeNode7 = new System.Windows.Forms.TreeNode("Siqaret");
            System.Windows.Forms.TreeNode treeNode8 = new System.Windows.Forms.TreeNode("Süd Məhsulları");
            System.Windows.Forms.TreeNode treeNode9 = new System.Windows.Forms.TreeNode("Sular və Soklar");
            System.Windows.Forms.TreeNode treeNode10 = new System.Windows.Forms.TreeNode("Tərəzi Malları");
            System.Windows.Forms.TreeNode treeNode11 = new System.Windows.Forms.TreeNode("Bar Kodsuz Mallar");
            System.Windows.Forms.TreeNode treeNode12 = new System.Windows.Forms.TreeNode("Dənəli");
            System.Windows.Forms.TreeNode treeNode13 = new System.Windows.Forms.TreeNode("Uzunluq");
            System.Windows.Forms.TreeNode treeNode14 = new System.Windows.Forms.TreeNode("Mallar", new System.Windows.Forms.TreeNode[] {
            treeNode1,
            treeNode2,
            treeNode3,
            treeNode4,
            treeNode5,
            treeNode6,
            treeNode7,
            treeNode8,
            treeNode9,
            treeNode10,
            treeNode11,
            treeNode12,
            treeNode13});
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Admin));
            this.esas_tabControl1 = new System.Windows.Forms.TabControl();
            this.mallar_tabPage1 = new System.Windows.Forms.TabPage();
            this.mallar_tabControl1 = new System.Windows.Forms.TabControl();
            this.mallar_hisse_tabPage1 = new System.Windows.Forms.TabPage();
            this.mallar_esas_tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.mallar_asagi_tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.tam_ekran_mallar = new System.Windows.Forms.Button();
            this.satis_cemi_mallar = new System.Windows.Forms.Label();
            this.admin_daxil_olan_mallar_endirim_button = new System.Windows.Forms.Button();
            this.psv_satis_label25 = new System.Windows.Forms.Label();
            this.psv_alis_label20 = new System.Windows.Forms.Label();
            this.alis_cemi_mallar = new System.Windows.Forms.Label();
            this.mallari_bolen_spliter = new System.Windows.Forms.SplitContainer();
            this.mallar_siyahi_bolen_tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.mallar_treeview_mallar = new System.Windows.Forms.TreeView();
            this.mallar_esas_cedvel_tableLayoutPanel7 = new System.Windows.Forms.TableLayoutPanel();
            this.mallar_xeber_tableLayoutPanel8 = new System.Windows.Forms.TableLayoutPanel();
            this.xeberdarliq_label_mallar = new System.Windows.Forms.Label();
            this.axtaris_textbox_mallar = new System.Windows.Forms.TextBox();
            this.xeberdarliqlar_aktiv_label_1 = new System.Windows.Forms.Label();
            this.mali_redakte_et_button1 = new System.Windows.Forms.Button();
            this.mallar_qaytar_button1 = new System.Windows.Forms.Button();
            this.mallar_dgv_esas = new System.Windows.Forms.DataGridView();
            this.mallar_list_mallar = new System.Windows.Forms.ListBox();
            this.mallar_daxil_tableLayoutPanel9 = new System.Windows.Forms.TableLayoutPanel();
            this.daxil_dgv = new System.Windows.Forms.DataGridView();
            this.duymeler_tableLayoutPanel10 = new System.Windows.Forms.TableLayoutPanel();
            this.mallar_temizle_duymesi = new System.Windows.Forms.Button();
            this.daxil_ok_mallar = new System.Windows.Forms.Button();
            this.yeni_mal_mallar = new System.Windows.Forms.Button();
            this.sil_getirilen_mallardan_birini = new System.Windows.Forms.Button();
            this.daxil_legv_mallar = new System.Windows.Forms.Button();
            this.psv_daxil_label57 = new System.Windows.Forms.Label();
            this.real_mallar_tabPage1 = new System.Windows.Forms.TabPage();
            this.mallar_real_mallar_esas_tableLayoutPanel19 = new System.Windows.Forms.TableLayoutPanel();
            this.rm_dgv = new System.Windows.Forms.DataGridView();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label38 = new System.Windows.Forms.Label();
            this.mal_ktleri_combobox_rm = new System.Windows.Forms.ComboBox();
            this.rm_ok_button2 = new System.Windows.Forms.Button();
            this.axtar_text_rm = new System.Windows.Forms.TextBox();
            this.mal_tipleri_combobox_rm = new System.Windows.Forms.ComboBox();
            this.tableLayoutPanel20 = new System.Windows.Forms.TableLayoutPanel();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.rm_say_label42 = new System.Windows.Forms.Label();
            this.rm_cem_mq__label42 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.rm_cem_sq_label42 = new System.Windows.Forms.Label();
            this.rm_cem_md_label42 = new System.Windows.Forms.Label();
            this.rm_cem_gelir_label42 = new System.Windows.Forms.Label();
            this.yeni_mal_tabPage2 = new System.Windows.Forms.TabPage();
            this.yeni_mal_tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.yeni_mal_kt_listBox1 = new System.Windows.Forms.ListBox();
            this.getirilen_mallar_tabPage1 = new System.Windows.Forms.TabPage();
            this.getirilen_mallar_tabControl2 = new System.Windows.Forms.TabControl();
            this.getirilen_mallar_esas_tabPage1 = new System.Windows.Forms.TabPage();
            this.getirilen_mallar_tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.getirilen_m_adv = new ADGV.AdvancedDataGridView();
            this.kodDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.adDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.barKodDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tarixDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.miqdarDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.alışDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.məbləğDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.satışDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.satışMəbləğiDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gmv2BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.mpdeaDataSet = new MagazaProqramiDEA.mpdeaDataSet();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.son_tarix_qalan_mallarin = new System.Windows.Forms.DateTimePicker();
            this.label4 = new System.Windows.Forms.Label();
            this.gm_yenile_button1 = new System.Windows.Forms.Button();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.bas_tarix_qalan_mallarin = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.gm_bugun_button1 = new System.Windows.Forms.Button();
            this.getirilen_mallarin_umumi_siyahisi_d_g_v = new System.Windows.Forms.DataGridView();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.label5 = new System.Windows.Forms.Label();
            this.gm_setir_sayi_label6 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.gm_endirimli_cem_mebleg_label10 = new System.Windows.Forms.Label();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.label8 = new System.Windows.Forms.Label();
            this.gm_cem_satis_meblegi_label7 = new System.Windows.Forms.Label();
            this.cem_mebleg_label7_passiv = new System.Windows.Forms.Label();
            this.gm_cem_mebleg_label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.gm_cem_gelir_label7 = new System.Windows.Forms.Label();
            this.tableLayoutPanel17 = new System.Windows.Forms.TableLayoutPanel();
            this.label37 = new System.Windows.Forms.Label();
            this.gm_mdcem_label40 = new System.Windows.Forms.Label();
            this.tableLayoutPanel18 = new System.Windows.Forms.TableLayoutPanel();
            this.label39 = new System.Windows.Forms.Label();
            this.gm_sqcem_label40 = new System.Windows.Forms.Label();
            this.hesabat_tabPage1 = new System.Windows.Forms.TabPage();
            this.hesabat_tabControl1 = new System.Windows.Forms.TabControl();
            this.hesabat_kassa_tabPage1 = new System.Windows.Forms.TabPage();
            this.hesabat_kassa_tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.hesabat_esas_dgv = new System.Windows.Forms.DataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.mal_ktleri_combobox_hesabat = new System.Windows.Forms.ComboBox();
            this.hesabat_bugun_button1 = new System.Windows.Forms.Button();
            this.hesabat_satis_tipi_comboBox1 = new System.Windows.Forms.ComboBox();
            this.evvel_label = new System.Windows.Forms.Label();
            this.son_label = new System.Windows.Forms.Label();
            this.tarix_araligi_duymesi_hesabat = new System.Windows.Forms.Button();
            this.bas_tarix_hesabat = new System.Windows.Forms.DateTimePicker();
            this.son_tarix_hesabat = new System.Windows.Forms.DateTimePicker();
            this.axtar_text_hesabat = new System.Windows.Forms.TextBox();
            this.mal_tipleri_combobox_hesabat = new System.Windows.Forms.ComboBox();
            this.kassalar_combobox_hesabat = new System.Windows.Forms.ComboBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.cesid_sayi_label = new System.Windows.Forms.Label();
            this.umumi_say_label = new System.Windows.Forms.Label();
            this.umumi_say_label_aktiv = new System.Windows.Forms.Label();
            this.cesid_sayi_label_aktiv = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.hesabat_satis_cemi_aktiv_label3 = new System.Windows.Forms.Label();
            this.hesabat_gelir_cemi_aktiv_label3 = new System.Windows.Forms.Label();
            this.hesabat_cedveli_cap_et_button1 = new System.Windows.Forms.Button();
            this.hesabat_kassani_bagla_button1 = new System.Windows.Forms.Button();
            this.label60 = new System.Windows.Forms.Label();
            this.hesabat_satis_cemi_endirimli_aktiv_label3 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.kassa_endirim_meblegi_label62 = new System.Windows.Forms.Label();
            this.hesabat_bonus_kartlari_tabPage1 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel10 = new System.Windows.Forms.TableLayoutPanel();
            this.abk_silinme_dgv = new System.Windows.Forms.DataGridView();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.bonus_silinme_ok_button2 = new System.Windows.Forms.Button();
            this.abk_silinme_bas_dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.abk_silinme_son_dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label19 = new System.Windows.Forms.Label();
            this.abk_silinme_axtar_textBox1 = new System.Windows.Forms.TextBox();
            this.kassada_silinen_mallar_tabPage1 = new System.Windows.Forms.TabPage();
            this.kassada_silinen_esas_tableLayoutPanel12 = new System.Windows.Forms.TableLayoutPanel();
            this.kassada_silinenler_dgv = new System.Windows.Forms.DataGridView();
            this.kassada_silinen_panel3 = new System.Windows.Forms.Panel();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.kassaad_silinen_ok_button2 = new System.Windows.Forms.Button();
            this.kassada_silinen_bas_dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.kassada_silinen_son_dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.kassada_silinenler_kassalar_comboBox3 = new System.Windows.Forms.ComboBox();
            this.hesabat_malin_qaytarilmasi_tabPage1 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel15 = new System.Windows.Forms.TableLayoutPanel();
            this.hes_malin_qayt_dgv = new System.Windows.Forms.DataGridView();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label25 = new System.Windows.Forms.Label();
            this.hesabat_qaytar_mal_ktleri_comboBox3 = new System.Windows.Forms.ComboBox();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.hesabat_qaytar_ok_button2 = new System.Windows.Forms.Button();
            this.hesabat_qaytar_bas_dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.hesabat_qaytar_son_dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.hesabat_qaytar_axtar_txt = new System.Windows.Forms.TextBox();
            this.hesabat_qaytar_mal_tipleri_comboBox3 = new System.Windows.Forms.ComboBox();
            this.tableLayoutPanel16 = new System.Windows.Forms.TableLayoutPanel();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.hesabat_qaytar_umumi_say_label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.hesabat_borclular_tabPage1 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel19 = new System.Windows.Forms.TableLayoutPanel();
            this.hes_brlar_dgv = new System.Windows.Forms.DataGridView();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label45 = new System.Windows.Forms.Label();
            this.hes_brclar_borc_tipi_comboBox2 = new System.Windows.Forms.ComboBox();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.hes_brlar_ok_button2 = new System.Windows.Forms.Button();
            this.hes_brlar_bas_dateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.hes_brlar_son_dateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.hes_brlar_axtar_textBox = new System.Windows.Forms.TextBox();
            this.brlar_combobox_hesabat = new System.Windows.Forms.ComboBox();
            this.tableLayoutPanel21 = new System.Windows.Forms.TableLayoutPanel();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.umumi_say_label_aktiv_hes_brlar = new System.Windows.Forms.Label();
            this.cem_mebleg_label_aktiv_hes_brlar = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.bonus_tabPage1 = new System.Windows.Forms.TabPage();
            this.bonus_esas_tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.siyahi_bonus_tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.musteriler_psv_label4 = new System.Windows.Forms.Label();
            this.musteriler_listbox_bonus = new System.Windows.Forms.ListBox();
            this.bonus_sag_tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.yeni_b_kart_groupBox3 = new System.Windows.Forms.GroupBox();
            this.yeni_kart_text_ad_soyad = new System.Windows.Forms.TextBox();
            this.yeni_kart_kod = new System.Windows.Forms.TextBox();
            this.yeni_bonus_karti_duymesi = new System.Windows.Forms.Button();
            this.kod_label_kart = new System.Windows.Forms.Label();
            this.ad_label_kart = new System.Windows.Forms.Label();
            this.kohne_bonus_kartini_deyis = new System.Windows.Forms.Button();
            this.bonus_axtaris_groupBox4 = new System.Windows.Forms.GroupBox();
            this.axtar_textbox_koda_gore = new System.Windows.Forms.TextBox();
            this.bar_kod_label_axtar = new System.Windows.Forms.Label();
            this.axtar_textbox_ada_gore = new System.Windows.Forms.TextBox();
            this.ad_label_axtar = new System.Windows.Forms.Label();
            this.bonus_kartini_sil_button5 = new System.Windows.Forms.Button();
            this.sazlamalar_tabPage1 = new System.Windows.Forms.TabPage();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.bonus_k_tabPage1 = new System.Windows.Forms.TabPage();
            this.txtkasasayi = new System.Windows.Forms.TextBox();
            this.label62 = new System.Windows.Forms.Label();
            this.chekyes = new System.Windows.Forms.CheckBox();
            this.bonusyes = new System.Windows.Forms.CheckBox();
            this.sazlamalar_deyisiklikleri_kassaya_gonder_button = new System.Windows.Forms.Button();
            this.srok_aktiv_edilsin_checkBox = new System.Windows.Forms.CheckBox();
            this.alici_bildirisi_gunu_button = new System.Windows.Forms.Button();
            this.cekde_musterilerin_sroku_cap_olunsun_checkBox = new System.Windows.Forms.CheckBox();
            this.butun_musterilerin_srok_gununu_deyis_button = new System.Windows.Forms.Button();
            this.cekde_musteri_xali_gorunsun_checkBox = new System.Windows.Forms.CheckBox();
            this.admin_sazlamalar_faiz_standart_button = new System.Windows.Forms.Button();
            this.butun_musterilerin_bonus_faizini_deyis_button = new System.Windows.Forms.Button();
            this.elave_tabPage2 = new System.Windows.Forms.TabPage();
            this.yadda_saxla_button = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.sifre_textbox = new System.Windows.Forms.TextBox();
            this.sifreler_listbox = new System.Windows.Forms.ListBox();
            this.bazaya_sorgu_textBox2 = new System.Windows.Forms.TextBox();
            this.bazaya_iud_sorgu_button6 = new System.Windows.Forms.Button();
            this.sazlamalar_mallar_tabPage1 = new System.Windows.Forms.TabPage();
            this.sazlamalar_mallar_tableLayoutPanel12 = new System.Windows.Forms.TableLayoutPanel();
            this.sazlamalar_mallar_dgv = new System.Windows.Forms.DataGridView();
            this.tableLayoutPanel13 = new System.Windows.Forms.TableLayoutPanel();
            this.sazlamalar_mallar_silinmeli_ay_textBox1 = new System.Windows.Forms.TextBox();
            this.passiv_mallari_sil_button1 = new System.Windows.Forms.Button();
            this.sazlamalar_mallar_hamisini_sil_button1 = new System.Windows.Forms.Button();
            this.sazlamalar_mallar_birini_sil_button2 = new System.Windows.Forms.Button();
            this.sazlamalar_ktler_tabPage1 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel12 = new System.Windows.Forms.TableLayoutPanel();
            this.label20 = new System.Windows.Forms.Label();
            this.sazlamalar_ktler_listBox1 = new System.Windows.Forms.ListBox();
            this.tableLayoutPanel14 = new System.Windows.Forms.TableLayoutPanel();
            this.sazlamalar_ktler_adi_textBox1 = new System.Windows.Forms.TextBox();
            this.sazlamalar_ktler_adi_deyisdir_button1 = new System.Windows.Forms.Button();
            this.sazlamalar_ktler_siyahini_yenile_button1 = new System.Windows.Forms.Button();
            this.sazlamalar_ktler_yeni_kt_button1 = new System.Windows.Forms.Button();
            this.diger_tabPage1 = new System.Windows.Forms.TabPage();
            this.diger_esas_tabControl1 = new System.Windows.Forms.TabControl();
            this.borclar_tabPage1 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel7 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel8 = new System.Windows.Forms.TableLayoutPanel();
            this.label11 = new System.Windows.Forms.Label();
            this.borclar_axtar_textBox2 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.borclar_listBox1 = new System.Windows.Forms.ListBox();
            this.tableLayoutPanel9 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.borclar_yeni_musteri_textBox = new System.Windows.Forms.TextBox();
            this.borclar_yeni_musteri_button = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.tableLayoutPanel11 = new System.Windows.Forms.TableLayoutPanel();
            this.borclar_odenisi_yadda_saxla_button1 = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.borclar_borcumuzun_miqdari_textBox1 = new System.Windows.Forms.TextBox();
            this.borclular_tabPage2 = new System.Windows.Forms.TabPage();
            this.borclar_tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.borclar_axtar_tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.mus_label47 = new System.Windows.Forms.Label();
            this.borclular_axtar_textBox2 = new System.Windows.Forms.TextBox();
            this.axtar_psv_label48 = new System.Windows.Forms.Label();
            this.borclular_musleriler_listBox = new System.Windows.Forms.ListBox();
            this.brc_yeni_tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.yeni_musteri_groupBox33 = new System.Windows.Forms.GroupBox();
            this.borclular_yeni_musteri_textBox = new System.Windows.Forms.TextBox();
            this.borclular_yeni_musteri_button = new System.Windows.Forms.Button();
            this.ad_sad_label49_psv = new System.Windows.Forms.Label();
            this.silinmis_mallar_tabPage1 = new System.Windows.Forms.TabPage();
            this.silinmis_mali_tam_sil = new System.Windows.Forms.Button();
            this.silinmis_mali_geri_qaytar = new System.Windows.Forms.Button();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.silinmis_mallar_kodlari = new System.Windows.Forms.ListBox();
            this.silinmis_mallar_adlari = new System.Windows.Forms.ListBox();
            this.kodsuz_mallar_tabPage1 = new System.Windows.Forms.TabPage();
            this.kodsuz_mallar_yenile_button1 = new System.Windows.Forms.Button();
            this.strix_kodlar_label = new System.Windows.Forms.Label();
            this.mallarin_kodlari_listbox = new System.Windows.Forms.ListBox();
            this.yukle_duymesi = new System.Windows.Forms.Button();
            this.legv_et_button = new System.Windows.Forms.Button();
            this.hamisini_sec_button = new System.Windows.Forms.Button();
            this.bar_kodsuz_mallarin_siyahisi = new System.Windows.Forms.Label();
            this.mallarin_siyahisi_listbox = new System.Windows.Forms.CheckedListBox();
            this.malin_qaytarilmasi_tabPage1 = new System.Windows.Forms.TabPage();
            this.malin_qaytarilmasi_sqcem_label37 = new System.Windows.Forms.Label();
            this.malin_qaytarilmasi_sq_label37 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.malin_qaytarilmasi_qaytar_button1 = new System.Windows.Forms.Button();
            this.malin_qaytarilmasi_miqdar_textBox2 = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.malin_qaytarilmasi_bar_kod_textBox1 = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.diger_balans_tabPage1 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel22 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel23 = new System.Windows.Forms.TableLayoutPanel();
            this.label50 = new System.Windows.Forms.Label();
            this.magazanin_balansi_label50 = new System.Windows.Forms.Label();
            this.tableLayoutPanel24 = new System.Windows.Forms.TableLayoutPanel();
            this.balans_emeliyyatlar_dgv = new System.Windows.Forms.DataGridView();
            this.tableLayoutPanel26 = new System.Windows.Forms.TableLayoutPanel();
            this.label58 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.balans_emeliyyatlari_setir_sayi_label58 = new System.Windows.Forms.Label();
            this.balans_emeliyyatlari_cem_pul_label58 = new System.Windows.Forms.Label();
            this.tableLayoutPanel25 = new System.Windows.Forms.TableLayoutPanel();
            this.son_dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.balansa_medaxil_button1 = new System.Windows.Forms.Button();
            this.balansa_mexaric_button1 = new System.Windows.Forms.Button();
            this.balansi_yenile_button1 = new System.Windows.Forms.Button();
            this.label51 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.bas_dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.balans_medaxil_tipi_comboBox1 = new System.Windows.Forms.ComboBox();
            this.tableLayoutPanel27 = new System.Windows.Forms.TableLayoutPanel();
            this.label59 = new System.Windows.Forms.Label();
            this.balans_firma_adlari_comboBox1 = new System.Windows.Forms.ComboBox();
            this.balans_yeni_firma_button1 = new System.Windows.Forms.Button();
            this.balans_bugun_checkBox1 = new System.Windows.Forms.CheckBox();
            this.yeni_mal_4_button1 = new System.Windows.Forms.Button();
            this.yeni_mal_3_button1 = new System.Windows.Forms.Button();
            this.yeni_mal_2_button1 = new System.Windows.Forms.Button();
            this.yeni_mal_1_button1 = new System.Windows.Forms.Button();
            this.gmv2TableAdapter = new MagazaProqramiDEA.mpdeaDataSetTableAdapters.gmv2TableAdapter();
            this.esas_tabControl1.SuspendLayout();
            this.mallar_tabPage1.SuspendLayout();
            this.mallar_tabControl1.SuspendLayout();
            this.mallar_hisse_tabPage1.SuspendLayout();
            this.mallar_esas_tableLayoutPanel1.SuspendLayout();
            this.mallar_asagi_tableLayoutPanel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.mallari_bolen_spliter)).BeginInit();
            this.mallari_bolen_spliter.Panel1.SuspendLayout();
            this.mallari_bolen_spliter.Panel2.SuspendLayout();
            this.mallari_bolen_spliter.SuspendLayout();
            this.mallar_siyahi_bolen_tableLayoutPanel6.SuspendLayout();
            this.mallar_esas_cedvel_tableLayoutPanel7.SuspendLayout();
            this.mallar_xeber_tableLayoutPanel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.mallar_dgv_esas)).BeginInit();
            this.mallar_daxil_tableLayoutPanel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.daxil_dgv)).BeginInit();
            this.duymeler_tableLayoutPanel10.SuspendLayout();
            this.real_mallar_tabPage1.SuspendLayout();
            this.mallar_real_mallar_esas_tableLayoutPanel19.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rm_dgv)).BeginInit();
            this.panel4.SuspendLayout();
            this.tableLayoutPanel20.SuspendLayout();
            this.yeni_mal_tabPage2.SuspendLayout();
            this.yeni_mal_tableLayoutPanel1.SuspendLayout();
            this.getirilen_mallar_tabPage1.SuspendLayout();
            this.getirilen_mallar_tabControl2.SuspendLayout();
            this.getirilen_mallar_esas_tabPage1.SuspendLayout();
            this.getirilen_mallar_tableLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.getirilen_m_adv)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gmv2BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mpdeaDataSet)).BeginInit();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.getirilen_mallarin_umumi_siyahisi_d_g_v)).BeginInit();
            this.tableLayoutPanel5.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.tableLayoutPanel17.SuspendLayout();
            this.tableLayoutPanel18.SuspendLayout();
            this.hesabat_tabPage1.SuspendLayout();
            this.hesabat_tabControl1.SuspendLayout();
            this.hesabat_kassa_tabPage1.SuspendLayout();
            this.hesabat_kassa_tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.hesabat_esas_dgv)).BeginInit();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.hesabat_bonus_kartlari_tabPage1.SuspendLayout();
            this.tableLayoutPanel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.abk_silinme_dgv)).BeginInit();
            this.panel2.SuspendLayout();
            this.kassada_silinen_mallar_tabPage1.SuspendLayout();
            this.kassada_silinen_esas_tableLayoutPanel12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kassada_silinenler_dgv)).BeginInit();
            this.kassada_silinen_panel3.SuspendLayout();
            this.hesabat_malin_qaytarilmasi_tabPage1.SuspendLayout();
            this.tableLayoutPanel15.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.hes_malin_qayt_dgv)).BeginInit();
            this.panel3.SuspendLayout();
            this.tableLayoutPanel16.SuspendLayout();
            this.hesabat_borclular_tabPage1.SuspendLayout();
            this.tableLayoutPanel19.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.hes_brlar_dgv)).BeginInit();
            this.panel5.SuspendLayout();
            this.tableLayoutPanel21.SuspendLayout();
            this.bonus_tabPage1.SuspendLayout();
            this.bonus_esas_tableLayoutPanel1.SuspendLayout();
            this.siyahi_bonus_tableLayoutPanel2.SuspendLayout();
            this.bonus_sag_tableLayoutPanel3.SuspendLayout();
            this.yeni_b_kart_groupBox3.SuspendLayout();
            this.bonus_axtaris_groupBox4.SuspendLayout();
            this.sazlamalar_tabPage1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.bonus_k_tabPage1.SuspendLayout();
            this.elave_tabPage2.SuspendLayout();
            this.sazlamalar_mallar_tabPage1.SuspendLayout();
            this.sazlamalar_mallar_tableLayoutPanel12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sazlamalar_mallar_dgv)).BeginInit();
            this.tableLayoutPanel13.SuspendLayout();
            this.sazlamalar_ktler_tabPage1.SuspendLayout();
            this.tableLayoutPanel12.SuspendLayout();
            this.tableLayoutPanel14.SuspendLayout();
            this.diger_tabPage1.SuspendLayout();
            this.diger_esas_tabControl1.SuspendLayout();
            this.borclar_tabPage1.SuspendLayout();
            this.tableLayoutPanel7.SuspendLayout();
            this.tableLayoutPanel8.SuspendLayout();
            this.tableLayoutPanel9.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tableLayoutPanel11.SuspendLayout();
            this.borclular_tabPage2.SuspendLayout();
            this.borclar_tableLayoutPanel1.SuspendLayout();
            this.borclar_axtar_tableLayoutPanel2.SuspendLayout();
            this.brc_yeni_tableLayoutPanel3.SuspendLayout();
            this.yeni_musteri_groupBox33.SuspendLayout();
            this.silinmis_mallar_tabPage1.SuspendLayout();
            this.kodsuz_mallar_tabPage1.SuspendLayout();
            this.malin_qaytarilmasi_tabPage1.SuspendLayout();
            this.diger_balans_tabPage1.SuspendLayout();
            this.tableLayoutPanel22.SuspendLayout();
            this.tableLayoutPanel23.SuspendLayout();
            this.tableLayoutPanel24.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.balans_emeliyyatlar_dgv)).BeginInit();
            this.tableLayoutPanel26.SuspendLayout();
            this.tableLayoutPanel25.SuspendLayout();
            this.tableLayoutPanel27.SuspendLayout();
            this.SuspendLayout();
            // 
            // esas_tabControl1
            // 
            this.esas_tabControl1.Controls.Add(this.mallar_tabPage1);
            this.esas_tabControl1.Controls.Add(this.yeni_mal_tabPage2);
            this.esas_tabControl1.Controls.Add(this.getirilen_mallar_tabPage1);
            this.esas_tabControl1.Controls.Add(this.hesabat_tabPage1);
            this.esas_tabControl1.Controls.Add(this.bonus_tabPage1);
            this.esas_tabControl1.Controls.Add(this.sazlamalar_tabPage1);
            this.esas_tabControl1.Controls.Add(this.diger_tabPage1);
            this.esas_tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.esas_tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.esas_tabControl1.Location = new System.Drawing.Point(0, 0);
            this.esas_tabControl1.Name = "esas_tabControl1";
            this.esas_tabControl1.SelectedIndex = 0;
            this.esas_tabControl1.Size = new System.Drawing.Size(1284, 781);
            this.esas_tabControl1.TabIndex = 0;
            this.esas_tabControl1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.esas_tabControl1_MouseClick);
            // 
            // mallar_tabPage1
            // 
            this.mallar_tabPage1.Controls.Add(this.mallar_tabControl1);
            this.mallar_tabPage1.Location = new System.Drawing.Point(4, 29);
            this.mallar_tabPage1.Name = "mallar_tabPage1";
            this.mallar_tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.mallar_tabPage1.Size = new System.Drawing.Size(1276, 748);
            this.mallar_tabPage1.TabIndex = 0;
            this.mallar_tabPage1.Text = "MALLAR";
            this.mallar_tabPage1.UseVisualStyleBackColor = true;
            // 
            // mallar_tabControl1
            // 
            this.mallar_tabControl1.Controls.Add(this.mallar_hisse_tabPage1);
            this.mallar_tabControl1.Controls.Add(this.real_mallar_tabPage1);
            this.mallar_tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mallar_tabControl1.Location = new System.Drawing.Point(3, 3);
            this.mallar_tabControl1.Name = "mallar_tabControl1";
            this.mallar_tabControl1.SelectedIndex = 0;
            this.mallar_tabControl1.Size = new System.Drawing.Size(1270, 742);
            this.mallar_tabControl1.TabIndex = 0;
            // 
            // mallar_hisse_tabPage1
            // 
            this.mallar_hisse_tabPage1.Controls.Add(this.mallar_esas_tableLayoutPanel1);
            this.mallar_hisse_tabPage1.Location = new System.Drawing.Point(4, 29);
            this.mallar_hisse_tabPage1.Name = "mallar_hisse_tabPage1";
            this.mallar_hisse_tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.mallar_hisse_tabPage1.Size = new System.Drawing.Size(1262, 709);
            this.mallar_hisse_tabPage1.TabIndex = 0;
            this.mallar_hisse_tabPage1.Text = "Mallar";
            this.mallar_hisse_tabPage1.UseVisualStyleBackColor = true;
            // 
            // mallar_esas_tableLayoutPanel1
            // 
            this.mallar_esas_tableLayoutPanel1.ColumnCount = 1;
            this.mallar_esas_tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.mallar_esas_tableLayoutPanel1.Controls.Add(this.mallar_asagi_tableLayoutPanel5, 0, 1);
            this.mallar_esas_tableLayoutPanel1.Controls.Add(this.mallari_bolen_spliter, 0, 0);
            this.mallar_esas_tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mallar_esas_tableLayoutPanel1.Location = new System.Drawing.Point(3, 3);
            this.mallar_esas_tableLayoutPanel1.Name = "mallar_esas_tableLayoutPanel1";
            this.mallar_esas_tableLayoutPanel1.RowCount = 2;
            this.mallar_esas_tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.mallar_esas_tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.mallar_esas_tableLayoutPanel1.Size = new System.Drawing.Size(1256, 703);
            this.mallar_esas_tableLayoutPanel1.TabIndex = 1;
            // 
            // mallar_asagi_tableLayoutPanel5
            // 
            this.mallar_asagi_tableLayoutPanel5.ColumnCount = 7;
            this.mallar_asagi_tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 200F));
            this.mallar_asagi_tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.mallar_asagi_tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.mallar_asagi_tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 200F));
            this.mallar_asagi_tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.mallar_asagi_tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 200F));
            this.mallar_asagi_tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.mallar_asagi_tableLayoutPanel5.Controls.Add(this.tam_ekran_mallar, 0, 0);
            this.mallar_asagi_tableLayoutPanel5.Controls.Add(this.satis_cemi_mallar, 5, 0);
            this.mallar_asagi_tableLayoutPanel5.Controls.Add(this.admin_daxil_olan_mallar_endirim_button, 1, 0);
            this.mallar_asagi_tableLayoutPanel5.Controls.Add(this.psv_satis_label25, 4, 0);
            this.mallar_asagi_tableLayoutPanel5.Controls.Add(this.psv_alis_label20, 2, 0);
            this.mallar_asagi_tableLayoutPanel5.Controls.Add(this.alis_cemi_mallar, 3, 0);
            this.mallar_asagi_tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mallar_asagi_tableLayoutPanel5.Location = new System.Drawing.Point(3, 656);
            this.mallar_asagi_tableLayoutPanel5.Name = "mallar_asagi_tableLayoutPanel5";
            this.mallar_asagi_tableLayoutPanel5.RowCount = 1;
            this.mallar_asagi_tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.mallar_asagi_tableLayoutPanel5.Size = new System.Drawing.Size(1250, 44);
            this.mallar_asagi_tableLayoutPanel5.TabIndex = 29;
            // 
            // tam_ekran_mallar
            // 
            this.tam_ekran_mallar.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tam_ekran_mallar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.tam_ekran_mallar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.tam_ekran_mallar.Location = new System.Drawing.Point(3, 3);
            this.tam_ekran_mallar.Name = "tam_ekran_mallar";
            this.tam_ekran_mallar.Size = new System.Drawing.Size(194, 38);
            this.tam_ekran_mallar.TabIndex = 32;
            this.tam_ekran_mallar.Text = "Tam Ekran";
            this.tam_ekran_mallar.UseVisualStyleBackColor = true;
            this.tam_ekran_mallar.Click += new System.EventHandler(this.tam_ekran_mallar_Click);
            // 
            // satis_cemi_mallar
            // 
            this.satis_cemi_mallar.AutoSize = true;
            this.satis_cemi_mallar.Dock = System.Windows.Forms.DockStyle.Fill;
            this.satis_cemi_mallar.Location = new System.Drawing.Point(703, 0);
            this.satis_cemi_mallar.Name = "satis_cemi_mallar";
            this.satis_cemi_mallar.Size = new System.Drawing.Size(194, 44);
            this.satis_cemi_mallar.TabIndex = 31;
            this.satis_cemi_mallar.Text = ":::";
            this.satis_cemi_mallar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // admin_daxil_olan_mallar_endirim_button
            // 
            this.admin_daxil_olan_mallar_endirim_button.Dock = System.Windows.Forms.DockStyle.Fill;
            this.admin_daxil_olan_mallar_endirim_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.admin_daxil_olan_mallar_endirim_button.Location = new System.Drawing.Point(203, 3);
            this.admin_daxil_olan_mallar_endirim_button.Name = "admin_daxil_olan_mallar_endirim_button";
            this.admin_daxil_olan_mallar_endirim_button.Size = new System.Drawing.Size(94, 38);
            this.admin_daxil_olan_mallar_endirim_button.TabIndex = 33;
            this.admin_daxil_olan_mallar_endirim_button.Text = "Endirim";
            this.admin_daxil_olan_mallar_endirim_button.UseVisualStyleBackColor = true;
            this.admin_daxil_olan_mallar_endirim_button.Click += new System.EventHandler(this.admin_daxil_olan_mallar_endirim_button_Click);
            // 
            // psv_satis_label25
            // 
            this.psv_satis_label25.AutoSize = true;
            this.psv_satis_label25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.psv_satis_label25.Location = new System.Drawing.Point(603, 0);
            this.psv_satis_label25.Name = "psv_satis_label25";
            this.psv_satis_label25.Size = new System.Drawing.Size(94, 44);
            this.psv_satis_label25.TabIndex = 30;
            this.psv_satis_label25.Text = "Satış:";
            this.psv_satis_label25.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // psv_alis_label20
            // 
            this.psv_alis_label20.AutoSize = true;
            this.psv_alis_label20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.psv_alis_label20.Location = new System.Drawing.Point(303, 0);
            this.psv_alis_label20.Name = "psv_alis_label20";
            this.psv_alis_label20.Size = new System.Drawing.Size(94, 44);
            this.psv_alis_label20.TabIndex = 28;
            this.psv_alis_label20.Text = "Alış:";
            this.psv_alis_label20.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // alis_cemi_mallar
            // 
            this.alis_cemi_mallar.AutoSize = true;
            this.alis_cemi_mallar.Dock = System.Windows.Forms.DockStyle.Fill;
            this.alis_cemi_mallar.Location = new System.Drawing.Point(403, 0);
            this.alis_cemi_mallar.Name = "alis_cemi_mallar";
            this.alis_cemi_mallar.Size = new System.Drawing.Size(194, 44);
            this.alis_cemi_mallar.TabIndex = 29;
            this.alis_cemi_mallar.Text = ":::";
            this.alis_cemi_mallar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // mallari_bolen_spliter
            // 
            this.mallari_bolen_spliter.BackColor = System.Drawing.Color.LightSkyBlue;
            this.mallari_bolen_spliter.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mallari_bolen_spliter.ForeColor = System.Drawing.Color.Black;
            this.mallari_bolen_spliter.Location = new System.Drawing.Point(3, 3);
            this.mallari_bolen_spliter.Name = "mallari_bolen_spliter";
            this.mallari_bolen_spliter.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // mallari_bolen_spliter.Panel1
            // 
            this.mallari_bolen_spliter.Panel1.AutoScroll = true;
            this.mallari_bolen_spliter.Panel1.BackColor = System.Drawing.Color.White;
            this.mallari_bolen_spliter.Panel1.Controls.Add(this.mallar_siyahi_bolen_tableLayoutPanel6);
            this.mallari_bolen_spliter.Panel1.ForeColor = System.Drawing.Color.Black;
            this.mallari_bolen_spliter.Panel1.Margin = new System.Windows.Forms.Padding(3);
            this.mallari_bolen_spliter.Panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.splitContainer1_Panel1_Paint_1);
            // 
            // mallari_bolen_spliter.Panel2
            // 
            this.mallari_bolen_spliter.Panel2.AutoScroll = true;
            this.mallari_bolen_spliter.Panel2.BackColor = System.Drawing.Color.White;
            this.mallari_bolen_spliter.Panel2.Controls.Add(this.mallar_daxil_tableLayoutPanel9);
            this.mallari_bolen_spliter.Panel2.ForeColor = System.Drawing.Color.Black;
            this.mallari_bolen_spliter.Panel2.Margin = new System.Windows.Forms.Padding(3);
            this.mallari_bolen_spliter.Size = new System.Drawing.Size(1250, 647);
            this.mallari_bolen_spliter.SplitterDistance = 338;
            this.mallari_bolen_spliter.SplitterIncrement = 10;
            this.mallari_bolen_spliter.SplitterWidth = 10;
            this.mallari_bolen_spliter.TabIndex = 28;
            // 
            // mallar_siyahi_bolen_tableLayoutPanel6
            // 
            this.mallar_siyahi_bolen_tableLayoutPanel6.ColumnCount = 3;
            this.mallar_siyahi_bolen_tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 10F));
            this.mallar_siyahi_bolen_tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 300F));
            this.mallar_siyahi_bolen_tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.mallar_siyahi_bolen_tableLayoutPanel6.Controls.Add(this.mallar_treeview_mallar, 0, 0);
            this.mallar_siyahi_bolen_tableLayoutPanel6.Controls.Add(this.mallar_esas_cedvel_tableLayoutPanel7, 2, 0);
            this.mallar_siyahi_bolen_tableLayoutPanel6.Controls.Add(this.mallar_list_mallar, 1, 0);
            this.mallar_siyahi_bolen_tableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mallar_siyahi_bolen_tableLayoutPanel6.Location = new System.Drawing.Point(0, 0);
            this.mallar_siyahi_bolen_tableLayoutPanel6.Name = "mallar_siyahi_bolen_tableLayoutPanel6";
            this.mallar_siyahi_bolen_tableLayoutPanel6.RowCount = 1;
            this.mallar_siyahi_bolen_tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.mallar_siyahi_bolen_tableLayoutPanel6.Size = new System.Drawing.Size(1250, 338);
            this.mallar_siyahi_bolen_tableLayoutPanel6.TabIndex = 29;
            // 
            // mallar_treeview_mallar
            // 
            this.mallar_treeview_mallar.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mallar_treeview_mallar.Enabled = false;
            this.mallar_treeview_mallar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.mallar_treeview_mallar.Location = new System.Drawing.Point(3, 3);
            this.mallar_treeview_mallar.Name = "mallar_treeview_mallar";
            treeNode1.BackColor = System.Drawing.Color.White;
            treeNode1.ForeColor = System.Drawing.Color.Black;
            treeNode1.Name = "erzaq";
            treeNode1.NodeFont = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            treeNode1.Text = "Ərzaq";
            treeNode1.ToolTipText = "Ərzaq Malları";
            treeNode2.ForeColor = System.Drawing.Color.Black;
            treeNode2.Name = "caylar_kofeler";
            treeNode2.NodeFont = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            treeNode2.Text = "Çaylar Kofelər";
            treeNode2.ToolTipText = "Çaylar Kofelər";
            treeNode3.ForeColor = System.Drawing.Color.Black;
            treeNode3.Name = "dondurma";
            treeNode3.NodeFont = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            treeNode3.Text = "Dondurma";
            treeNode3.ToolTipText = "Dondurma malları";
            treeNode4.ForeColor = System.Drawing.Color.Black;
            treeNode4.Name = "paltar";
            treeNode4.NodeFont = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            treeNode4.Text = "Paltar";
            treeNode4.ToolTipText = "Paltarlar";
            treeNode5.Name = "parfumeriya";
            treeNode5.NodeFont = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            treeNode5.Text = "Parfumeriya";
            treeNode6.Name = "sirniyat";
            treeNode6.NodeFont = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            treeNode6.Text = "Şirniyat";
            treeNode7.Name = "siqaret";
            treeNode7.NodeFont = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            treeNode7.Text = "Siqaret";
            treeNode8.Name = "sud_mehsullari";
            treeNode8.NodeFont = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            treeNode8.Text = "Süd Məhsulları";
            treeNode9.Name = "sular_soklar";
            treeNode9.NodeFont = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            treeNode9.Text = "Sular və Soklar";
            treeNode10.Name = "terezi";
            treeNode10.NodeFont = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            treeNode10.Text = "Tərəzi Malları";
            treeNode10.ToolTipText = "Kiloqramla olan mallar";
            treeNode11.Name = "kodsuz_mallar";
            treeNode11.NodeFont = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            treeNode11.Text = "Bar Kodsuz Mallar";
            treeNode12.Name = "deneli";
            treeNode12.NodeFont = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            treeNode12.Text = "Dənəli";
            treeNode12.ToolTipText = "Bölünüb satılan mallar";
            treeNode13.Name = "uzunluq";
            treeNode13.NodeFont = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            treeNode13.Text = "Uzunluq";
            treeNode13.ToolTipText = "Metrlə satılan mallar";
            treeNode14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            treeNode14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            treeNode14.Name = "mallar";
            treeNode14.NodeFont = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            treeNode14.Text = "Mallar";
            treeNode14.ToolTipText = "Malların Siyahısı";
            this.mallar_treeview_mallar.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode14});
            this.mallar_treeview_mallar.Size = new System.Drawing.Size(4, 332);
            this.mallar_treeview_mallar.TabIndex = 0;
            this.mallar_treeview_mallar.Visible = false;
            this.mallar_treeview_mallar.KeyDown += new System.Windows.Forms.KeyEventHandler(this.mallar_treeview_mallar_KeyDown);
            this.mallar_treeview_mallar.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.mallar_treeview_mallar_MouseDoubleClick);
            // 
            // mallar_esas_cedvel_tableLayoutPanel7
            // 
            this.mallar_esas_cedvel_tableLayoutPanel7.ColumnCount = 1;
            this.mallar_esas_cedvel_tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.mallar_esas_cedvel_tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.mallar_esas_cedvel_tableLayoutPanel7.Controls.Add(this.mallar_xeber_tableLayoutPanel8, 0, 1);
            this.mallar_esas_cedvel_tableLayoutPanel7.Controls.Add(this.mallar_dgv_esas, 0, 0);
            this.mallar_esas_cedvel_tableLayoutPanel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mallar_esas_cedvel_tableLayoutPanel7.Location = new System.Drawing.Point(313, 3);
            this.mallar_esas_cedvel_tableLayoutPanel7.Name = "mallar_esas_cedvel_tableLayoutPanel7";
            this.mallar_esas_cedvel_tableLayoutPanel7.RowCount = 2;
            this.mallar_esas_cedvel_tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.mallar_esas_cedvel_tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.mallar_esas_cedvel_tableLayoutPanel7.Size = new System.Drawing.Size(934, 332);
            this.mallar_esas_cedvel_tableLayoutPanel7.TabIndex = 1;
            // 
            // mallar_xeber_tableLayoutPanel8
            // 
            this.mallar_xeber_tableLayoutPanel8.ColumnCount = 5;
            this.mallar_xeber_tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.mallar_xeber_tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.mallar_xeber_tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 180F));
            this.mallar_xeber_tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.mallar_xeber_tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.mallar_xeber_tableLayoutPanel8.Controls.Add(this.xeberdarliq_label_mallar, 0, 0);
            this.mallar_xeber_tableLayoutPanel8.Controls.Add(this.axtaris_textbox_mallar, 2, 0);
            this.mallar_xeber_tableLayoutPanel8.Controls.Add(this.xeberdarliqlar_aktiv_label_1, 1, 0);
            this.mallar_xeber_tableLayoutPanel8.Controls.Add(this.mali_redakte_et_button1, 3, 0);
            this.mallar_xeber_tableLayoutPanel8.Controls.Add(this.mallar_qaytar_button1, 4, 0);
            this.mallar_xeber_tableLayoutPanel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mallar_xeber_tableLayoutPanel8.Location = new System.Drawing.Point(3, 285);
            this.mallar_xeber_tableLayoutPanel8.Name = "mallar_xeber_tableLayoutPanel8";
            this.mallar_xeber_tableLayoutPanel8.RowCount = 1;
            this.mallar_xeber_tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.mallar_xeber_tableLayoutPanel8.Size = new System.Drawing.Size(928, 44);
            this.mallar_xeber_tableLayoutPanel8.TabIndex = 0;
            // 
            // xeberdarliq_label_mallar
            // 
            this.xeberdarliq_label_mallar.AutoSize = true;
            this.xeberdarliq_label_mallar.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xeberdarliq_label_mallar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.xeberdarliq_label_mallar.ForeColor = System.Drawing.Color.RoyalBlue;
            this.xeberdarliq_label_mallar.Location = new System.Drawing.Point(3, 0);
            this.xeberdarliq_label_mallar.Name = "xeberdarliq_label_mallar";
            this.xeberdarliq_label_mallar.Size = new System.Drawing.Size(114, 44);
            this.xeberdarliq_label_mallar.TabIndex = 28;
            this.xeberdarliq_label_mallar.Text = "Məlumatlar : ";
            this.xeberdarliq_label_mallar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // axtaris_textbox_mallar
            // 
            this.axtaris_textbox_mallar.BackColor = System.Drawing.Color.White;
            this.axtaris_textbox_mallar.Dock = System.Windows.Forms.DockStyle.Fill;
            this.axtaris_textbox_mallar.Enabled = false;
            this.axtaris_textbox_mallar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.axtaris_textbox_mallar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.axtaris_textbox_mallar.Location = new System.Drawing.Point(551, 3);
            this.axtaris_textbox_mallar.Name = "axtaris_textbox_mallar";
            this.axtaris_textbox_mallar.Size = new System.Drawing.Size(174, 21);
            this.axtaris_textbox_mallar.TabIndex = 2;
            // 
            // xeberdarliqlar_aktiv_label_1
            // 
            this.xeberdarliqlar_aktiv_label_1.AutoSize = true;
            this.xeberdarliqlar_aktiv_label_1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xeberdarliqlar_aktiv_label_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            this.xeberdarliqlar_aktiv_label_1.ForeColor = System.Drawing.Color.Red;
            this.xeberdarliqlar_aktiv_label_1.Location = new System.Drawing.Point(123, 0);
            this.xeberdarliqlar_aktiv_label_1.Name = "xeberdarliqlar_aktiv_label_1";
            this.xeberdarliqlar_aktiv_label_1.Size = new System.Drawing.Size(422, 44);
            this.xeberdarliqlar_aktiv_label_1.TabIndex = 27;
            this.xeberdarliqlar_aktiv_label_1.Text = "mesaj";
            this.xeberdarliqlar_aktiv_label_1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // mali_redakte_et_button1
            // 
            this.mali_redakte_et_button1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mali_redakte_et_button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mali_redakte_et_button1.ForeColor = System.Drawing.Color.Crimson;
            this.mali_redakte_et_button1.Location = new System.Drawing.Point(731, 3);
            this.mali_redakte_et_button1.Name = "mali_redakte_et_button1";
            this.mali_redakte_et_button1.Size = new System.Drawing.Size(94, 38);
            this.mali_redakte_et_button1.TabIndex = 29;
            this.mali_redakte_et_button1.Text = "Redaktə";
            this.mali_redakte_et_button1.UseVisualStyleBackColor = true;
            this.mali_redakte_et_button1.Click += new System.EventHandler(this.mali_redakte_et_button1_Click);
            // 
            // mallar_qaytar_button1
            // 
            this.mallar_qaytar_button1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mallar_qaytar_button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mallar_qaytar_button1.ForeColor = System.Drawing.Color.Crimson;
            this.mallar_qaytar_button1.Location = new System.Drawing.Point(831, 3);
            this.mallar_qaytar_button1.Name = "mallar_qaytar_button1";
            this.mallar_qaytar_button1.Size = new System.Drawing.Size(94, 38);
            this.mallar_qaytar_button1.TabIndex = 30;
            this.mallar_qaytar_button1.Text = "Qaytar";
            this.mallar_qaytar_button1.UseVisualStyleBackColor = true;
            this.mallar_qaytar_button1.Click += new System.EventHandler(this.mallar_qaytar_button1_Click);
            // 
            // mallar_dgv_esas
            // 
            this.mallar_dgv_esas.AllowUserToAddRows = false;
            this.mallar_dgv_esas.AllowUserToDeleteRows = false;
            this.mallar_dgv_esas.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.mallar_dgv_esas.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.mallar_dgv_esas.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.mallar_dgv_esas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.mallar_dgv_esas.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mallar_dgv_esas.Location = new System.Drawing.Point(3, 3);
            this.mallar_dgv_esas.MultiSelect = false;
            this.mallar_dgv_esas.Name = "mallar_dgv_esas";
            this.mallar_dgv_esas.ReadOnly = true;
            this.mallar_dgv_esas.RowHeadersVisible = false;
            this.mallar_dgv_esas.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mallar_dgv_esas.Size = new System.Drawing.Size(928, 276);
            this.mallar_dgv_esas.TabIndex = 1;
            this.mallar_dgv_esas.KeyDown += new System.Windows.Forms.KeyEventHandler(this.mallar_dgv_esas_KeyDown);
            this.mallar_dgv_esas.KeyUp += new System.Windows.Forms.KeyEventHandler(this.mallar_dgv_esas_KeyUp);
            this.mallar_dgv_esas.MouseClick += new System.Windows.Forms.MouseEventHandler(this.mallar_dgv_esas_MouseClick);
            this.mallar_dgv_esas.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.mallar_dgv_esas_MouseDoubleClick);
            // 
            // mallar_list_mallar
            // 
            this.mallar_list_mallar.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mallar_list_mallar.FormattingEnabled = true;
            this.mallar_list_mallar.ItemHeight = 20;
            this.mallar_list_mallar.Location = new System.Drawing.Point(13, 3);
            this.mallar_list_mallar.Name = "mallar_list_mallar";
            this.mallar_list_mallar.Size = new System.Drawing.Size(294, 332);
            this.mallar_list_mallar.TabIndex = 2;
            this.mallar_list_mallar.SelectedIndexChanged += new System.EventHandler(this.mallar_list_mallar_SelectedIndexChanged);
            // 
            // mallar_daxil_tableLayoutPanel9
            // 
            this.mallar_daxil_tableLayoutPanel9.ColumnCount = 2;
            this.mallar_daxil_tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.mallar_daxil_tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 200F));
            this.mallar_daxil_tableLayoutPanel9.Controls.Add(this.daxil_dgv, 0, 1);
            this.mallar_daxil_tableLayoutPanel9.Controls.Add(this.duymeler_tableLayoutPanel10, 1, 1);
            this.mallar_daxil_tableLayoutPanel9.Controls.Add(this.psv_daxil_label57, 0, 0);
            this.mallar_daxil_tableLayoutPanel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mallar_daxil_tableLayoutPanel9.Location = new System.Drawing.Point(0, 0);
            this.mallar_daxil_tableLayoutPanel9.Name = "mallar_daxil_tableLayoutPanel9";
            this.mallar_daxil_tableLayoutPanel9.RowCount = 2;
            this.mallar_daxil_tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.mallar_daxil_tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.mallar_daxil_tableLayoutPanel9.Size = new System.Drawing.Size(1250, 299);
            this.mallar_daxil_tableLayoutPanel9.TabIndex = 6;
            // 
            // daxil_dgv
            // 
            this.daxil_dgv.AllowUserToAddRows = false;
            this.daxil_dgv.AllowUserToDeleteRows = false;
            this.daxil_dgv.AllowUserToResizeRows = false;
            this.daxil_dgv.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.daxil_dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.daxil_dgv.Dock = System.Windows.Forms.DockStyle.Fill;
            this.daxil_dgv.Location = new System.Drawing.Point(3, 43);
            this.daxil_dgv.MultiSelect = false;
            this.daxil_dgv.Name = "daxil_dgv";
            this.daxil_dgv.ReadOnly = true;
            this.daxil_dgv.RowHeadersVisible = false;
            this.daxil_dgv.Size = new System.Drawing.Size(1044, 253);
            this.daxil_dgv.TabIndex = 3;
            this.daxil_dgv.KeyDown += new System.Windows.Forms.KeyEventHandler(this.daxil_dgv_KeyDown);
            this.daxil_dgv.KeyUp += new System.Windows.Forms.KeyEventHandler(this.daxil_dgv_KeyUp);
            this.daxil_dgv.MouseClick += new System.Windows.Forms.MouseEventHandler(this.daxil_dgv_MouseClick);
            this.daxil_dgv.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.daxil_dgv_MouseDoubleClick);
            this.daxil_dgv.ImeModeChanged += new System.EventHandler(this.daxil_dgv_ImeModeChanged);
            // 
            // duymeler_tableLayoutPanel10
            // 
            this.duymeler_tableLayoutPanel10.ColumnCount = 1;
            this.duymeler_tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.duymeler_tableLayoutPanel10.Controls.Add(this.mallar_temizle_duymesi, 0, 4);
            this.duymeler_tableLayoutPanel10.Controls.Add(this.daxil_ok_mallar, 0, 0);
            this.duymeler_tableLayoutPanel10.Controls.Add(this.yeni_mal_mallar, 0, 2);
            this.duymeler_tableLayoutPanel10.Controls.Add(this.sil_getirilen_mallardan_birini, 0, 3);
            this.duymeler_tableLayoutPanel10.Controls.Add(this.daxil_legv_mallar, 0, 1);
            this.duymeler_tableLayoutPanel10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.duymeler_tableLayoutPanel10.Location = new System.Drawing.Point(1053, 43);
            this.duymeler_tableLayoutPanel10.Name = "duymeler_tableLayoutPanel10";
            this.duymeler_tableLayoutPanel10.RowCount = 7;
            this.duymeler_tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.duymeler_tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.duymeler_tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.duymeler_tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.duymeler_tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.duymeler_tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.duymeler_tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.duymeler_tableLayoutPanel10.Size = new System.Drawing.Size(194, 253);
            this.duymeler_tableLayoutPanel10.TabIndex = 4;
            // 
            // mallar_temizle_duymesi
            // 
            this.mallar_temizle_duymesi.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mallar_temizle_duymesi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.mallar_temizle_duymesi.Location = new System.Drawing.Point(3, 143);
            this.mallar_temizle_duymesi.Name = "mallar_temizle_duymesi";
            this.mallar_temizle_duymesi.Size = new System.Drawing.Size(188, 29);
            this.mallar_temizle_duymesi.TabIndex = 9;
            this.mallar_temizle_duymesi.Text = "Təmizlə";
            this.mallar_temizle_duymesi.UseVisualStyleBackColor = true;
            this.mallar_temizle_duymesi.Visible = false;
            // 
            // daxil_ok_mallar
            // 
            this.daxil_ok_mallar.Dock = System.Windows.Forms.DockStyle.Fill;
            this.daxil_ok_mallar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.daxil_ok_mallar.Location = new System.Drawing.Point(3, 3);
            this.daxil_ok_mallar.Name = "daxil_ok_mallar";
            this.daxil_ok_mallar.Size = new System.Drawing.Size(188, 29);
            this.daxil_ok_mallar.TabIndex = 4;
            this.daxil_ok_mallar.Text = "OK";
            this.daxil_ok_mallar.UseVisualStyleBackColor = true;
            this.daxil_ok_mallar.Click += new System.EventHandler(this.daxil_ok_mallar_Click);
            // 
            // yeni_mal_mallar
            // 
            this.yeni_mal_mallar.Dock = System.Windows.Forms.DockStyle.Fill;
            this.yeni_mal_mallar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.yeni_mal_mallar.Location = new System.Drawing.Point(3, 73);
            this.yeni_mal_mallar.Name = "yeni_mal_mallar";
            this.yeni_mal_mallar.Size = new System.Drawing.Size(188, 29);
            this.yeni_mal_mallar.TabIndex = 7;
            this.yeni_mal_mallar.Text = "Yeni Mal";
            this.yeni_mal_mallar.UseVisualStyleBackColor = true;
            this.yeni_mal_mallar.Click += new System.EventHandler(this.yeni_mal_mallar_Click);
            // 
            // sil_getirilen_mallardan_birini
            // 
            this.sil_getirilen_mallardan_birini.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sil_getirilen_mallardan_birini.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.sil_getirilen_mallardan_birini.Location = new System.Drawing.Point(3, 108);
            this.sil_getirilen_mallardan_birini.Name = "sil_getirilen_mallardan_birini";
            this.sil_getirilen_mallardan_birini.Size = new System.Drawing.Size(188, 29);
            this.sil_getirilen_mallardan_birini.TabIndex = 8;
            this.sil_getirilen_mallardan_birini.Text = "Sil";
            this.sil_getirilen_mallardan_birini.UseVisualStyleBackColor = true;
            this.sil_getirilen_mallardan_birini.Click += new System.EventHandler(this.sil_getirilen_mallardan_birini_Click);
            // 
            // daxil_legv_mallar
            // 
            this.daxil_legv_mallar.Dock = System.Windows.Forms.DockStyle.Fill;
            this.daxil_legv_mallar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.daxil_legv_mallar.Location = new System.Drawing.Point(3, 38);
            this.daxil_legv_mallar.Name = "daxil_legv_mallar";
            this.daxil_legv_mallar.Size = new System.Drawing.Size(188, 29);
            this.daxil_legv_mallar.TabIndex = 5;
            this.daxil_legv_mallar.Text = "Ləğv";
            this.daxil_legv_mallar.UseVisualStyleBackColor = true;
            this.daxil_legv_mallar.Click += new System.EventHandler(this.daxil_legv_mallar_Click);
            // 
            // psv_daxil_label57
            // 
            this.psv_daxil_label57.AutoSize = true;
            this.psv_daxil_label57.Dock = System.Windows.Forms.DockStyle.Fill;
            this.psv_daxil_label57.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.psv_daxil_label57.Location = new System.Drawing.Point(3, 0);
            this.psv_daxil_label57.Name = "psv_daxil_label57";
            this.psv_daxil_label57.Size = new System.Drawing.Size(1044, 40);
            this.psv_daxil_label57.TabIndex = 5;
            this.psv_daxil_label57.Text = "DAXİL EDİLƏN MALLAR";
            this.psv_daxil_label57.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // real_mallar_tabPage1
            // 
            this.real_mallar_tabPage1.Controls.Add(this.mallar_real_mallar_esas_tableLayoutPanel19);
            this.real_mallar_tabPage1.Location = new System.Drawing.Point(4, 29);
            this.real_mallar_tabPage1.Name = "real_mallar_tabPage1";
            this.real_mallar_tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.real_mallar_tabPage1.Size = new System.Drawing.Size(1262, 709);
            this.real_mallar_tabPage1.TabIndex = 1;
            this.real_mallar_tabPage1.Text = "Real Mallar";
            this.real_mallar_tabPage1.UseVisualStyleBackColor = true;
            // 
            // mallar_real_mallar_esas_tableLayoutPanel19
            // 
            this.mallar_real_mallar_esas_tableLayoutPanel19.ColumnCount = 1;
            this.mallar_real_mallar_esas_tableLayoutPanel19.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.mallar_real_mallar_esas_tableLayoutPanel19.Controls.Add(this.rm_dgv, 0, 1);
            this.mallar_real_mallar_esas_tableLayoutPanel19.Controls.Add(this.panel4, 0, 0);
            this.mallar_real_mallar_esas_tableLayoutPanel19.Controls.Add(this.tableLayoutPanel20, 0, 2);
            this.mallar_real_mallar_esas_tableLayoutPanel19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mallar_real_mallar_esas_tableLayoutPanel19.Location = new System.Drawing.Point(3, 3);
            this.mallar_real_mallar_esas_tableLayoutPanel19.Name = "mallar_real_mallar_esas_tableLayoutPanel19";
            this.mallar_real_mallar_esas_tableLayoutPanel19.RowCount = 3;
            this.mallar_real_mallar_esas_tableLayoutPanel19.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.mallar_real_mallar_esas_tableLayoutPanel19.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.mallar_real_mallar_esas_tableLayoutPanel19.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.mallar_real_mallar_esas_tableLayoutPanel19.Size = new System.Drawing.Size(1256, 703);
            this.mallar_real_mallar_esas_tableLayoutPanel19.TabIndex = 1;
            // 
            // rm_dgv
            // 
            this.rm_dgv.AllowUserToAddRows = false;
            this.rm_dgv.AllowUserToDeleteRows = false;
            this.rm_dgv.AllowUserToOrderColumns = true;
            this.rm_dgv.AllowUserToResizeRows = false;
            this.rm_dgv.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.rm_dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.rm_dgv.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rm_dgv.Location = new System.Drawing.Point(3, 103);
            this.rm_dgv.MultiSelect = false;
            this.rm_dgv.Name = "rm_dgv";
            this.rm_dgv.ReadOnly = true;
            this.rm_dgv.RowHeadersVisible = false;
            this.rm_dgv.Size = new System.Drawing.Size(1250, 497);
            this.rm_dgv.TabIndex = 0;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.label38);
            this.panel4.Controls.Add(this.mal_ktleri_combobox_rm);
            this.panel4.Controls.Add(this.rm_ok_button2);
            this.panel4.Controls.Add(this.axtar_text_rm);
            this.panel4.Controls.Add(this.mal_tipleri_combobox_rm);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(3, 3);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1250, 94);
            this.panel4.TabIndex = 1;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(219, 15);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(51, 20);
            this.label38.TabIndex = 54;
            this.label38.Text = "Axtar";
            // 
            // mal_ktleri_combobox_rm
            // 
            this.mal_ktleri_combobox_rm.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.mal_ktleri_combobox_rm.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.mal_ktleri_combobox_rm.FormattingEnabled = true;
            this.mal_ktleri_combobox_rm.Items.AddRange(new object[] {
            "Mal kateqoriyaları"});
            this.mal_ktleri_combobox_rm.Location = new System.Drawing.Point(18, 50);
            this.mal_ktleri_combobox_rm.Name = "mal_ktleri_combobox_rm";
            this.mal_ktleri_combobox_rm.Size = new System.Drawing.Size(144, 21);
            this.mal_ktleri_combobox_rm.TabIndex = 53;
            // 
            // rm_ok_button2
            // 
            this.rm_ok_button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.rm_ok_button2.ForeColor = System.Drawing.Color.Maroon;
            this.rm_ok_button2.Location = new System.Drawing.Point(326, 22);
            this.rm_ok_button2.Name = "rm_ok_button2";
            this.rm_ok_button2.Size = new System.Drawing.Size(69, 51);
            this.rm_ok_button2.TabIndex = 46;
            this.rm_ok_button2.Text = "OK";
            this.rm_ok_button2.UseVisualStyleBackColor = true;
            this.rm_ok_button2.Click += new System.EventHandler(this.rm_ok_button2_Click);
            // 
            // axtar_text_rm
            // 
            this.axtar_text_rm.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.axtar_text_rm.Location = new System.Drawing.Point(183, 50);
            this.axtar_text_rm.Name = "axtar_text_rm";
            this.axtar_text_rm.Size = new System.Drawing.Size(119, 23);
            this.axtar_text_rm.TabIndex = 41;
            // 
            // mal_tipleri_combobox_rm
            // 
            this.mal_tipleri_combobox_rm.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.mal_tipleri_combobox_rm.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.mal_tipleri_combobox_rm.FormattingEnabled = true;
            this.mal_tipleri_combobox_rm.Items.AddRange(new object[] {
            "Mal tipləri",
            "1-Say",
            "2-Uzunluq",
            "3-Çəki",
            "4-Dənəli"});
            this.mal_tipleri_combobox_rm.Location = new System.Drawing.Point(18, 14);
            this.mal_tipleri_combobox_rm.Name = "mal_tipleri_combobox_rm";
            this.mal_tipleri_combobox_rm.Size = new System.Drawing.Size(144, 21);
            this.mal_tipleri_combobox_rm.TabIndex = 35;
            // 
            // tableLayoutPanel20
            // 
            this.tableLayoutPanel20.ColumnCount = 7;
            this.tableLayoutPanel20.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
            this.tableLayoutPanel20.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel20.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel20.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel20.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
            this.tableLayoutPanel20.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel20.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel20.Controls.Add(this.label40, 0, 0);
            this.tableLayoutPanel20.Controls.Add(this.label41, 0, 1);
            this.tableLayoutPanel20.Controls.Add(this.rm_say_label42, 1, 0);
            this.tableLayoutPanel20.Controls.Add(this.rm_cem_mq__label42, 1, 1);
            this.tableLayoutPanel20.Controls.Add(this.label42, 2, 0);
            this.tableLayoutPanel20.Controls.Add(this.label43, 2, 1);
            this.tableLayoutPanel20.Controls.Add(this.label44, 4, 0);
            this.tableLayoutPanel20.Controls.Add(this.rm_cem_sq_label42, 3, 0);
            this.tableLayoutPanel20.Controls.Add(this.rm_cem_md_label42, 3, 1);
            this.tableLayoutPanel20.Controls.Add(this.rm_cem_gelir_label42, 5, 0);
            this.tableLayoutPanel20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel20.Location = new System.Drawing.Point(3, 606);
            this.tableLayoutPanel20.Name = "tableLayoutPanel20";
            this.tableLayoutPanel20.RowCount = 2;
            this.tableLayoutPanel20.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel20.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel20.Size = new System.Drawing.Size(1250, 94);
            this.tableLayoutPanel20.TabIndex = 2;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label40.Location = new System.Drawing.Point(3, 0);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(134, 47);
            this.label40.TabIndex = 0;
            this.label40.Text = "Say:";
            this.label40.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label41.Location = new System.Drawing.Point(3, 47);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(134, 47);
            this.label41.TabIndex = 1;
            this.label41.Text = "Cəm miqdar:";
            this.label41.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // rm_say_label42
            // 
            this.rm_say_label42.AutoSize = true;
            this.rm_say_label42.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rm_say_label42.Location = new System.Drawing.Point(143, 0);
            this.rm_say_label42.Name = "rm_say_label42";
            this.rm_say_label42.Size = new System.Drawing.Size(114, 47);
            this.rm_say_label42.TabIndex = 2;
            this.rm_say_label42.Text = ":::";
            this.rm_say_label42.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // rm_cem_mq__label42
            // 
            this.rm_cem_mq__label42.AutoSize = true;
            this.rm_cem_mq__label42.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rm_cem_mq__label42.Location = new System.Drawing.Point(143, 47);
            this.rm_cem_mq__label42.Name = "rm_cem_mq__label42";
            this.rm_cem_mq__label42.Size = new System.Drawing.Size(114, 47);
            this.rm_cem_mq__label42.TabIndex = 3;
            this.rm_cem_mq__label42.Text = ":::";
            this.rm_cem_mq__label42.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label42.Location = new System.Drawing.Point(263, 0);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(114, 47);
            this.label42.TabIndex = 4;
            this.label42.Text = "Cəm satış:";
            this.label42.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label43.Location = new System.Drawing.Point(263, 47);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(114, 47);
            this.label43.TabIndex = 5;
            this.label43.Text = "Cəm maya:";
            this.label43.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label44.Location = new System.Drawing.Point(503, 0);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(134, 47);
            this.label44.TabIndex = 6;
            this.label44.Text = "Cəm gəlir:";
            this.label44.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // rm_cem_sq_label42
            // 
            this.rm_cem_sq_label42.AutoSize = true;
            this.rm_cem_sq_label42.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rm_cem_sq_label42.Location = new System.Drawing.Point(383, 0);
            this.rm_cem_sq_label42.Name = "rm_cem_sq_label42";
            this.rm_cem_sq_label42.Size = new System.Drawing.Size(114, 47);
            this.rm_cem_sq_label42.TabIndex = 7;
            this.rm_cem_sq_label42.Text = ":::";
            this.rm_cem_sq_label42.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // rm_cem_md_label42
            // 
            this.rm_cem_md_label42.AutoSize = true;
            this.rm_cem_md_label42.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rm_cem_md_label42.Location = new System.Drawing.Point(383, 47);
            this.rm_cem_md_label42.Name = "rm_cem_md_label42";
            this.rm_cem_md_label42.Size = new System.Drawing.Size(114, 47);
            this.rm_cem_md_label42.TabIndex = 8;
            this.rm_cem_md_label42.Text = ":::";
            this.rm_cem_md_label42.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // rm_cem_gelir_label42
            // 
            this.rm_cem_gelir_label42.AutoSize = true;
            this.rm_cem_gelir_label42.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rm_cem_gelir_label42.Location = new System.Drawing.Point(643, 0);
            this.rm_cem_gelir_label42.Name = "rm_cem_gelir_label42";
            this.rm_cem_gelir_label42.Size = new System.Drawing.Size(114, 47);
            this.rm_cem_gelir_label42.TabIndex = 9;
            this.rm_cem_gelir_label42.Text = ":::";
            this.rm_cem_gelir_label42.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // yeni_mal_tabPage2
            // 
            this.yeni_mal_tabPage2.Controls.Add(this.yeni_mal_tableLayoutPanel1);
            this.yeni_mal_tabPage2.Location = new System.Drawing.Point(4, 29);
            this.yeni_mal_tabPage2.Name = "yeni_mal_tabPage2";
            this.yeni_mal_tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.yeni_mal_tabPage2.Size = new System.Drawing.Size(1276, 748);
            this.yeni_mal_tabPage2.TabIndex = 1;
            this.yeni_mal_tabPage2.Text = "YENI MAL";
            this.yeni_mal_tabPage2.UseVisualStyleBackColor = true;
            // 
            // yeni_mal_tableLayoutPanel1
            // 
            this.yeni_mal_tableLayoutPanel1.ColumnCount = 2;
            this.yeni_mal_tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 400F));
            this.yeni_mal_tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.yeni_mal_tableLayoutPanel1.Controls.Add(this.yeni_mal_kt_listBox1, 0, 0);
            this.yeni_mal_tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.yeni_mal_tableLayoutPanel1.Location = new System.Drawing.Point(3, 3);
            this.yeni_mal_tableLayoutPanel1.Name = "yeni_mal_tableLayoutPanel1";
            this.yeni_mal_tableLayoutPanel1.RowCount = 2;
            this.yeni_mal_tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 500F));
            this.yeni_mal_tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.yeni_mal_tableLayoutPanel1.Size = new System.Drawing.Size(1270, 742);
            this.yeni_mal_tableLayoutPanel1.TabIndex = 0;
            // 
            // yeni_mal_kt_listBox1
            // 
            this.yeni_mal_kt_listBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.yeni_mal_kt_listBox1.FormattingEnabled = true;
            this.yeni_mal_kt_listBox1.ItemHeight = 20;
            this.yeni_mal_kt_listBox1.Location = new System.Drawing.Point(3, 3);
            this.yeni_mal_kt_listBox1.Name = "yeni_mal_kt_listBox1";
            this.yeni_mal_kt_listBox1.Size = new System.Drawing.Size(394, 494);
            this.yeni_mal_kt_listBox1.TabIndex = 0;
            this.yeni_mal_kt_listBox1.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.yeni_mal_kt_listBox1_MouseDoubleClick);
            // 
            // getirilen_mallar_tabPage1
            // 
            this.getirilen_mallar_tabPage1.Controls.Add(this.getirilen_mallar_tabControl2);
            this.getirilen_mallar_tabPage1.Location = new System.Drawing.Point(4, 29);
            this.getirilen_mallar_tabPage1.Name = "getirilen_mallar_tabPage1";
            this.getirilen_mallar_tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.getirilen_mallar_tabPage1.Size = new System.Drawing.Size(1276, 748);
            this.getirilen_mallar_tabPage1.TabIndex = 2;
            this.getirilen_mallar_tabPage1.Text = "GƏTİRİLƏN MALLAR";
            this.getirilen_mallar_tabPage1.UseVisualStyleBackColor = true;
            // 
            // getirilen_mallar_tabControl2
            // 
            this.getirilen_mallar_tabControl2.Controls.Add(this.getirilen_mallar_esas_tabPage1);
            this.getirilen_mallar_tabControl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.getirilen_mallar_tabControl2.Location = new System.Drawing.Point(3, 3);
            this.getirilen_mallar_tabControl2.Name = "getirilen_mallar_tabControl2";
            this.getirilen_mallar_tabControl2.SelectedIndex = 0;
            this.getirilen_mallar_tabControl2.Size = new System.Drawing.Size(1270, 742);
            this.getirilen_mallar_tabControl2.TabIndex = 0;
            // 
            // getirilen_mallar_esas_tabPage1
            // 
            this.getirilen_mallar_esas_tabPage1.Controls.Add(this.getirilen_mallar_tableLayoutPanel2);
            this.getirilen_mallar_esas_tabPage1.Location = new System.Drawing.Point(4, 29);
            this.getirilen_mallar_esas_tabPage1.Name = "getirilen_mallar_esas_tabPage1";
            this.getirilen_mallar_esas_tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.getirilen_mallar_esas_tabPage1.Size = new System.Drawing.Size(1262, 709);
            this.getirilen_mallar_esas_tabPage1.TabIndex = 0;
            this.getirilen_mallar_esas_tabPage1.Text = "Gətirilən Mallar";
            this.getirilen_mallar_esas_tabPage1.UseVisualStyleBackColor = true;
            // 
            // getirilen_mallar_tableLayoutPanel2
            // 
            this.getirilen_mallar_tableLayoutPanel2.ColumnCount = 2;
            this.getirilen_mallar_tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 300F));
            this.getirilen_mallar_tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.getirilen_mallar_tableLayoutPanel2.Controls.Add(this.getirilen_m_adv, 1, 0);
            this.getirilen_mallar_tableLayoutPanel2.Controls.Add(this.tableLayoutPanel2, 0, 0);
            this.getirilen_mallar_tableLayoutPanel2.Controls.Add(this.tableLayoutPanel5, 1, 1);
            this.getirilen_mallar_tableLayoutPanel2.Controls.Add(this.tableLayoutPanel6, 1, 2);
            this.getirilen_mallar_tableLayoutPanel2.Controls.Add(this.tableLayoutPanel17, 0, 1);
            this.getirilen_mallar_tableLayoutPanel2.Controls.Add(this.tableLayoutPanel18, 0, 2);
            this.getirilen_mallar_tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.getirilen_mallar_tableLayoutPanel2.Location = new System.Drawing.Point(3, 3);
            this.getirilen_mallar_tableLayoutPanel2.Name = "getirilen_mallar_tableLayoutPanel2";
            this.getirilen_mallar_tableLayoutPanel2.RowCount = 3;
            this.getirilen_mallar_tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.getirilen_mallar_tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.getirilen_mallar_tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.getirilen_mallar_tableLayoutPanel2.Size = new System.Drawing.Size(1256, 703);
            this.getirilen_mallar_tableLayoutPanel2.TabIndex = 0;
            // 
            // getirilen_m_adv
            // 
            this.getirilen_m_adv.AllowUserToAddRows = false;
            this.getirilen_m_adv.AllowUserToDeleteRows = false;
            this.getirilen_m_adv.AllowUserToResizeRows = false;
            this.getirilen_m_adv.AutoGenerateColumns = false;
            this.getirilen_m_adv.AutoGenerateContextFilters = true;
            this.getirilen_m_adv.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.getirilen_m_adv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.getirilen_m_adv.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.kodDataGridViewTextBoxColumn,
            this.adDataGridViewTextBoxColumn,
            this.barKodDataGridViewTextBoxColumn,
            this.tarixDataGridViewTextBoxColumn,
            this.miqdarDataGridViewTextBoxColumn,
            this.alışDataGridViewTextBoxColumn,
            this.məbləğDataGridViewTextBoxColumn,
            this.satışDataGridViewTextBoxColumn,
            this.satışMəbləğiDataGridViewTextBoxColumn});
            this.getirilen_m_adv.DataSource = this.gmv2BindingSource;
            this.getirilen_m_adv.DateWithTime = false;
            this.getirilen_m_adv.Dock = System.Windows.Forms.DockStyle.Fill;
            this.getirilen_m_adv.Location = new System.Drawing.Point(303, 3);
            this.getirilen_m_adv.MultiSelect = false;
            this.getirilen_m_adv.Name = "getirilen_m_adv";
            this.getirilen_m_adv.ReadOnly = true;
            this.getirilen_m_adv.RowHeadersVisible = false;
            this.getirilen_m_adv.Size = new System.Drawing.Size(950, 597);
            this.getirilen_m_adv.TabIndex = 0;
            this.getirilen_m_adv.TimeFilter = false;
            this.getirilen_m_adv.SortStringChanged += new System.EventHandler(this.getirilen_m_adv_SortStringChanged);
            this.getirilen_m_adv.FilterStringChanged += new System.EventHandler(this.getirilen_m_adv_FilterStringChanged);
            this.getirilen_m_adv.Click += new System.EventHandler(this.getirilen_m_adv_Click);
            this.getirilen_m_adv.KeyDown += new System.Windows.Forms.KeyEventHandler(this.getirilen_m_adv_KeyDown);
            this.getirilen_m_adv.KeyUp += new System.Windows.Forms.KeyEventHandler(this.getirilen_m_adv_KeyUp);
            this.getirilen_m_adv.MouseClick += new System.Windows.Forms.MouseEventHandler(this.getirilen_m_adv_MouseClick);
            this.getirilen_m_adv.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.getirilen_m_adv_MouseDoubleClick);
            // 
            // kodDataGridViewTextBoxColumn
            // 
            this.kodDataGridViewTextBoxColumn.DataPropertyName = "Kod";
            this.kodDataGridViewTextBoxColumn.HeaderText = "Kod";
            this.kodDataGridViewTextBoxColumn.MinimumWidth = 22;
            this.kodDataGridViewTextBoxColumn.Name = "kodDataGridViewTextBoxColumn";
            this.kodDataGridViewTextBoxColumn.ReadOnly = true;
            this.kodDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            // 
            // adDataGridViewTextBoxColumn
            // 
            this.adDataGridViewTextBoxColumn.DataPropertyName = "Ad";
            this.adDataGridViewTextBoxColumn.HeaderText = "Ad";
            this.adDataGridViewTextBoxColumn.MinimumWidth = 22;
            this.adDataGridViewTextBoxColumn.Name = "adDataGridViewTextBoxColumn";
            this.adDataGridViewTextBoxColumn.ReadOnly = true;
            this.adDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            // 
            // barKodDataGridViewTextBoxColumn
            // 
            this.barKodDataGridViewTextBoxColumn.DataPropertyName = "Bar Kod";
            this.barKodDataGridViewTextBoxColumn.HeaderText = "Bar Kod";
            this.barKodDataGridViewTextBoxColumn.MinimumWidth = 22;
            this.barKodDataGridViewTextBoxColumn.Name = "barKodDataGridViewTextBoxColumn";
            this.barKodDataGridViewTextBoxColumn.ReadOnly = true;
            this.barKodDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            // 
            // tarixDataGridViewTextBoxColumn
            // 
            this.tarixDataGridViewTextBoxColumn.DataPropertyName = "Tarix";
            dataGridViewCellStyle2.Format = "yyyy-MM-dd HH:mm:ss";
            this.tarixDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle2;
            this.tarixDataGridViewTextBoxColumn.HeaderText = "Tarix";
            this.tarixDataGridViewTextBoxColumn.MinimumWidth = 22;
            this.tarixDataGridViewTextBoxColumn.Name = "tarixDataGridViewTextBoxColumn";
            this.tarixDataGridViewTextBoxColumn.ReadOnly = true;
            this.tarixDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            // 
            // miqdarDataGridViewTextBoxColumn
            // 
            this.miqdarDataGridViewTextBoxColumn.DataPropertyName = "Miqdar";
            this.miqdarDataGridViewTextBoxColumn.HeaderText = "Miqdar";
            this.miqdarDataGridViewTextBoxColumn.MinimumWidth = 22;
            this.miqdarDataGridViewTextBoxColumn.Name = "miqdarDataGridViewTextBoxColumn";
            this.miqdarDataGridViewTextBoxColumn.ReadOnly = true;
            this.miqdarDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            // 
            // alışDataGridViewTextBoxColumn
            // 
            this.alışDataGridViewTextBoxColumn.DataPropertyName = "Alış";
            this.alışDataGridViewTextBoxColumn.HeaderText = "Alış";
            this.alışDataGridViewTextBoxColumn.MinimumWidth = 22;
            this.alışDataGridViewTextBoxColumn.Name = "alışDataGridViewTextBoxColumn";
            this.alışDataGridViewTextBoxColumn.ReadOnly = true;
            this.alışDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            // 
            // məbləğDataGridViewTextBoxColumn
            // 
            this.məbləğDataGridViewTextBoxColumn.DataPropertyName = "Məbləğ";
            this.məbləğDataGridViewTextBoxColumn.HeaderText = "Məbləğ";
            this.məbləğDataGridViewTextBoxColumn.MinimumWidth = 22;
            this.məbləğDataGridViewTextBoxColumn.Name = "məbləğDataGridViewTextBoxColumn";
            this.məbləğDataGridViewTextBoxColumn.ReadOnly = true;
            this.məbləğDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            // 
            // satışDataGridViewTextBoxColumn
            // 
            this.satışDataGridViewTextBoxColumn.DataPropertyName = "Satış";
            this.satışDataGridViewTextBoxColumn.HeaderText = "Satış";
            this.satışDataGridViewTextBoxColumn.MinimumWidth = 22;
            this.satışDataGridViewTextBoxColumn.Name = "satışDataGridViewTextBoxColumn";
            this.satışDataGridViewTextBoxColumn.ReadOnly = true;
            this.satışDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            // 
            // satışMəbləğiDataGridViewTextBoxColumn
            // 
            this.satışMəbləğiDataGridViewTextBoxColumn.DataPropertyName = "Satış Məbləği";
            this.satışMəbləğiDataGridViewTextBoxColumn.HeaderText = "Satış Məbləği";
            this.satışMəbləğiDataGridViewTextBoxColumn.MinimumWidth = 22;
            this.satışMəbləğiDataGridViewTextBoxColumn.Name = "satışMəbləğiDataGridViewTextBoxColumn";
            this.satışMəbləğiDataGridViewTextBoxColumn.ReadOnly = true;
            this.satışMəbləğiDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            // 
            // gmv2BindingSource
            // 
            this.gmv2BindingSource.DataMember = "gmv2";
            this.gmv2BindingSource.DataSource = this.mpdeaDataSet;
            this.gmv2BindingSource.ListChanged += new System.ComponentModel.ListChangedEventHandler(this.gmv2BindingSource_ListChanged);
            // 
            // mpdeaDataSet
            // 
            this.mpdeaDataSet.DataSetName = "mpdeaDataSet";
            this.mpdeaDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel4, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.gm_yenile_button1, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel3, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.gm_bugun_button1, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.getirilen_mallarin_umumi_siyahisi_d_g_v, 0, 4);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 5;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 80F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 80F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(294, 597);
            this.tableLayoutPanel2.TabIndex = 1;
            this.tableLayoutPanel2.Paint += new System.Windows.Forms.PaintEventHandler(this.tableLayoutPanel2_Paint);
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 1;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel4.Controls.Add(this.son_tarix_qalan_mallarin, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.label4, 0, 0);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(3, 123);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 2;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(288, 74);
            this.tableLayoutPanel4.TabIndex = 2;
            // 
            // son_tarix_qalan_mallarin
            // 
            this.son_tarix_qalan_mallarin.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.son_tarix_qalan_mallarin.CustomFormat = "yyyy-MM-dd HH:mm:ss";
            this.son_tarix_qalan_mallarin.Dock = System.Windows.Forms.DockStyle.Fill;
            this.son_tarix_qalan_mallarin.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.son_tarix_qalan_mallarin.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.son_tarix_qalan_mallarin.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.son_tarix_qalan_mallarin.Location = new System.Drawing.Point(3, 40);
            this.son_tarix_qalan_mallarin.Name = "son_tarix_qalan_mallarin";
            this.son_tarix_qalan_mallarin.Size = new System.Drawing.Size(282, 23);
            this.son_tarix_qalan_mallarin.TabIndex = 24;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label4.Location = new System.Drawing.Point(3, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(282, 37);
            this.label4.TabIndex = 0;
            this.label4.Text = "Son Tarix";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // gm_yenile_button1
            // 
            this.gm_yenile_button1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gm_yenile_button1.Location = new System.Drawing.Point(3, 3);
            this.gm_yenile_button1.Name = "gm_yenile_button1";
            this.gm_yenile_button1.Size = new System.Drawing.Size(288, 34);
            this.gm_yenile_button1.TabIndex = 0;
            this.gm_yenile_button1.Text = "YENILƏ";
            this.gm_yenile_button1.UseVisualStyleBackColor = true;
            this.gm_yenile_button1.Click += new System.EventHandler(this.gm_yenile_button1_Click);
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 1;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.Controls.Add(this.bas_tarix_qalan_mallarin, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.label3, 0, 0);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 43);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 2;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(288, 74);
            this.tableLayoutPanel3.TabIndex = 1;
            // 
            // bas_tarix_qalan_mallarin
            // 
            this.bas_tarix_qalan_mallarin.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.bas_tarix_qalan_mallarin.CustomFormat = "yyyy-MM-dd HH:mm:ss";
            this.bas_tarix_qalan_mallarin.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bas_tarix_qalan_mallarin.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.bas_tarix_qalan_mallarin.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.bas_tarix_qalan_mallarin.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.bas_tarix_qalan_mallarin.Location = new System.Drawing.Point(3, 40);
            this.bas_tarix_qalan_mallarin.Name = "bas_tarix_qalan_mallarin";
            this.bas_tarix_qalan_mallarin.Size = new System.Drawing.Size(282, 23);
            this.bas_tarix_qalan_mallarin.TabIndex = 23;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.Location = new System.Drawing.Point(3, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(282, 37);
            this.label3.TabIndex = 0;
            this.label3.Text = "Baş Tarix";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // gm_bugun_button1
            // 
            this.gm_bugun_button1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gm_bugun_button1.Location = new System.Drawing.Point(3, 203);
            this.gm_bugun_button1.Name = "gm_bugun_button1";
            this.gm_bugun_button1.Size = new System.Drawing.Size(288, 34);
            this.gm_bugun_button1.TabIndex = 3;
            this.gm_bugun_button1.Text = "BU GÜN";
            this.gm_bugun_button1.UseVisualStyleBackColor = true;
            this.gm_bugun_button1.Click += new System.EventHandler(this.gm_bugun_button1_Click);
            // 
            // getirilen_mallarin_umumi_siyahisi_d_g_v
            // 
            this.getirilen_mallarin_umumi_siyahisi_d_g_v.AllowUserToAddRows = false;
            this.getirilen_mallarin_umumi_siyahisi_d_g_v.AllowUserToDeleteRows = false;
            this.getirilen_mallarin_umumi_siyahisi_d_g_v.AllowUserToResizeRows = false;
            this.getirilen_mallarin_umumi_siyahisi_d_g_v.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.getirilen_mallarin_umumi_siyahisi_d_g_v.Dock = System.Windows.Forms.DockStyle.Fill;
            this.getirilen_mallarin_umumi_siyahisi_d_g_v.Location = new System.Drawing.Point(3, 243);
            this.getirilen_mallarin_umumi_siyahisi_d_g_v.MultiSelect = false;
            this.getirilen_mallarin_umumi_siyahisi_d_g_v.Name = "getirilen_mallarin_umumi_siyahisi_d_g_v";
            this.getirilen_mallarin_umumi_siyahisi_d_g_v.ReadOnly = true;
            this.getirilen_mallarin_umumi_siyahisi_d_g_v.RowHeadersVisible = false;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Consolas", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.getirilen_mallarin_umumi_siyahisi_d_g_v.RowsDefaultCellStyle = dataGridViewCellStyle3;
            this.getirilen_mallarin_umumi_siyahisi_d_g_v.Size = new System.Drawing.Size(288, 351);
            this.getirilen_mallarin_umumi_siyahisi_d_g_v.TabIndex = 4;
            this.getirilen_mallarin_umumi_siyahisi_d_g_v.MouseClick += new System.Windows.Forms.MouseEventHandler(this.getirilen_mallarin_umumi_siyahisi_d_g_v_MouseClick);
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 5;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 200F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 300F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel5.Controls.Add(this.label5, 0, 0);
            this.tableLayoutPanel5.Controls.Add(this.gm_setir_sayi_label6, 1, 0);
            this.tableLayoutPanel5.Controls.Add(this.label9, 2, 0);
            this.tableLayoutPanel5.Controls.Add(this.gm_endirimli_cem_mebleg_label10, 3, 0);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(303, 606);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 1;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(950, 44);
            this.tableLayoutPanel5.TabIndex = 2;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label5.Location = new System.Drawing.Point(3, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(94, 44);
            this.label5.TabIndex = 0;
            this.label5.Text = "Sətir sayı:";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // gm_setir_sayi_label6
            // 
            this.gm_setir_sayi_label6.AutoSize = true;
            this.gm_setir_sayi_label6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gm_setir_sayi_label6.Location = new System.Drawing.Point(103, 0);
            this.gm_setir_sayi_label6.Name = "gm_setir_sayi_label6";
            this.gm_setir_sayi_label6.Size = new System.Drawing.Size(194, 44);
            this.gm_setir_sayi_label6.TabIndex = 1;
            this.gm_setir_sayi_label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label9.Location = new System.Drawing.Point(303, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(294, 44);
            this.label9.TabIndex = 2;
            this.label9.Text = "Endirimli cəm məbləğ:";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label9.Visible = false;
            // 
            // gm_endirimli_cem_mebleg_label10
            // 
            this.gm_endirimli_cem_mebleg_label10.AutoSize = true;
            this.gm_endirimli_cem_mebleg_label10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gm_endirimli_cem_mebleg_label10.Location = new System.Drawing.Point(603, 0);
            this.gm_endirimli_cem_mebleg_label10.Name = "gm_endirimli_cem_mebleg_label10";
            this.gm_endirimli_cem_mebleg_label10.Size = new System.Drawing.Size(94, 44);
            this.gm_endirimli_cem_mebleg_label10.TabIndex = 3;
            this.gm_endirimli_cem_mebleg_label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.ColumnCount = 7;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 110F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 150F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel6.Controls.Add(this.label8, 0, 0);
            this.tableLayoutPanel6.Controls.Add(this.gm_cem_satis_meblegi_label7, 0, 0);
            this.tableLayoutPanel6.Controls.Add(this.cem_mebleg_label7_passiv, 0, 0);
            this.tableLayoutPanel6.Controls.Add(this.gm_cem_mebleg_label7, 0, 0);
            this.tableLayoutPanel6.Controls.Add(this.label6, 4, 0);
            this.tableLayoutPanel6.Controls.Add(this.gm_cem_gelir_label7, 5, 0);
            this.tableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel6.Location = new System.Drawing.Point(303, 656);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 1;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(950, 44);
            this.tableLayoutPanel6.TabIndex = 3;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(233, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(144, 44);
            this.label8.TabIndex = 4;
            this.label8.Text = "Cəm satış məbləği:";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // gm_cem_satis_meblegi_label7
            // 
            this.gm_cem_satis_meblegi_label7.AutoSize = true;
            this.gm_cem_satis_meblegi_label7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gm_cem_satis_meblegi_label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gm_cem_satis_meblegi_label7.ForeColor = System.Drawing.Color.Red;
            this.gm_cem_satis_meblegi_label7.Location = new System.Drawing.Point(383, 0);
            this.gm_cem_satis_meblegi_label7.Name = "gm_cem_satis_meblegi_label7";
            this.gm_cem_satis_meblegi_label7.Size = new System.Drawing.Size(114, 44);
            this.gm_cem_satis_meblegi_label7.TabIndex = 3;
            this.gm_cem_satis_meblegi_label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cem_mebleg_label7_passiv
            // 
            this.cem_mebleg_label7_passiv.AutoSize = true;
            this.cem_mebleg_label7_passiv.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cem_mebleg_label7_passiv.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cem_mebleg_label7_passiv.Location = new System.Drawing.Point(3, 0);
            this.cem_mebleg_label7_passiv.Name = "cem_mebleg_label7_passiv";
            this.cem_mebleg_label7_passiv.Size = new System.Drawing.Size(104, 44);
            this.cem_mebleg_label7_passiv.TabIndex = 2;
            this.cem_mebleg_label7_passiv.Text = "Cəm məbləğ:";
            this.cem_mebleg_label7_passiv.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // gm_cem_mebleg_label7
            // 
            this.gm_cem_mebleg_label7.AutoSize = true;
            this.gm_cem_mebleg_label7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gm_cem_mebleg_label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gm_cem_mebleg_label7.ForeColor = System.Drawing.Color.Red;
            this.gm_cem_mebleg_label7.Location = new System.Drawing.Point(113, 0);
            this.gm_cem_mebleg_label7.Name = "gm_cem_mebleg_label7";
            this.gm_cem_mebleg_label7.Size = new System.Drawing.Size(114, 44);
            this.gm_cem_mebleg_label7.TabIndex = 1;
            this.gm_cem_mebleg_label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(503, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(94, 44);
            this.label6.TabIndex = 5;
            this.label6.Text = "Cəm gəlir:";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // gm_cem_gelir_label7
            // 
            this.gm_cem_gelir_label7.AutoSize = true;
            this.gm_cem_gelir_label7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gm_cem_gelir_label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gm_cem_gelir_label7.ForeColor = System.Drawing.Color.Red;
            this.gm_cem_gelir_label7.Location = new System.Drawing.Point(603, 0);
            this.gm_cem_gelir_label7.Name = "gm_cem_gelir_label7";
            this.gm_cem_gelir_label7.Size = new System.Drawing.Size(114, 44);
            this.gm_cem_gelir_label7.TabIndex = 6;
            this.gm_cem_gelir_label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel17
            // 
            this.tableLayoutPanel17.ColumnCount = 2;
            this.tableLayoutPanel17.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel17.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel17.Controls.Add(this.label37, 0, 0);
            this.tableLayoutPanel17.Controls.Add(this.gm_mdcem_label40, 1, 0);
            this.tableLayoutPanel17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel17.Location = new System.Drawing.Point(3, 606);
            this.tableLayoutPanel17.Name = "tableLayoutPanel17";
            this.tableLayoutPanel17.RowCount = 1;
            this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 44F));
            this.tableLayoutPanel17.Size = new System.Drawing.Size(294, 44);
            this.tableLayoutPanel17.TabIndex = 4;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label37.Location = new System.Drawing.Point(3, 0);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(141, 44);
            this.label37.TabIndex = 0;
            this.label37.Text = "Məbləğ:";
            this.label37.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // gm_mdcem_label40
            // 
            this.gm_mdcem_label40.AutoSize = true;
            this.gm_mdcem_label40.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gm_mdcem_label40.ForeColor = System.Drawing.Color.Red;
            this.gm_mdcem_label40.Location = new System.Drawing.Point(150, 0);
            this.gm_mdcem_label40.Name = "gm_mdcem_label40";
            this.gm_mdcem_label40.Size = new System.Drawing.Size(141, 44);
            this.gm_mdcem_label40.TabIndex = 1;
            this.gm_mdcem_label40.Text = ":::";
            this.gm_mdcem_label40.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel18
            // 
            this.tableLayoutPanel18.ColumnCount = 2;
            this.tableLayoutPanel18.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel18.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel18.Controls.Add(this.label39, 0, 0);
            this.tableLayoutPanel18.Controls.Add(this.gm_sqcem_label40, 1, 0);
            this.tableLayoutPanel18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel18.Location = new System.Drawing.Point(3, 656);
            this.tableLayoutPanel18.Name = "tableLayoutPanel18";
            this.tableLayoutPanel18.RowCount = 1;
            this.tableLayoutPanel18.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel18.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 44F));
            this.tableLayoutPanel18.Size = new System.Drawing.Size(294, 44);
            this.tableLayoutPanel18.TabIndex = 5;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label39.Location = new System.Drawing.Point(3, 0);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(141, 44);
            this.label39.TabIndex = 0;
            this.label39.Text = "Satış:";
            this.label39.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // gm_sqcem_label40
            // 
            this.gm_sqcem_label40.AutoSize = true;
            this.gm_sqcem_label40.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gm_sqcem_label40.ForeColor = System.Drawing.Color.Red;
            this.gm_sqcem_label40.Location = new System.Drawing.Point(150, 0);
            this.gm_sqcem_label40.Name = "gm_sqcem_label40";
            this.gm_sqcem_label40.Size = new System.Drawing.Size(141, 44);
            this.gm_sqcem_label40.TabIndex = 1;
            this.gm_sqcem_label40.Text = ":::";
            this.gm_sqcem_label40.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // hesabat_tabPage1
            // 
            this.hesabat_tabPage1.Controls.Add(this.hesabat_tabControl1);
            this.hesabat_tabPage1.Location = new System.Drawing.Point(4, 29);
            this.hesabat_tabPage1.Name = "hesabat_tabPage1";
            this.hesabat_tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.hesabat_tabPage1.Size = new System.Drawing.Size(1276, 748);
            this.hesabat_tabPage1.TabIndex = 3;
            this.hesabat_tabPage1.Text = "HESABAT";
            this.hesabat_tabPage1.UseVisualStyleBackColor = true;
            // 
            // hesabat_tabControl1
            // 
            this.hesabat_tabControl1.Controls.Add(this.hesabat_kassa_tabPage1);
            this.hesabat_tabControl1.Controls.Add(this.hesabat_bonus_kartlari_tabPage1);
            this.hesabat_tabControl1.Controls.Add(this.kassada_silinen_mallar_tabPage1);
            this.hesabat_tabControl1.Controls.Add(this.hesabat_malin_qaytarilmasi_tabPage1);
            this.hesabat_tabControl1.Controls.Add(this.hesabat_borclular_tabPage1);
            this.hesabat_tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.hesabat_tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hesabat_tabControl1.Location = new System.Drawing.Point(3, 3);
            this.hesabat_tabControl1.Name = "hesabat_tabControl1";
            this.hesabat_tabControl1.SelectedIndex = 0;
            this.hesabat_tabControl1.Size = new System.Drawing.Size(1270, 742);
            this.hesabat_tabControl1.TabIndex = 0;
            // 
            // hesabat_kassa_tabPage1
            // 
            this.hesabat_kassa_tabPage1.Controls.Add(this.hesabat_kassa_tableLayoutPanel1);
            this.hesabat_kassa_tabPage1.Location = new System.Drawing.Point(4, 25);
            this.hesabat_kassa_tabPage1.Name = "hesabat_kassa_tabPage1";
            this.hesabat_kassa_tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.hesabat_kassa_tabPage1.Size = new System.Drawing.Size(1262, 713);
            this.hesabat_kassa_tabPage1.TabIndex = 0;
            this.hesabat_kassa_tabPage1.Text = "Kassa";
            this.hesabat_kassa_tabPage1.UseVisualStyleBackColor = true;
            // 
            // hesabat_kassa_tableLayoutPanel1
            // 
            this.hesabat_kassa_tableLayoutPanel1.ColumnCount = 1;
            this.hesabat_kassa_tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.hesabat_kassa_tableLayoutPanel1.Controls.Add(this.hesabat_esas_dgv, 0, 1);
            this.hesabat_kassa_tableLayoutPanel1.Controls.Add(this.panel1, 0, 0);
            this.hesabat_kassa_tableLayoutPanel1.Controls.Add(this.tableLayoutPanel1, 0, 2);
            this.hesabat_kassa_tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.hesabat_kassa_tableLayoutPanel1.Location = new System.Drawing.Point(3, 3);
            this.hesabat_kassa_tableLayoutPanel1.Name = "hesabat_kassa_tableLayoutPanel1";
            this.hesabat_kassa_tableLayoutPanel1.RowCount = 3;
            this.hesabat_kassa_tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.hesabat_kassa_tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.hesabat_kassa_tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.hesabat_kassa_tableLayoutPanel1.Size = new System.Drawing.Size(1256, 707);
            this.hesabat_kassa_tableLayoutPanel1.TabIndex = 0;
            // 
            // hesabat_esas_dgv
            // 
            this.hesabat_esas_dgv.AllowUserToAddRows = false;
            this.hesabat_esas_dgv.AllowUserToDeleteRows = false;
            this.hesabat_esas_dgv.AllowUserToOrderColumns = true;
            this.hesabat_esas_dgv.AllowUserToResizeRows = false;
            this.hesabat_esas_dgv.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.hesabat_esas_dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.hesabat_esas_dgv.Dock = System.Windows.Forms.DockStyle.Fill;
            this.hesabat_esas_dgv.Location = new System.Drawing.Point(3, 103);
            this.hesabat_esas_dgv.MultiSelect = false;
            this.hesabat_esas_dgv.Name = "hesabat_esas_dgv";
            this.hesabat_esas_dgv.ReadOnly = true;
            this.hesabat_esas_dgv.RowHeadersVisible = false;
            this.hesabat_esas_dgv.Size = new System.Drawing.Size(1250, 501);
            this.hesabat_esas_dgv.TabIndex = 0;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.mal_ktleri_combobox_hesabat);
            this.panel1.Controls.Add(this.hesabat_bugun_button1);
            this.panel1.Controls.Add(this.hesabat_satis_tipi_comboBox1);
            this.panel1.Controls.Add(this.evvel_label);
            this.panel1.Controls.Add(this.son_label);
            this.panel1.Controls.Add(this.tarix_araligi_duymesi_hesabat);
            this.panel1.Controls.Add(this.bas_tarix_hesabat);
            this.panel1.Controls.Add(this.son_tarix_hesabat);
            this.panel1.Controls.Add(this.axtar_text_hesabat);
            this.panel1.Controls.Add(this.mal_tipleri_combobox_hesabat);
            this.panel1.Controls.Add(this.kassalar_combobox_hesabat);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1250, 94);
            this.panel1.TabIndex = 1;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(287, 15);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(45, 17);
            this.label10.TabIndex = 54;
            this.label10.Text = "Axtar";
            // 
            // mal_ktleri_combobox_hesabat
            // 
            this.mal_ktleri_combobox_hesabat.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.mal_ktleri_combobox_hesabat.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.mal_ktleri_combobox_hesabat.FormattingEnabled = true;
            this.mal_ktleri_combobox_hesabat.Items.AddRange(new object[] {
            "Mal kateqoriyaları"});
            this.mal_ktleri_combobox_hesabat.Location = new System.Drawing.Point(97, 50);
            this.mal_ktleri_combobox_hesabat.Name = "mal_ktleri_combobox_hesabat";
            this.mal_ktleri_combobox_hesabat.Size = new System.Drawing.Size(144, 21);
            this.mal_ktleri_combobox_hesabat.TabIndex = 53;
            // 
            // hesabat_bugun_button1
            // 
            this.hesabat_bugun_button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.hesabat_bugun_button1.ForeColor = System.Drawing.Color.Maroon;
            this.hesabat_bugun_button1.Location = new System.Drawing.Point(912, 18);
            this.hesabat_bugun_button1.Name = "hesabat_bugun_button1";
            this.hesabat_bugun_button1.Size = new System.Drawing.Size(101, 51);
            this.hesabat_bugun_button1.TabIndex = 51;
            this.hesabat_bugun_button1.Text = "Bu gün";
            this.hesabat_bugun_button1.UseVisualStyleBackColor = true;
            this.hesabat_bugun_button1.Click += new System.EventHandler(this.hesabat_bugun_button1_Click);
            // 
            // hesabat_satis_tipi_comboBox1
            // 
            this.hesabat_satis_tipi_comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.hesabat_satis_tipi_comboBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.hesabat_satis_tipi_comboBox1.FormattingEnabled = true;
            this.hesabat_satis_tipi_comboBox1.Items.AddRange(new object[] {
            "Satış tipi",
            "1-Satış",
            "2-Qaytarış"});
            this.hesabat_satis_tipi_comboBox1.Location = new System.Drawing.Point(663, 9);
            this.hesabat_satis_tipi_comboBox1.Name = "hesabat_satis_tipi_comboBox1";
            this.hesabat_satis_tipi_comboBox1.Size = new System.Drawing.Size(144, 21);
            this.hesabat_satis_tipi_comboBox1.TabIndex = 50;
            // 
            // evvel_label
            // 
            this.evvel_label.AutoSize = true;
            this.evvel_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.evvel_label.Location = new System.Drawing.Point(388, 9);
            this.evvel_label.Name = "evvel_label";
            this.evvel_label.Size = new System.Drawing.Size(83, 17);
            this.evvel_label.TabIndex = 48;
            this.evvel_label.Text = "Başlanğıc:";
            // 
            // son_label
            // 
            this.son_label.AutoSize = true;
            this.son_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.son_label.Location = new System.Drawing.Point(430, 46);
            this.son_label.Name = "son_label";
            this.son_label.Size = new System.Drawing.Size(41, 17);
            this.son_label.TabIndex = 47;
            this.son_label.Text = "Son:";
            // 
            // tarix_araligi_duymesi_hesabat
            // 
            this.tarix_araligi_duymesi_hesabat.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tarix_araligi_duymesi_hesabat.ForeColor = System.Drawing.Color.Maroon;
            this.tarix_araligi_duymesi_hesabat.Location = new System.Drawing.Point(826, 17);
            this.tarix_araligi_duymesi_hesabat.Name = "tarix_araligi_duymesi_hesabat";
            this.tarix_araligi_duymesi_hesabat.Size = new System.Drawing.Size(69, 51);
            this.tarix_araligi_duymesi_hesabat.TabIndex = 46;
            this.tarix_araligi_duymesi_hesabat.Text = "OK";
            this.tarix_araligi_duymesi_hesabat.UseVisualStyleBackColor = true;
            this.tarix_araligi_duymesi_hesabat.Click += new System.EventHandler(this.tarix_araligi_duymesi_hesabat_Click);
            // 
            // bas_tarix_hesabat
            // 
            this.bas_tarix_hesabat.CustomFormat = "yyyy-MM-dd HH:mm:ss";
            this.bas_tarix_hesabat.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bas_tarix_hesabat.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.bas_tarix_hesabat.Location = new System.Drawing.Point(483, 9);
            this.bas_tarix_hesabat.Name = "bas_tarix_hesabat";
            this.bas_tarix_hesabat.Size = new System.Drawing.Size(164, 23);
            this.bas_tarix_hesabat.TabIndex = 45;
            // 
            // son_tarix_hesabat
            // 
            this.son_tarix_hesabat.CustomFormat = "yyyy-MM-dd HH:mm:ss";
            this.son_tarix_hesabat.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.son_tarix_hesabat.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.son_tarix_hesabat.Location = new System.Drawing.Point(483, 46);
            this.son_tarix_hesabat.Name = "son_tarix_hesabat";
            this.son_tarix_hesabat.Size = new System.Drawing.Size(164, 23);
            this.son_tarix_hesabat.TabIndex = 44;
            // 
            // axtar_text_hesabat
            // 
            this.axtar_text_hesabat.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.axtar_text_hesabat.Location = new System.Drawing.Point(254, 50);
            this.axtar_text_hesabat.Name = "axtar_text_hesabat";
            this.axtar_text_hesabat.Size = new System.Drawing.Size(119, 23);
            this.axtar_text_hesabat.TabIndex = 41;
            // 
            // mal_tipleri_combobox_hesabat
            // 
            this.mal_tipleri_combobox_hesabat.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.mal_tipleri_combobox_hesabat.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.mal_tipleri_combobox_hesabat.FormattingEnabled = true;
            this.mal_tipleri_combobox_hesabat.Items.AddRange(new object[] {
            "Mal tipləri",
            "1-Say",
            "2-Uzunluq",
            "3-Çəki",
            "4-Dənəli"});
            this.mal_tipleri_combobox_hesabat.Location = new System.Drawing.Point(97, 12);
            this.mal_tipleri_combobox_hesabat.Name = "mal_tipleri_combobox_hesabat";
            this.mal_tipleri_combobox_hesabat.Size = new System.Drawing.Size(144, 21);
            this.mal_tipleri_combobox_hesabat.TabIndex = 35;
            // 
            // kassalar_combobox_hesabat
            // 
            this.kassalar_combobox_hesabat.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.kassalar_combobox_hesabat.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.kassalar_combobox_hesabat.FormattingEnabled = true;
            this.kassalar_combobox_hesabat.Items.AddRange(new object[] {
            "Kassalar"});
            this.kassalar_combobox_hesabat.Location = new System.Drawing.Point(11, 12);
            this.kassalar_combobox_hesabat.Name = "kassalar_combobox_hesabat";
            this.kassalar_combobox_hesabat.Size = new System.Drawing.Size(71, 21);
            this.kassalar_combobox_hesabat.TabIndex = 32;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 8;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 160F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 160F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.cesid_sayi_label, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.umumi_say_label, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.umumi_say_label_aktiv, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.cesid_sayi_label_aktiv, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.label1, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.label2, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.hesabat_satis_cemi_aktiv_label3, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.hesabat_gelir_cemi_aktiv_label3, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.hesabat_cedveli_cap_et_button1, 4, 0);
            this.tableLayoutPanel1.Controls.Add(this.hesabat_kassani_bagla_button1, 4, 1);
            this.tableLayoutPanel1.Controls.Add(this.label60, 5, 0);
            this.tableLayoutPanel1.Controls.Add(this.hesabat_satis_cemi_endirimli_aktiv_label3, 6, 0);
            this.tableLayoutPanel1.Controls.Add(this.label61, 5, 1);
            this.tableLayoutPanel1.Controls.Add(this.kassa_endirim_meblegi_label62, 6, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(3, 610);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1250, 94);
            this.tableLayoutPanel1.TabIndex = 2;
            // 
            // cesid_sayi_label
            // 
            this.cesid_sayi_label.AutoSize = true;
            this.cesid_sayi_label.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cesid_sayi_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cesid_sayi_label.Location = new System.Drawing.Point(3, 47);
            this.cesid_sayi_label.Name = "cesid_sayi_label";
            this.cesid_sayi_label.Size = new System.Drawing.Size(114, 47);
            this.cesid_sayi_label.TabIndex = 43;
            this.cesid_sayi_label.Text = "Çeşid sayı:";
            this.cesid_sayi_label.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // umumi_say_label
            // 
            this.umumi_say_label.AutoSize = true;
            this.umumi_say_label.Dock = System.Windows.Forms.DockStyle.Fill;
            this.umumi_say_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.umumi_say_label.Location = new System.Drawing.Point(3, 0);
            this.umumi_say_label.Name = "umumi_say_label";
            this.umumi_say_label.Size = new System.Drawing.Size(114, 47);
            this.umumi_say_label.TabIndex = 42;
            this.umumi_say_label.Text = "Ümumi say:";
            this.umumi_say_label.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // umumi_say_label_aktiv
            // 
            this.umumi_say_label_aktiv.AutoSize = true;
            this.umumi_say_label_aktiv.Dock = System.Windows.Forms.DockStyle.Fill;
            this.umumi_say_label_aktiv.Location = new System.Drawing.Point(123, 0);
            this.umumi_say_label_aktiv.Name = "umumi_say_label_aktiv";
            this.umumi_say_label_aktiv.Size = new System.Drawing.Size(114, 47);
            this.umumi_say_label_aktiv.TabIndex = 44;
            this.umumi_say_label_aktiv.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cesid_sayi_label_aktiv
            // 
            this.cesid_sayi_label_aktiv.AutoSize = true;
            this.cesid_sayi_label_aktiv.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cesid_sayi_label_aktiv.Location = new System.Drawing.Point(123, 47);
            this.cesid_sayi_label_aktiv.Name = "cesid_sayi_label_aktiv";
            this.cesid_sayi_label_aktiv.Size = new System.Drawing.Size(114, 47);
            this.cesid_sayi_label_aktiv.TabIndex = 45;
            this.cesid_sayi_label_aktiv.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.label1.Location = new System.Drawing.Point(243, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(114, 47);
            this.label1.TabIndex = 46;
            this.label1.Text = "Satış cəmi:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.label2.Location = new System.Drawing.Point(243, 47);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(114, 47);
            this.label2.TabIndex = 47;
            this.label2.Text = "Gəlir cəmi:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // hesabat_satis_cemi_aktiv_label3
            // 
            this.hesabat_satis_cemi_aktiv_label3.AutoSize = true;
            this.hesabat_satis_cemi_aktiv_label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.hesabat_satis_cemi_aktiv_label3.Location = new System.Drawing.Point(363, 0);
            this.hesabat_satis_cemi_aktiv_label3.Name = "hesabat_satis_cemi_aktiv_label3";
            this.hesabat_satis_cemi_aktiv_label3.Size = new System.Drawing.Size(154, 47);
            this.hesabat_satis_cemi_aktiv_label3.TabIndex = 48;
            this.hesabat_satis_cemi_aktiv_label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // hesabat_gelir_cemi_aktiv_label3
            // 
            this.hesabat_gelir_cemi_aktiv_label3.AutoSize = true;
            this.hesabat_gelir_cemi_aktiv_label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.hesabat_gelir_cemi_aktiv_label3.Location = new System.Drawing.Point(363, 47);
            this.hesabat_gelir_cemi_aktiv_label3.Name = "hesabat_gelir_cemi_aktiv_label3";
            this.hesabat_gelir_cemi_aktiv_label3.Size = new System.Drawing.Size(154, 47);
            this.hesabat_gelir_cemi_aktiv_label3.TabIndex = 49;
            this.hesabat_gelir_cemi_aktiv_label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // hesabat_cedveli_cap_et_button1
            // 
            this.hesabat_cedveli_cap_et_button1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.hesabat_cedveli_cap_et_button1.Location = new System.Drawing.Point(523, 3);
            this.hesabat_cedveli_cap_et_button1.Name = "hesabat_cedveli_cap_et_button1";
            this.hesabat_cedveli_cap_et_button1.Size = new System.Drawing.Size(154, 41);
            this.hesabat_cedveli_cap_et_button1.TabIndex = 50;
            this.hesabat_cedveli_cap_et_button1.Text = "Çap et";
            this.hesabat_cedveli_cap_et_button1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.hesabat_cedveli_cap_et_button1.UseVisualStyleBackColor = true;
            this.hesabat_cedveli_cap_et_button1.Visible = false;
            this.hesabat_cedveli_cap_et_button1.Click += new System.EventHandler(this.hesabat_cedveli_cap_et_button1_Click);
            // 
            // hesabat_kassani_bagla_button1
            // 
            this.hesabat_kassani_bagla_button1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.hesabat_kassani_bagla_button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hesabat_kassani_bagla_button1.Location = new System.Drawing.Point(523, 50);
            this.hesabat_kassani_bagla_button1.Name = "hesabat_kassani_bagla_button1";
            this.hesabat_kassani_bagla_button1.Size = new System.Drawing.Size(154, 41);
            this.hesabat_kassani_bagla_button1.TabIndex = 51;
            this.hesabat_kassani_bagla_button1.Text = "Kassanı bağla";
            this.hesabat_kassani_bagla_button1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.hesabat_kassani_bagla_button1.UseVisualStyleBackColor = true;
            this.hesabat_kassani_bagla_button1.Click += new System.EventHandler(this.hesabat_kassani_bagla_button1_Click);
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label60.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label60.Location = new System.Drawing.Point(683, 0);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(114, 47);
            this.label60.TabIndex = 52;
            this.label60.Text = "Satış cəmi (En):";
            this.label60.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // hesabat_satis_cemi_endirimli_aktiv_label3
            // 
            this.hesabat_satis_cemi_endirimli_aktiv_label3.AutoSize = true;
            this.hesabat_satis_cemi_endirimli_aktiv_label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.hesabat_satis_cemi_endirimli_aktiv_label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hesabat_satis_cemi_endirimli_aktiv_label3.Location = new System.Drawing.Point(803, 0);
            this.hesabat_satis_cemi_endirimli_aktiv_label3.Name = "hesabat_satis_cemi_endirimli_aktiv_label3";
            this.hesabat_satis_cemi_endirimli_aktiv_label3.Size = new System.Drawing.Size(114, 47);
            this.hesabat_satis_cemi_endirimli_aktiv_label3.TabIndex = 53;
            this.hesabat_satis_cemi_endirimli_aktiv_label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label61.Location = new System.Drawing.Point(683, 47);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(114, 47);
            this.label61.TabIndex = 54;
            this.label61.Text = "Endirim:";
            this.label61.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // kassa_endirim_meblegi_label62
            // 
            this.kassa_endirim_meblegi_label62.AutoSize = true;
            this.kassa_endirim_meblegi_label62.Dock = System.Windows.Forms.DockStyle.Fill;
            this.kassa_endirim_meblegi_label62.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kassa_endirim_meblegi_label62.Location = new System.Drawing.Point(803, 47);
            this.kassa_endirim_meblegi_label62.Name = "kassa_endirim_meblegi_label62";
            this.kassa_endirim_meblegi_label62.Size = new System.Drawing.Size(114, 47);
            this.kassa_endirim_meblegi_label62.TabIndex = 55;
            this.kassa_endirim_meblegi_label62.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // hesabat_bonus_kartlari_tabPage1
            // 
            this.hesabat_bonus_kartlari_tabPage1.Controls.Add(this.tableLayoutPanel10);
            this.hesabat_bonus_kartlari_tabPage1.Location = new System.Drawing.Point(4, 25);
            this.hesabat_bonus_kartlari_tabPage1.Name = "hesabat_bonus_kartlari_tabPage1";
            this.hesabat_bonus_kartlari_tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.hesabat_bonus_kartlari_tabPage1.Size = new System.Drawing.Size(1262, 713);
            this.hesabat_bonus_kartlari_tabPage1.TabIndex = 1;
            this.hesabat_bonus_kartlari_tabPage1.Text = "Bonus kartları silinmələr";
            this.hesabat_bonus_kartlari_tabPage1.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel10
            // 
            this.tableLayoutPanel10.ColumnCount = 1;
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel10.Controls.Add(this.abk_silinme_dgv, 0, 1);
            this.tableLayoutPanel10.Controls.Add(this.panel2, 0, 0);
            this.tableLayoutPanel10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel10.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel10.Name = "tableLayoutPanel10";
            this.tableLayoutPanel10.RowCount = 2;
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel10.Size = new System.Drawing.Size(1256, 707);
            this.tableLayoutPanel10.TabIndex = 1;
            // 
            // abk_silinme_dgv
            // 
            this.abk_silinme_dgv.AllowUserToAddRows = false;
            this.abk_silinme_dgv.AllowUserToDeleteRows = false;
            this.abk_silinme_dgv.AllowUserToOrderColumns = true;
            this.abk_silinme_dgv.AllowUserToResizeRows = false;
            this.abk_silinme_dgv.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.abk_silinme_dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.abk_silinme_dgv.Dock = System.Windows.Forms.DockStyle.Fill;
            this.abk_silinme_dgv.Location = new System.Drawing.Point(3, 103);
            this.abk_silinme_dgv.MultiSelect = false;
            this.abk_silinme_dgv.Name = "abk_silinme_dgv";
            this.abk_silinme_dgv.ReadOnly = true;
            this.abk_silinme_dgv.RowHeadersVisible = false;
            this.abk_silinme_dgv.Size = new System.Drawing.Size(1250, 601);
            this.abk_silinme_dgv.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label15);
            this.panel2.Controls.Add(this.label16);
            this.panel2.Controls.Add(this.bonus_silinme_ok_button2);
            this.panel2.Controls.Add(this.abk_silinme_bas_dateTimePicker1);
            this.panel2.Controls.Add(this.abk_silinme_son_dateTimePicker1);
            this.panel2.Controls.Add(this.label19);
            this.panel2.Controls.Add(this.abk_silinme_axtar_textBox1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(3, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1250, 94);
            this.panel2.TabIndex = 1;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(166, 15);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(83, 17);
            this.label15.TabIndex = 48;
            this.label15.Text = "Başlanğıc:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(208, 52);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(41, 17);
            this.label16.TabIndex = 47;
            this.label16.Text = "Son:";
            // 
            // bonus_silinme_ok_button2
            // 
            this.bonus_silinme_ok_button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.bonus_silinme_ok_button2.ForeColor = System.Drawing.Color.Maroon;
            this.bonus_silinme_ok_button2.Location = new System.Drawing.Point(455, 23);
            this.bonus_silinme_ok_button2.Name = "bonus_silinme_ok_button2";
            this.bonus_silinme_ok_button2.Size = new System.Drawing.Size(69, 51);
            this.bonus_silinme_ok_button2.TabIndex = 46;
            this.bonus_silinme_ok_button2.Text = "OK";
            this.bonus_silinme_ok_button2.UseVisualStyleBackColor = true;
            this.bonus_silinme_ok_button2.Click += new System.EventHandler(this.bonus_silinme_ok_button2_Click);
            // 
            // abk_silinme_bas_dateTimePicker1
            // 
            this.abk_silinme_bas_dateTimePicker1.CustomFormat = "yyyy-MM-dd HH:mm:ss";
            this.abk_silinme_bas_dateTimePicker1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.abk_silinme_bas_dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.abk_silinme_bas_dateTimePicker1.Location = new System.Drawing.Point(261, 15);
            this.abk_silinme_bas_dateTimePicker1.Name = "abk_silinme_bas_dateTimePicker1";
            this.abk_silinme_bas_dateTimePicker1.Size = new System.Drawing.Size(164, 23);
            this.abk_silinme_bas_dateTimePicker1.TabIndex = 45;
            // 
            // abk_silinme_son_dateTimePicker1
            // 
            this.abk_silinme_son_dateTimePicker1.CustomFormat = "yyyy-MM-dd HH:mm:ss";
            this.abk_silinme_son_dateTimePicker1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.abk_silinme_son_dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.abk_silinme_son_dateTimePicker1.Location = new System.Drawing.Point(261, 52);
            this.abk_silinme_son_dateTimePicker1.Name = "abk_silinme_son_dateTimePicker1";
            this.abk_silinme_son_dateTimePicker1.Size = new System.Drawing.Size(164, 23);
            this.abk_silinme_son_dateTimePicker1.TabIndex = 44;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.DarkViolet;
            this.label19.Location = new System.Drawing.Point(32, 15);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(45, 17);
            this.label19.TabIndex = 42;
            this.label19.Text = "Axtar";
            // 
            // abk_silinme_axtar_textBox1
            // 
            this.abk_silinme_axtar_textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.abk_silinme_axtar_textBox1.Location = new System.Drawing.Point(32, 43);
            this.abk_silinme_axtar_textBox1.Name = "abk_silinme_axtar_textBox1";
            this.abk_silinme_axtar_textBox1.Size = new System.Drawing.Size(119, 23);
            this.abk_silinme_axtar_textBox1.TabIndex = 41;
            // 
            // kassada_silinen_mallar_tabPage1
            // 
            this.kassada_silinen_mallar_tabPage1.Controls.Add(this.kassada_silinen_esas_tableLayoutPanel12);
            this.kassada_silinen_mallar_tabPage1.Location = new System.Drawing.Point(4, 25);
            this.kassada_silinen_mallar_tabPage1.Name = "kassada_silinen_mallar_tabPage1";
            this.kassada_silinen_mallar_tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.kassada_silinen_mallar_tabPage1.Size = new System.Drawing.Size(1262, 713);
            this.kassada_silinen_mallar_tabPage1.TabIndex = 2;
            this.kassada_silinen_mallar_tabPage1.Text = "Kassada silinən mallar";
            this.kassada_silinen_mallar_tabPage1.UseVisualStyleBackColor = true;
            this.kassada_silinen_mallar_tabPage1.Click += new System.EventHandler(this.kassada_silinen_mallar_tabPage1_Click);
            // 
            // kassada_silinen_esas_tableLayoutPanel12
            // 
            this.kassada_silinen_esas_tableLayoutPanel12.ColumnCount = 1;
            this.kassada_silinen_esas_tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.kassada_silinen_esas_tableLayoutPanel12.Controls.Add(this.kassada_silinenler_dgv, 0, 1);
            this.kassada_silinen_esas_tableLayoutPanel12.Controls.Add(this.kassada_silinen_panel3, 0, 0);
            this.kassada_silinen_esas_tableLayoutPanel12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.kassada_silinen_esas_tableLayoutPanel12.Location = new System.Drawing.Point(3, 3);
            this.kassada_silinen_esas_tableLayoutPanel12.Name = "kassada_silinen_esas_tableLayoutPanel12";
            this.kassada_silinen_esas_tableLayoutPanel12.RowCount = 3;
            this.kassada_silinen_esas_tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.kassada_silinen_esas_tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.kassada_silinen_esas_tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.kassada_silinen_esas_tableLayoutPanel12.Size = new System.Drawing.Size(1256, 707);
            this.kassada_silinen_esas_tableLayoutPanel12.TabIndex = 1;
            // 
            // kassada_silinenler_dgv
            // 
            this.kassada_silinenler_dgv.AllowUserToAddRows = false;
            this.kassada_silinenler_dgv.AllowUserToDeleteRows = false;
            this.kassada_silinenler_dgv.AllowUserToOrderColumns = true;
            this.kassada_silinenler_dgv.AllowUserToResizeRows = false;
            this.kassada_silinenler_dgv.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.kassada_silinenler_dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.kassada_silinenler_dgv.Dock = System.Windows.Forms.DockStyle.Fill;
            this.kassada_silinenler_dgv.Location = new System.Drawing.Point(3, 103);
            this.kassada_silinenler_dgv.MultiSelect = false;
            this.kassada_silinenler_dgv.Name = "kassada_silinenler_dgv";
            this.kassada_silinenler_dgv.ReadOnly = true;
            this.kassada_silinenler_dgv.RowHeadersVisible = false;
            this.kassada_silinenler_dgv.Size = new System.Drawing.Size(1250, 581);
            this.kassada_silinenler_dgv.TabIndex = 0;
            // 
            // kassada_silinen_panel3
            // 
            this.kassada_silinen_panel3.Controls.Add(this.label21);
            this.kassada_silinen_panel3.Controls.Add(this.label22);
            this.kassada_silinen_panel3.Controls.Add(this.kassaad_silinen_ok_button2);
            this.kassada_silinen_panel3.Controls.Add(this.kassada_silinen_bas_dateTimePicker1);
            this.kassada_silinen_panel3.Controls.Add(this.kassada_silinen_son_dateTimePicker1);
            this.kassada_silinen_panel3.Controls.Add(this.kassada_silinenler_kassalar_comboBox3);
            this.kassada_silinen_panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.kassada_silinen_panel3.Location = new System.Drawing.Point(3, 3);
            this.kassada_silinen_panel3.Name = "kassada_silinen_panel3";
            this.kassada_silinen_panel3.Size = new System.Drawing.Size(1250, 94);
            this.kassada_silinen_panel3.TabIndex = 1;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(114, 12);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(83, 17);
            this.label21.TabIndex = 48;
            this.label21.Text = "Başlanğıc:";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(156, 49);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(41, 17);
            this.label22.TabIndex = 47;
            this.label22.Text = "Son:";
            // 
            // kassaad_silinen_ok_button2
            // 
            this.kassaad_silinen_ok_button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.kassaad_silinen_ok_button2.ForeColor = System.Drawing.Color.Maroon;
            this.kassaad_silinen_ok_button2.Location = new System.Drawing.Point(388, 15);
            this.kassaad_silinen_ok_button2.Name = "kassaad_silinen_ok_button2";
            this.kassaad_silinen_ok_button2.Size = new System.Drawing.Size(69, 51);
            this.kassaad_silinen_ok_button2.TabIndex = 46;
            this.kassaad_silinen_ok_button2.Text = "OK";
            this.kassaad_silinen_ok_button2.UseVisualStyleBackColor = true;
            this.kassaad_silinen_ok_button2.Click += new System.EventHandler(this.kassaad_silinen_ok_button2_Click);
            // 
            // kassada_silinen_bas_dateTimePicker1
            // 
            this.kassada_silinen_bas_dateTimePicker1.CustomFormat = "yyyy-MM-dd HH:mm:ss";
            this.kassada_silinen_bas_dateTimePicker1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kassada_silinen_bas_dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.kassada_silinen_bas_dateTimePicker1.Location = new System.Drawing.Point(209, 12);
            this.kassada_silinen_bas_dateTimePicker1.Name = "kassada_silinen_bas_dateTimePicker1";
            this.kassada_silinen_bas_dateTimePicker1.Size = new System.Drawing.Size(164, 23);
            this.kassada_silinen_bas_dateTimePicker1.TabIndex = 45;
            // 
            // kassada_silinen_son_dateTimePicker1
            // 
            this.kassada_silinen_son_dateTimePicker1.CustomFormat = "yyyy-MM-dd HH:mm:ss";
            this.kassada_silinen_son_dateTimePicker1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kassada_silinen_son_dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.kassada_silinen_son_dateTimePicker1.Location = new System.Drawing.Point(209, 49);
            this.kassada_silinen_son_dateTimePicker1.Name = "kassada_silinen_son_dateTimePicker1";
            this.kassada_silinen_son_dateTimePicker1.Size = new System.Drawing.Size(164, 23);
            this.kassada_silinen_son_dateTimePicker1.TabIndex = 44;
            // 
            // kassada_silinenler_kassalar_comboBox3
            // 
            this.kassada_silinenler_kassalar_comboBox3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.kassada_silinenler_kassalar_comboBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.kassada_silinenler_kassalar_comboBox3.FormattingEnabled = true;
            this.kassada_silinenler_kassalar_comboBox3.Items.AddRange(new object[] {
            "Kassalar"});
            this.kassada_silinenler_kassalar_comboBox3.Location = new System.Drawing.Point(12, 15);
            this.kassada_silinenler_kassalar_comboBox3.Name = "kassada_silinenler_kassalar_comboBox3";
            this.kassada_silinenler_kassalar_comboBox3.Size = new System.Drawing.Size(71, 21);
            this.kassada_silinenler_kassalar_comboBox3.TabIndex = 32;
            // 
            // hesabat_malin_qaytarilmasi_tabPage1
            // 
            this.hesabat_malin_qaytarilmasi_tabPage1.Controls.Add(this.tableLayoutPanel15);
            this.hesabat_malin_qaytarilmasi_tabPage1.Location = new System.Drawing.Point(4, 25);
            this.hesabat_malin_qaytarilmasi_tabPage1.Name = "hesabat_malin_qaytarilmasi_tabPage1";
            this.hesabat_malin_qaytarilmasi_tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.hesabat_malin_qaytarilmasi_tabPage1.Size = new System.Drawing.Size(1262, 713);
            this.hesabat_malin_qaytarilmasi_tabPage1.TabIndex = 3;
            this.hesabat_malin_qaytarilmasi_tabPage1.Text = "Malın qaytarılması";
            this.hesabat_malin_qaytarilmasi_tabPage1.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel15
            // 
            this.tableLayoutPanel15.ColumnCount = 1;
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel15.Controls.Add(this.hes_malin_qayt_dgv, 0, 1);
            this.tableLayoutPanel15.Controls.Add(this.panel3, 0, 0);
            this.tableLayoutPanel15.Controls.Add(this.tableLayoutPanel16, 0, 2);
            this.tableLayoutPanel15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel15.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel15.Name = "tableLayoutPanel15";
            this.tableLayoutPanel15.RowCount = 3;
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel15.Size = new System.Drawing.Size(1256, 707);
            this.tableLayoutPanel15.TabIndex = 1;
            // 
            // hes_malin_qayt_dgv
            // 
            this.hes_malin_qayt_dgv.AllowUserToAddRows = false;
            this.hes_malin_qayt_dgv.AllowUserToDeleteRows = false;
            this.hes_malin_qayt_dgv.AllowUserToOrderColumns = true;
            this.hes_malin_qayt_dgv.AllowUserToResizeRows = false;
            this.hes_malin_qayt_dgv.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.hes_malin_qayt_dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.hes_malin_qayt_dgv.Dock = System.Windows.Forms.DockStyle.Fill;
            this.hes_malin_qayt_dgv.Location = new System.Drawing.Point(3, 123);
            this.hes_malin_qayt_dgv.MultiSelect = false;
            this.hes_malin_qayt_dgv.Name = "hes_malin_qayt_dgv";
            this.hes_malin_qayt_dgv.ReadOnly = true;
            this.hes_malin_qayt_dgv.RowHeadersVisible = false;
            this.hes_malin_qayt_dgv.Size = new System.Drawing.Size(1250, 481);
            this.hes_malin_qayt_dgv.TabIndex = 0;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.label25);
            this.panel3.Controls.Add(this.hesabat_qaytar_mal_ktleri_comboBox3);
            this.panel3.Controls.Add(this.label26);
            this.panel3.Controls.Add(this.label27);
            this.panel3.Controls.Add(this.hesabat_qaytar_ok_button2);
            this.panel3.Controls.Add(this.hesabat_qaytar_bas_dateTimePicker1);
            this.panel3.Controls.Add(this.hesabat_qaytar_son_dateTimePicker1);
            this.panel3.Controls.Add(this.hesabat_qaytar_axtar_txt);
            this.panel3.Controls.Add(this.hesabat_qaytar_mal_tipleri_comboBox3);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(3, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1250, 114);
            this.panel3.TabIndex = 1;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(212, 18);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(45, 17);
            this.label25.TabIndex = 54;
            this.label25.Text = "Axtar";
            // 
            // hesabat_qaytar_mal_ktleri_comboBox3
            // 
            this.hesabat_qaytar_mal_ktleri_comboBox3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.hesabat_qaytar_mal_ktleri_comboBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.hesabat_qaytar_mal_ktleri_comboBox3.FormattingEnabled = true;
            this.hesabat_qaytar_mal_ktleri_comboBox3.Items.AddRange(new object[] {
            "Mal kateqoriyaları"});
            this.hesabat_qaytar_mal_ktleri_comboBox3.Location = new System.Drawing.Point(17, 55);
            this.hesabat_qaytar_mal_ktleri_comboBox3.Name = "hesabat_qaytar_mal_ktleri_comboBox3";
            this.hesabat_qaytar_mal_ktleri_comboBox3.Size = new System.Drawing.Size(144, 21);
            this.hesabat_qaytar_mal_ktleri_comboBox3.TabIndex = 53;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(327, 19);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(83, 17);
            this.label26.TabIndex = 48;
            this.label26.Text = "Başlanğıc:";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(369, 56);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(41, 17);
            this.label27.TabIndex = 47;
            this.label27.Text = "Son:";
            // 
            // hesabat_qaytar_ok_button2
            // 
            this.hesabat_qaytar_ok_button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.hesabat_qaytar_ok_button2.ForeColor = System.Drawing.Color.Maroon;
            this.hesabat_qaytar_ok_button2.Location = new System.Drawing.Point(618, 25);
            this.hesabat_qaytar_ok_button2.Name = "hesabat_qaytar_ok_button2";
            this.hesabat_qaytar_ok_button2.Size = new System.Drawing.Size(69, 51);
            this.hesabat_qaytar_ok_button2.TabIndex = 46;
            this.hesabat_qaytar_ok_button2.Text = "OK";
            this.hesabat_qaytar_ok_button2.UseVisualStyleBackColor = true;
            this.hesabat_qaytar_ok_button2.Click += new System.EventHandler(this.hesabat_qaytar_ok_button2_Click);
            // 
            // hesabat_qaytar_bas_dateTimePicker1
            // 
            this.hesabat_qaytar_bas_dateTimePicker1.CustomFormat = "yyyy-MM-dd HH:mm:ss";
            this.hesabat_qaytar_bas_dateTimePicker1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hesabat_qaytar_bas_dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.hesabat_qaytar_bas_dateTimePicker1.Location = new System.Drawing.Point(422, 19);
            this.hesabat_qaytar_bas_dateTimePicker1.Name = "hesabat_qaytar_bas_dateTimePicker1";
            this.hesabat_qaytar_bas_dateTimePicker1.Size = new System.Drawing.Size(177, 23);
            this.hesabat_qaytar_bas_dateTimePicker1.TabIndex = 45;
            // 
            // hesabat_qaytar_son_dateTimePicker1
            // 
            this.hesabat_qaytar_son_dateTimePicker1.CustomFormat = "yyyy-MM-dd HH:mm:ss";
            this.hesabat_qaytar_son_dateTimePicker1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hesabat_qaytar_son_dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.hesabat_qaytar_son_dateTimePicker1.Location = new System.Drawing.Point(422, 56);
            this.hesabat_qaytar_son_dateTimePicker1.Name = "hesabat_qaytar_son_dateTimePicker1";
            this.hesabat_qaytar_son_dateTimePicker1.Size = new System.Drawing.Size(177, 23);
            this.hesabat_qaytar_son_dateTimePicker1.TabIndex = 44;
            // 
            // hesabat_qaytar_axtar_txt
            // 
            this.hesabat_qaytar_axtar_txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hesabat_qaytar_axtar_txt.Location = new System.Drawing.Point(179, 53);
            this.hesabat_qaytar_axtar_txt.Name = "hesabat_qaytar_axtar_txt";
            this.hesabat_qaytar_axtar_txt.Size = new System.Drawing.Size(119, 23);
            this.hesabat_qaytar_axtar_txt.TabIndex = 41;
            // 
            // hesabat_qaytar_mal_tipleri_comboBox3
            // 
            this.hesabat_qaytar_mal_tipleri_comboBox3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.hesabat_qaytar_mal_tipleri_comboBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.hesabat_qaytar_mal_tipleri_comboBox3.FormattingEnabled = true;
            this.hesabat_qaytar_mal_tipleri_comboBox3.Items.AddRange(new object[] {
            "Mal tipləri",
            "1-Say",
            "2-Uzunluq",
            "3-Çəki",
            "4-Dənəli"});
            this.hesabat_qaytar_mal_tipleri_comboBox3.Location = new System.Drawing.Point(17, 17);
            this.hesabat_qaytar_mal_tipleri_comboBox3.Name = "hesabat_qaytar_mal_tipleri_comboBox3";
            this.hesabat_qaytar_mal_tipleri_comboBox3.Size = new System.Drawing.Size(144, 21);
            this.hesabat_qaytar_mal_tipleri_comboBox3.TabIndex = 35;
            // 
            // tableLayoutPanel16
            // 
            this.tableLayoutPanel16.ColumnCount = 6;
            this.tableLayoutPanel16.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel16.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel16.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel16.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 160F));
            this.tableLayoutPanel16.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 160F));
            this.tableLayoutPanel16.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel16.Controls.Add(this.label28, 0, 1);
            this.tableLayoutPanel16.Controls.Add(this.label29, 0, 0);
            this.tableLayoutPanel16.Controls.Add(this.hesabat_qaytar_umumi_say_label30, 1, 0);
            this.tableLayoutPanel16.Controls.Add(this.label31, 1, 1);
            this.tableLayoutPanel16.Controls.Add(this.label32, 2, 0);
            this.tableLayoutPanel16.Controls.Add(this.label33, 2, 1);
            this.tableLayoutPanel16.Controls.Add(this.label34, 3, 0);
            this.tableLayoutPanel16.Controls.Add(this.label35, 3, 1);
            this.tableLayoutPanel16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel16.Location = new System.Drawing.Point(3, 610);
            this.tableLayoutPanel16.Name = "tableLayoutPanel16";
            this.tableLayoutPanel16.RowCount = 2;
            this.tableLayoutPanel16.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel16.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel16.Size = new System.Drawing.Size(1250, 94);
            this.tableLayoutPanel16.TabIndex = 2;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(3, 47);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(114, 47);
            this.label28.TabIndex = 43;
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(3, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(114, 47);
            this.label29.TabIndex = 42;
            this.label29.Text = "Ümumi say:";
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // hesabat_qaytar_umumi_say_label30
            // 
            this.hesabat_qaytar_umumi_say_label30.AutoSize = true;
            this.hesabat_qaytar_umumi_say_label30.Dock = System.Windows.Forms.DockStyle.Fill;
            this.hesabat_qaytar_umumi_say_label30.Location = new System.Drawing.Point(123, 0);
            this.hesabat_qaytar_umumi_say_label30.Name = "hesabat_qaytar_umumi_say_label30";
            this.hesabat_qaytar_umumi_say_label30.Size = new System.Drawing.Size(114, 47);
            this.hesabat_qaytar_umumi_say_label30.TabIndex = 44;
            this.hesabat_qaytar_umumi_say_label30.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label31.Location = new System.Drawing.Point(123, 47);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(114, 47);
            this.label31.TabIndex = 45;
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label32.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.label32.Location = new System.Drawing.Point(243, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(114, 47);
            this.label32.TabIndex = 46;
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label33.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.label33.Location = new System.Drawing.Point(243, 47);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(114, 47);
            this.label33.TabIndex = 47;
            this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label34.Location = new System.Drawing.Point(363, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(154, 47);
            this.label34.TabIndex = 48;
            this.label34.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label35.Location = new System.Drawing.Point(363, 47);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(154, 47);
            this.label35.TabIndex = 49;
            this.label35.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // hesabat_borclular_tabPage1
            // 
            this.hesabat_borclular_tabPage1.Controls.Add(this.tableLayoutPanel19);
            this.hesabat_borclular_tabPage1.Location = new System.Drawing.Point(4, 25);
            this.hesabat_borclular_tabPage1.Name = "hesabat_borclular_tabPage1";
            this.hesabat_borclular_tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.hesabat_borclular_tabPage1.Size = new System.Drawing.Size(1262, 713);
            this.hesabat_borclular_tabPage1.TabIndex = 4;
            this.hesabat_borclular_tabPage1.Text = "Borclular";
            this.hesabat_borclular_tabPage1.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel19
            // 
            this.tableLayoutPanel19.ColumnCount = 1;
            this.tableLayoutPanel19.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel19.Controls.Add(this.hes_brlar_dgv, 0, 1);
            this.tableLayoutPanel19.Controls.Add(this.panel5, 0, 0);
            this.tableLayoutPanel19.Controls.Add(this.tableLayoutPanel21, 0, 2);
            this.tableLayoutPanel19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel19.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel19.Name = "tableLayoutPanel19";
            this.tableLayoutPanel19.RowCount = 3;
            this.tableLayoutPanel19.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel19.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel19.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel19.Size = new System.Drawing.Size(1256, 707);
            this.tableLayoutPanel19.TabIndex = 1;
            // 
            // hes_brlar_dgv
            // 
            this.hes_brlar_dgv.AllowUserToAddRows = false;
            this.hes_brlar_dgv.AllowUserToDeleteRows = false;
            this.hes_brlar_dgv.AllowUserToOrderColumns = true;
            this.hes_brlar_dgv.AllowUserToResizeRows = false;
            this.hes_brlar_dgv.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.hes_brlar_dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.hes_brlar_dgv.Dock = System.Windows.Forms.DockStyle.Fill;
            this.hes_brlar_dgv.Location = new System.Drawing.Point(3, 103);
            this.hes_brlar_dgv.MultiSelect = false;
            this.hes_brlar_dgv.Name = "hes_brlar_dgv";
            this.hes_brlar_dgv.ReadOnly = true;
            this.hes_brlar_dgv.RowHeadersVisible = false;
            this.hes_brlar_dgv.Size = new System.Drawing.Size(1250, 501);
            this.hes_brlar_dgv.TabIndex = 0;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.label45);
            this.panel5.Controls.Add(this.hes_brclar_borc_tipi_comboBox2);
            this.panel5.Controls.Add(this.label46);
            this.panel5.Controls.Add(this.label47);
            this.panel5.Controls.Add(this.hes_brlar_ok_button2);
            this.panel5.Controls.Add(this.hes_brlar_bas_dateTimePicker);
            this.panel5.Controls.Add(this.hes_brlar_son_dateTimePicker);
            this.panel5.Controls.Add(this.hes_brlar_axtar_textBox);
            this.panel5.Controls.Add(this.brlar_combobox_hesabat);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(3, 3);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1250, 94);
            this.panel5.TabIndex = 1;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(143, 16);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(45, 17);
            this.label45.TabIndex = 54;
            this.label45.Text = "Axtar";
            // 
            // hes_brclar_borc_tipi_comboBox2
            // 
            this.hes_brclar_borc_tipi_comboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.hes_brclar_borc_tipi_comboBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.hes_brclar_borc_tipi_comboBox2.FormattingEnabled = true;
            this.hes_brclar_borc_tipi_comboBox2.Items.AddRange(new object[] {
            "Borc tipi",
            "1-Borc verilir",
            "2-Borc alınır"});
            this.hes_brclar_borc_tipi_comboBox2.Location = new System.Drawing.Point(586, 15);
            this.hes_brclar_borc_tipi_comboBox2.Name = "hes_brclar_borc_tipi_comboBox2";
            this.hes_brclar_borc_tipi_comboBox2.Size = new System.Drawing.Size(173, 21);
            this.hes_brclar_borc_tipi_comboBox2.TabIndex = 50;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.Location = new System.Drawing.Point(260, 16);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(83, 17);
            this.label46.TabIndex = 48;
            this.label46.Text = "Başlanğıc:";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.Location = new System.Drawing.Point(302, 53);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(41, 17);
            this.label47.TabIndex = 47;
            this.label47.Text = "Son:";
            // 
            // hes_brlar_ok_button2
            // 
            this.hes_brlar_ok_button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.hes_brlar_ok_button2.ForeColor = System.Drawing.Color.Maroon;
            this.hes_brlar_ok_button2.Location = new System.Drawing.Point(790, 25);
            this.hes_brlar_ok_button2.Name = "hes_brlar_ok_button2";
            this.hes_brlar_ok_button2.Size = new System.Drawing.Size(69, 51);
            this.hes_brlar_ok_button2.TabIndex = 46;
            this.hes_brlar_ok_button2.Text = "OK";
            this.hes_brlar_ok_button2.UseVisualStyleBackColor = true;
            this.hes_brlar_ok_button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // hes_brlar_bas_dateTimePicker
            // 
            this.hes_brlar_bas_dateTimePicker.CustomFormat = "yyyy-MM-dd HH:mm:ss";
            this.hes_brlar_bas_dateTimePicker.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hes_brlar_bas_dateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.hes_brlar_bas_dateTimePicker.Location = new System.Drawing.Point(355, 16);
            this.hes_brlar_bas_dateTimePicker.Name = "hes_brlar_bas_dateTimePicker";
            this.hes_brlar_bas_dateTimePicker.Size = new System.Drawing.Size(189, 23);
            this.hes_brlar_bas_dateTimePicker.TabIndex = 45;
            // 
            // hes_brlar_son_dateTimePicker
            // 
            this.hes_brlar_son_dateTimePicker.CustomFormat = "yyyy-MM-dd HH:mm:ss";
            this.hes_brlar_son_dateTimePicker.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hes_brlar_son_dateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.hes_brlar_son_dateTimePicker.Location = new System.Drawing.Point(355, 53);
            this.hes_brlar_son_dateTimePicker.Name = "hes_brlar_son_dateTimePicker";
            this.hes_brlar_son_dateTimePicker.Size = new System.Drawing.Size(189, 23);
            this.hes_brlar_son_dateTimePicker.TabIndex = 44;
            // 
            // hes_brlar_axtar_textBox
            // 
            this.hes_brlar_axtar_textBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hes_brlar_axtar_textBox.Location = new System.Drawing.Point(109, 53);
            this.hes_brlar_axtar_textBox.Name = "hes_brlar_axtar_textBox";
            this.hes_brlar_axtar_textBox.Size = new System.Drawing.Size(119, 23);
            this.hes_brlar_axtar_textBox.TabIndex = 41;
            // 
            // brlar_combobox_hesabat
            // 
            this.brlar_combobox_hesabat.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.brlar_combobox_hesabat.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.brlar_combobox_hesabat.FormattingEnabled = true;
            this.brlar_combobox_hesabat.Items.AddRange(new object[] {
            "Kassalar"});
            this.brlar_combobox_hesabat.Location = new System.Drawing.Point(11, 16);
            this.brlar_combobox_hesabat.Name = "brlar_combobox_hesabat";
            this.brlar_combobox_hesabat.Size = new System.Drawing.Size(87, 21);
            this.brlar_combobox_hesabat.TabIndex = 32;
            // 
            // tableLayoutPanel21
            // 
            this.tableLayoutPanel21.ColumnCount = 6;
            this.tableLayoutPanel21.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel21.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel21.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel21.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 160F));
            this.tableLayoutPanel21.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 160F));
            this.tableLayoutPanel21.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel21.Controls.Add(this.label48, 0, 1);
            this.tableLayoutPanel21.Controls.Add(this.label49, 0, 0);
            this.tableLayoutPanel21.Controls.Add(this.umumi_say_label_aktiv_hes_brlar, 1, 0);
            this.tableLayoutPanel21.Controls.Add(this.cem_mebleg_label_aktiv_hes_brlar, 1, 1);
            this.tableLayoutPanel21.Controls.Add(this.label52, 2, 0);
            this.tableLayoutPanel21.Controls.Add(this.label53, 2, 1);
            this.tableLayoutPanel21.Controls.Add(this.label54, 3, 0);
            this.tableLayoutPanel21.Controls.Add(this.label55, 3, 1);
            this.tableLayoutPanel21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel21.Location = new System.Drawing.Point(3, 610);
            this.tableLayoutPanel21.Name = "tableLayoutPanel21";
            this.tableLayoutPanel21.RowCount = 2;
            this.tableLayoutPanel21.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel21.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel21.Size = new System.Drawing.Size(1250, 94);
            this.tableLayoutPanel21.TabIndex = 2;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label48.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.Location = new System.Drawing.Point(3, 47);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(114, 47);
            this.label48.TabIndex = 43;
            this.label48.Text = "Cəm məbləğ:";
            this.label48.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label49.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.Location = new System.Drawing.Point(3, 0);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(114, 47);
            this.label49.TabIndex = 42;
            this.label49.Text = "Ümumi say:";
            this.label49.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // umumi_say_label_aktiv_hes_brlar
            // 
            this.umumi_say_label_aktiv_hes_brlar.AutoSize = true;
            this.umumi_say_label_aktiv_hes_brlar.Dock = System.Windows.Forms.DockStyle.Fill;
            this.umumi_say_label_aktiv_hes_brlar.Location = new System.Drawing.Point(123, 0);
            this.umumi_say_label_aktiv_hes_brlar.Name = "umumi_say_label_aktiv_hes_brlar";
            this.umumi_say_label_aktiv_hes_brlar.Size = new System.Drawing.Size(114, 47);
            this.umumi_say_label_aktiv_hes_brlar.TabIndex = 44;
            this.umumi_say_label_aktiv_hes_brlar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cem_mebleg_label_aktiv_hes_brlar
            // 
            this.cem_mebleg_label_aktiv_hes_brlar.AutoSize = true;
            this.cem_mebleg_label_aktiv_hes_brlar.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cem_mebleg_label_aktiv_hes_brlar.Location = new System.Drawing.Point(123, 47);
            this.cem_mebleg_label_aktiv_hes_brlar.Name = "cem_mebleg_label_aktiv_hes_brlar";
            this.cem_mebleg_label_aktiv_hes_brlar.Size = new System.Drawing.Size(114, 47);
            this.cem_mebleg_label_aktiv_hes_brlar.TabIndex = 45;
            this.cem_mebleg_label_aktiv_hes_brlar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label52.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.label52.Location = new System.Drawing.Point(243, 0);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(114, 47);
            this.label52.TabIndex = 46;
            this.label52.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label53.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.label53.Location = new System.Drawing.Point(243, 47);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(114, 47);
            this.label53.TabIndex = 47;
            this.label53.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label54.Location = new System.Drawing.Point(363, 0);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(154, 47);
            this.label54.TabIndex = 48;
            this.label54.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label55.Location = new System.Drawing.Point(363, 47);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(154, 47);
            this.label55.TabIndex = 49;
            this.label55.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // bonus_tabPage1
            // 
            this.bonus_tabPage1.Controls.Add(this.bonus_esas_tableLayoutPanel1);
            this.bonus_tabPage1.Location = new System.Drawing.Point(4, 29);
            this.bonus_tabPage1.Name = "bonus_tabPage1";
            this.bonus_tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.bonus_tabPage1.Size = new System.Drawing.Size(1276, 748);
            this.bonus_tabPage1.TabIndex = 4;
            this.bonus_tabPage1.Text = "BONUS";
            this.bonus_tabPage1.UseVisualStyleBackColor = true;
            // 
            // bonus_esas_tableLayoutPanel1
            // 
            this.bonus_esas_tableLayoutPanel1.ColumnCount = 2;
            this.bonus_esas_tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 300F));
            this.bonus_esas_tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.bonus_esas_tableLayoutPanel1.Controls.Add(this.siyahi_bonus_tableLayoutPanel2, 0, 0);
            this.bonus_esas_tableLayoutPanel1.Controls.Add(this.bonus_sag_tableLayoutPanel3, 1, 0);
            this.bonus_esas_tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bonus_esas_tableLayoutPanel1.Location = new System.Drawing.Point(3, 3);
            this.bonus_esas_tableLayoutPanel1.Name = "bonus_esas_tableLayoutPanel1";
            this.bonus_esas_tableLayoutPanel1.RowCount = 1;
            this.bonus_esas_tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.bonus_esas_tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 742F));
            this.bonus_esas_tableLayoutPanel1.Size = new System.Drawing.Size(1270, 742);
            this.bonus_esas_tableLayoutPanel1.TabIndex = 23;
            // 
            // siyahi_bonus_tableLayoutPanel2
            // 
            this.siyahi_bonus_tableLayoutPanel2.ColumnCount = 1;
            this.siyahi_bonus_tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.siyahi_bonus_tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.siyahi_bonus_tableLayoutPanel2.Controls.Add(this.musteriler_psv_label4, 0, 0);
            this.siyahi_bonus_tableLayoutPanel2.Controls.Add(this.musteriler_listbox_bonus, 0, 1);
            this.siyahi_bonus_tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.siyahi_bonus_tableLayoutPanel2.Location = new System.Drawing.Point(3, 3);
            this.siyahi_bonus_tableLayoutPanel2.Name = "siyahi_bonus_tableLayoutPanel2";
            this.siyahi_bonus_tableLayoutPanel2.RowCount = 2;
            this.siyahi_bonus_tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.siyahi_bonus_tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.siyahi_bonus_tableLayoutPanel2.Size = new System.Drawing.Size(294, 736);
            this.siyahi_bonus_tableLayoutPanel2.TabIndex = 0;
            // 
            // musteriler_psv_label4
            // 
            this.musteriler_psv_label4.AutoSize = true;
            this.musteriler_psv_label4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.musteriler_psv_label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.musteriler_psv_label4.Location = new System.Drawing.Point(3, 0);
            this.musteriler_psv_label4.Name = "musteriler_psv_label4";
            this.musteriler_psv_label4.Size = new System.Drawing.Size(288, 50);
            this.musteriler_psv_label4.TabIndex = 19;
            this.musteriler_psv_label4.Text = "Müştərilər";
            this.musteriler_psv_label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // musteriler_listbox_bonus
            // 
            this.musteriler_listbox_bonus.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.musteriler_listbox_bonus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.musteriler_listbox_bonus.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.musteriler_listbox_bonus.FormattingEnabled = true;
            this.musteriler_listbox_bonus.ItemHeight = 20;
            this.musteriler_listbox_bonus.Location = new System.Drawing.Point(3, 53);
            this.musteriler_listbox_bonus.Name = "musteriler_listbox_bonus";
            this.musteriler_listbox_bonus.Size = new System.Drawing.Size(288, 680);
            this.musteriler_listbox_bonus.TabIndex = 18;
            this.musteriler_listbox_bonus.Tag = "";
            // 
            // bonus_sag_tableLayoutPanel3
            // 
            this.bonus_sag_tableLayoutPanel3.ColumnCount = 2;
            this.bonus_sag_tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 400F));
            this.bonus_sag_tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.bonus_sag_tableLayoutPanel3.Controls.Add(this.yeni_b_kart_groupBox3, 0, 0);
            this.bonus_sag_tableLayoutPanel3.Controls.Add(this.kohne_bonus_kartini_deyis, 0, 3);
            this.bonus_sag_tableLayoutPanel3.Controls.Add(this.bonus_axtaris_groupBox4, 0, 1);
            this.bonus_sag_tableLayoutPanel3.Controls.Add(this.bonus_kartini_sil_button5, 0, 2);
            this.bonus_sag_tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bonus_sag_tableLayoutPanel3.Location = new System.Drawing.Point(303, 3);
            this.bonus_sag_tableLayoutPanel3.Name = "bonus_sag_tableLayoutPanel3";
            this.bonus_sag_tableLayoutPanel3.RowCount = 5;
            this.bonus_sag_tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 200F));
            this.bonus_sag_tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.bonus_sag_tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.bonus_sag_tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.bonus_sag_tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.bonus_sag_tableLayoutPanel3.Size = new System.Drawing.Size(964, 736);
            this.bonus_sag_tableLayoutPanel3.TabIndex = 1;
            // 
            // yeni_b_kart_groupBox3
            // 
            this.yeni_b_kart_groupBox3.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.yeni_b_kart_groupBox3.Controls.Add(this.yeni_kart_text_ad_soyad);
            this.yeni_b_kart_groupBox3.Controls.Add(this.yeni_kart_kod);
            this.yeni_b_kart_groupBox3.Controls.Add(this.yeni_bonus_karti_duymesi);
            this.yeni_b_kart_groupBox3.Controls.Add(this.kod_label_kart);
            this.yeni_b_kart_groupBox3.Controls.Add(this.ad_label_kart);
            this.yeni_b_kart_groupBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.yeni_b_kart_groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.yeni_b_kart_groupBox3.Location = new System.Drawing.Point(3, 3);
            this.yeni_b_kart_groupBox3.Name = "yeni_b_kart_groupBox3";
            this.yeni_b_kart_groupBox3.Size = new System.Drawing.Size(394, 194);
            this.yeni_b_kart_groupBox3.TabIndex = 21;
            this.yeni_b_kart_groupBox3.TabStop = false;
            this.yeni_b_kart_groupBox3.Text = "Yeni bonus kartı";
            // 
            // yeni_kart_text_ad_soyad
            // 
            this.yeni_kart_text_ad_soyad.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.yeni_kart_text_ad_soyad.Location = new System.Drawing.Point(114, 50);
            this.yeni_kart_text_ad_soyad.Name = "yeni_kart_text_ad_soyad";
            this.yeni_kart_text_ad_soyad.Size = new System.Drawing.Size(191, 23);
            this.yeni_kart_text_ad_soyad.TabIndex = 7;
            // 
            // yeni_kart_kod
            // 
            this.yeni_kart_kod.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.yeni_kart_kod.Location = new System.Drawing.Point(114, 79);
            this.yeni_kart_kod.Name = "yeni_kart_kod";
            this.yeni_kart_kod.Size = new System.Drawing.Size(191, 23);
            this.yeni_kart_kod.TabIndex = 9;
            // 
            // yeni_bonus_karti_duymesi
            // 
            this.yeni_bonus_karti_duymesi.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.yeni_bonus_karti_duymesi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.yeni_bonus_karti_duymesi.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.yeni_bonus_karti_duymesi.Location = new System.Drawing.Point(84, 117);
            this.yeni_bonus_karti_duymesi.Name = "yeni_bonus_karti_duymesi";
            this.yeni_bonus_karti_duymesi.Size = new System.Drawing.Size(199, 40);
            this.yeni_bonus_karti_duymesi.TabIndex = 5;
            this.yeni_bonus_karti_duymesi.Text = "Yeni Bonus Kartı";
            this.yeni_bonus_karti_duymesi.UseVisualStyleBackColor = false;
            this.yeni_bonus_karti_duymesi.Click += new System.EventHandler(this.yeni_bonus_karti_duymesi_Click);
            // 
            // kod_label_kart
            // 
            this.kod_label_kart.AutoSize = true;
            this.kod_label_kart.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kod_label_kart.Location = new System.Drawing.Point(61, 84);
            this.kod_label_kart.Name = "kod_label_kart";
            this.kod_label_kart.Size = new System.Drawing.Size(29, 13);
            this.kod_label_kart.TabIndex = 8;
            this.kod_label_kart.Text = "Kod";
            // 
            // ad_label_kart
            // 
            this.ad_label_kart.AutoSize = true;
            this.ad_label_kart.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ad_label_kart.Location = new System.Drawing.Point(41, 55);
            this.ad_label_kart.Name = "ad_label_kart";
            this.ad_label_kart.Size = new System.Drawing.Size(63, 13);
            this.ad_label_kart.TabIndex = 6;
            this.ad_label_kart.Text = "Ad/Soyad";
            // 
            // kohne_bonus_kartini_deyis
            // 
            this.kohne_bonus_kartini_deyis.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.kohne_bonus_kartini_deyis.Dock = System.Windows.Forms.DockStyle.Fill;
            this.kohne_bonus_kartini_deyis.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kohne_bonus_kartini_deyis.ForeColor = System.Drawing.Color.Maroon;
            this.kohne_bonus_kartini_deyis.Location = new System.Drawing.Point(3, 343);
            this.kohne_bonus_kartini_deyis.Name = "kohne_bonus_kartini_deyis";
            this.kohne_bonus_kartini_deyis.Size = new System.Drawing.Size(394, 34);
            this.kohne_bonus_kartini_deyis.TabIndex = 22;
            this.kohne_bonus_kartini_deyis.Text = "Köhnə bonus kartını yenilə";
            this.kohne_bonus_kartini_deyis.UseVisualStyleBackColor = false;
            this.kohne_bonus_kartini_deyis.Click += new System.EventHandler(this.kohne_bonus_kartini_deyis_Click);
            // 
            // bonus_axtaris_groupBox4
            // 
            this.bonus_axtaris_groupBox4.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.bonus_axtaris_groupBox4.Controls.Add(this.axtar_textbox_koda_gore);
            this.bonus_axtaris_groupBox4.Controls.Add(this.bar_kod_label_axtar);
            this.bonus_axtaris_groupBox4.Controls.Add(this.axtar_textbox_ada_gore);
            this.bonus_axtaris_groupBox4.Controls.Add(this.ad_label_axtar);
            this.bonus_axtaris_groupBox4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bonus_axtaris_groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bonus_axtaris_groupBox4.Location = new System.Drawing.Point(3, 203);
            this.bonus_axtaris_groupBox4.Name = "bonus_axtaris_groupBox4";
            this.bonus_axtaris_groupBox4.Size = new System.Drawing.Size(394, 94);
            this.bonus_axtaris_groupBox4.TabIndex = 17;
            this.bonus_axtaris_groupBox4.TabStop = false;
            this.bonus_axtaris_groupBox4.Text = "Axtarış";
            // 
            // axtar_textbox_koda_gore
            // 
            this.axtar_textbox_koda_gore.Location = new System.Drawing.Point(114, 56);
            this.axtar_textbox_koda_gore.Name = "axtar_textbox_koda_gore";
            this.axtar_textbox_koda_gore.Size = new System.Drawing.Size(185, 23);
            this.axtar_textbox_koda_gore.TabIndex = 3;
            this.axtar_textbox_koda_gore.KeyDown += new System.Windows.Forms.KeyEventHandler(this.axtar_textbox_koda_gore_KeyDown);
            // 
            // bar_kod_label_axtar
            // 
            this.bar_kod_label_axtar.AutoSize = true;
            this.bar_kod_label_axtar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bar_kod_label_axtar.Location = new System.Drawing.Point(18, 56);
            this.bar_kod_label_axtar.Name = "bar_kod_label_axtar";
            this.bar_kod_label_axtar.Size = new System.Drawing.Size(51, 13);
            this.bar_kod_label_axtar.TabIndex = 2;
            this.bar_kod_label_axtar.Text = "Bar kod";
            // 
            // axtar_textbox_ada_gore
            // 
            this.axtar_textbox_ada_gore.Location = new System.Drawing.Point(114, 22);
            this.axtar_textbox_ada_gore.Name = "axtar_textbox_ada_gore";
            this.axtar_textbox_ada_gore.Size = new System.Drawing.Size(185, 23);
            this.axtar_textbox_ada_gore.TabIndex = 1;
            this.axtar_textbox_ada_gore.KeyUp += new System.Windows.Forms.KeyEventHandler(this.axtar_textbox_ada_gore_KeyUp);
            // 
            // ad_label_axtar
            // 
            this.ad_label_axtar.AutoSize = true;
            this.ad_label_axtar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ad_label_axtar.Location = new System.Drawing.Point(18, 29);
            this.ad_label_axtar.Name = "ad_label_axtar";
            this.ad_label_axtar.Size = new System.Drawing.Size(22, 13);
            this.ad_label_axtar.TabIndex = 0;
            this.ad_label_axtar.Text = "Ad";
            // 
            // bonus_kartini_sil_button5
            // 
            this.bonus_kartini_sil_button5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.bonus_kartini_sil_button5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bonus_kartini_sil_button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bonus_kartini_sil_button5.ForeColor = System.Drawing.Color.Maroon;
            this.bonus_kartini_sil_button5.Location = new System.Drawing.Point(3, 303);
            this.bonus_kartini_sil_button5.Name = "bonus_kartini_sil_button5";
            this.bonus_kartini_sil_button5.Size = new System.Drawing.Size(394, 34);
            this.bonus_kartini_sil_button5.TabIndex = 20;
            this.bonus_kartini_sil_button5.Text = "Kartı sil";
            this.bonus_kartini_sil_button5.UseVisualStyleBackColor = false;
            this.bonus_kartini_sil_button5.Click += new System.EventHandler(this.bonus_kartini_sil_button5_Click);
            // 
            // sazlamalar_tabPage1
            // 
            this.sazlamalar_tabPage1.Controls.Add(this.tabControl1);
            this.sazlamalar_tabPage1.Location = new System.Drawing.Point(4, 29);
            this.sazlamalar_tabPage1.Name = "sazlamalar_tabPage1";
            this.sazlamalar_tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.sazlamalar_tabPage1.Size = new System.Drawing.Size(1276, 748);
            this.sazlamalar_tabPage1.TabIndex = 5;
            this.sazlamalar_tabPage1.Text = "SAZLAMALAR";
            this.sazlamalar_tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.bonus_k_tabPage1);
            this.tabControl1.Controls.Add(this.elave_tabPage2);
            this.tabControl1.Controls.Add(this.sazlamalar_mallar_tabPage1);
            this.tabControl1.Controls.Add(this.sazlamalar_ktler_tabPage1);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(3, 3);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1270, 742);
            this.tabControl1.TabIndex = 0;
            // 
            // bonus_k_tabPage1
            // 
            this.bonus_k_tabPage1.Controls.Add(this.txtkasasayi);
            this.bonus_k_tabPage1.Controls.Add(this.label62);
            this.bonus_k_tabPage1.Controls.Add(this.chekyes);
            this.bonus_k_tabPage1.Controls.Add(this.bonusyes);
            this.bonus_k_tabPage1.Controls.Add(this.sazlamalar_deyisiklikleri_kassaya_gonder_button);
            this.bonus_k_tabPage1.Controls.Add(this.srok_aktiv_edilsin_checkBox);
            this.bonus_k_tabPage1.Controls.Add(this.alici_bildirisi_gunu_button);
            this.bonus_k_tabPage1.Controls.Add(this.cekde_musterilerin_sroku_cap_olunsun_checkBox);
            this.bonus_k_tabPage1.Controls.Add(this.butun_musterilerin_srok_gununu_deyis_button);
            this.bonus_k_tabPage1.Controls.Add(this.cekde_musteri_xali_gorunsun_checkBox);
            this.bonus_k_tabPage1.Controls.Add(this.admin_sazlamalar_faiz_standart_button);
            this.bonus_k_tabPage1.Controls.Add(this.butun_musterilerin_bonus_faizini_deyis_button);
            this.bonus_k_tabPage1.Location = new System.Drawing.Point(4, 29);
            this.bonus_k_tabPage1.Name = "bonus_k_tabPage1";
            this.bonus_k_tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.bonus_k_tabPage1.Size = new System.Drawing.Size(1262, 709);
            this.bonus_k_tabPage1.TabIndex = 0;
            this.bonus_k_tabPage1.Text = "Bonus Kartları";
            this.bonus_k_tabPage1.UseVisualStyleBackColor = true;
            // 
            // txtkasasayi
            // 
            this.txtkasasayi.Location = new System.Drawing.Point(592, 160);
            this.txtkasasayi.Name = "txtkasasayi";
            this.txtkasasayi.Size = new System.Drawing.Size(50, 26);
            this.txtkasasayi.TabIndex = 20;
            this.txtkasasayi.Text = "1";
            this.txtkasasayi.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtkasasayi_KeyPress);
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(475, 163);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(94, 20);
            this.label62.TabIndex = 19;
            this.label62.Text = "Kassa sayi";
            // 
            // chekyes
            // 
            this.chekyes.AutoSize = true;
            this.chekyes.Location = new System.Drawing.Point(479, 126);
            this.chekyes.Name = "chekyes";
            this.chekyes.Size = new System.Drawing.Size(114, 24);
            this.chekyes.TabIndex = 18;
            this.chekyes.Text = "Çek çap et";
            this.chekyes.UseVisualStyleBackColor = true;
            this.chekyes.CheckedChanged += new System.EventHandler(this.chekyes_CheckedChanged);
            // 
            // bonusyes
            // 
            this.bonusyes.AutoSize = true;
            this.bonusyes.Location = new System.Drawing.Point(479, 96);
            this.bonusyes.Name = "bonusyes";
            this.bonusyes.Size = new System.Drawing.Size(221, 24);
            this.bonusyes.TabIndex = 17;
            this.bonusyes.Text = "Kassada bonus kart istə";
            this.bonusyes.UseVisualStyleBackColor = true;
            this.bonusyes.CheckedChanged += new System.EventHandler(this.bonusyes_CheckedChanged);
            // 
            // sazlamalar_deyisiklikleri_kassaya_gonder_button
            // 
            this.sazlamalar_deyisiklikleri_kassaya_gonder_button.Location = new System.Drawing.Point(6, 153);
            this.sazlamalar_deyisiklikleri_kassaya_gonder_button.Name = "sazlamalar_deyisiklikleri_kassaya_gonder_button";
            this.sazlamalar_deyisiklikleri_kassaya_gonder_button.Size = new System.Drawing.Size(367, 30);
            this.sazlamalar_deyisiklikleri_kassaya_gonder_button.TabIndex = 15;
            this.sazlamalar_deyisiklikleri_kassaya_gonder_button.Text = "Dəyişiklikləri kassalara göndər";
            this.sazlamalar_deyisiklikleri_kassaya_gonder_button.UseVisualStyleBackColor = true;
            this.sazlamalar_deyisiklikleri_kassaya_gonder_button.Visible = false;
            this.sazlamalar_deyisiklikleri_kassaya_gonder_button.Click += new System.EventHandler(this.sazlamalar_deyisiklikleri_kassaya_gonder_button_Click);
            // 
            // srok_aktiv_edilsin_checkBox
            // 
            this.srok_aktiv_edilsin_checkBox.AutoSize = true;
            this.srok_aktiv_edilsin_checkBox.Location = new System.Drawing.Point(479, 66);
            this.srok_aktiv_edilsin_checkBox.Name = "srok_aktiv_edilsin_checkBox";
            this.srok_aktiv_edilsin_checkBox.Size = new System.Drawing.Size(163, 24);
            this.srok_aktiv_edilsin_checkBox.TabIndex = 14;
            this.srok_aktiv_edilsin_checkBox.Text = "Srok aktiv edilsin";
            this.srok_aktiv_edilsin_checkBox.UseVisualStyleBackColor = true;
            this.srok_aktiv_edilsin_checkBox.CheckedChanged += new System.EventHandler(this.srok_aktiv_edilsin_checkBox_CheckedChanged);
            // 
            // alici_bildirisi_gunu_button
            // 
            this.alici_bildirisi_gunu_button.Location = new System.Drawing.Point(6, 117);
            this.alici_bildirisi_gunu_button.Name = "alici_bildirisi_gunu_button";
            this.alici_bildirisi_gunu_button.Size = new System.Drawing.Size(367, 30);
            this.alici_bildirisi_gunu_button.TabIndex = 13;
            this.alici_bildirisi_gunu_button.Text = "Sroka neçə gün qalmış bildiriş çap olunsun?";
            this.alici_bildirisi_gunu_button.UseVisualStyleBackColor = true;
            this.alici_bildirisi_gunu_button.Click += new System.EventHandler(this.alici_bildirisi_gunu_button_Click);
            // 
            // cekde_musterilerin_sroku_cap_olunsun_checkBox
            // 
            this.cekde_musterilerin_sroku_cap_olunsun_checkBox.AutoSize = true;
            this.cekde_musterilerin_sroku_cap_olunsun_checkBox.Location = new System.Drawing.Point(479, 40);
            this.cekde_musterilerin_sroku_cap_olunsun_checkBox.Name = "cekde_musterilerin_sroku_cap_olunsun_checkBox";
            this.cekde_musterilerin_sroku_cap_olunsun_checkBox.Size = new System.Drawing.Size(344, 24);
            this.cekde_musterilerin_sroku_cap_olunsun_checkBox.TabIndex = 12;
            this.cekde_musterilerin_sroku_cap_olunsun_checkBox.Text = "Çekdə alıcının bonus sroku çap olunsun";
            this.cekde_musterilerin_sroku_cap_olunsun_checkBox.UseVisualStyleBackColor = true;
            this.cekde_musterilerin_sroku_cap_olunsun_checkBox.CheckedChanged += new System.EventHandler(this.cekde_musterilerin_sroku_cap_olunsun_checkBox_CheckedChanged);
            // 
            // butun_musterilerin_srok_gununu_deyis_button
            // 
            this.butun_musterilerin_srok_gununu_deyis_button.Location = new System.Drawing.Point(6, 80);
            this.butun_musterilerin_srok_gununu_deyis_button.Name = "butun_musterilerin_srok_gununu_deyis_button";
            this.butun_musterilerin_srok_gununu_deyis_button.Size = new System.Drawing.Size(366, 31);
            this.butun_musterilerin_srok_gununu_deyis_button.TabIndex = 11;
            this.butun_musterilerin_srok_gununu_deyis_button.Text = "Bütün müştərilərin Srok gününü dəyiş";
            this.butun_musterilerin_srok_gununu_deyis_button.UseVisualStyleBackColor = true;
            this.butun_musterilerin_srok_gununu_deyis_button.Click += new System.EventHandler(this.butun_musterilerin_srok_gununu_deyis_button_Click);
            // 
            // cekde_musteri_xali_gorunsun_checkBox
            // 
            this.cekde_musteri_xali_gorunsun_checkBox.AutoSize = true;
            this.cekde_musteri_xali_gorunsun_checkBox.Location = new System.Drawing.Point(479, 13);
            this.cekde_musteri_xali_gorunsun_checkBox.Name = "cekde_musteri_xali_gorunsun_checkBox";
            this.cekde_musteri_xali_gorunsun_checkBox.Size = new System.Drawing.Size(340, 24);
            this.cekde_musteri_xali_gorunsun_checkBox.TabIndex = 10;
            this.cekde_musteri_xali_gorunsun_checkBox.Text = "Çekdə alıcının ümumi bonusu görünsün";
            this.cekde_musteri_xali_gorunsun_checkBox.UseVisualStyleBackColor = true;
            this.cekde_musteri_xali_gorunsun_checkBox.CheckedChanged += new System.EventHandler(this.cekde_musteri_xali_gorunsun_checkBox_CheckedChanged);
            // 
            // admin_sazlamalar_faiz_standart_button
            // 
            this.admin_sazlamalar_faiz_standart_button.Location = new System.Drawing.Point(6, 43);
            this.admin_sazlamalar_faiz_standart_button.Name = "admin_sazlamalar_faiz_standart_button";
            this.admin_sazlamalar_faiz_standart_button.Size = new System.Drawing.Size(366, 31);
            this.admin_sazlamalar_faiz_standart_button.TabIndex = 9;
            this.admin_sazlamalar_faiz_standart_button.Text = "Faiz üçün standartı daxil et";
            this.admin_sazlamalar_faiz_standart_button.UseVisualStyleBackColor = true;
            this.admin_sazlamalar_faiz_standart_button.Click += new System.EventHandler(this.admin_sazlamalar_faiz_standart_button_Click);
            // 
            // butun_musterilerin_bonus_faizini_deyis_button
            // 
            this.butun_musterilerin_bonus_faizini_deyis_button.Location = new System.Drawing.Point(6, 6);
            this.butun_musterilerin_bonus_faizini_deyis_button.Name = "butun_musterilerin_bonus_faizini_deyis_button";
            this.butun_musterilerin_bonus_faizini_deyis_button.Size = new System.Drawing.Size(366, 31);
            this.butun_musterilerin_bonus_faizini_deyis_button.TabIndex = 8;
            this.butun_musterilerin_bonus_faizini_deyis_button.Text = "Bütün müştərilərin bonus faizini dəyiş";
            this.butun_musterilerin_bonus_faizini_deyis_button.UseVisualStyleBackColor = true;
            this.butun_musterilerin_bonus_faizini_deyis_button.Click += new System.EventHandler(this.butun_musterilerin_bonus_faizini_deyis_button_Click);
            // 
            // elave_tabPage2
            // 
            this.elave_tabPage2.Controls.Add(this.yadda_saxla_button);
            this.elave_tabPage2.Controls.Add(this.label7);
            this.elave_tabPage2.Controls.Add(this.sifre_textbox);
            this.elave_tabPage2.Controls.Add(this.sifreler_listbox);
            this.elave_tabPage2.Controls.Add(this.bazaya_sorgu_textBox2);
            this.elave_tabPage2.Controls.Add(this.bazaya_iud_sorgu_button6);
            this.elave_tabPage2.Location = new System.Drawing.Point(4, 29);
            this.elave_tabPage2.Name = "elave_tabPage2";
            this.elave_tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.elave_tabPage2.Size = new System.Drawing.Size(1262, 709);
            this.elave_tabPage2.TabIndex = 1;
            this.elave_tabPage2.Text = "Əlavə";
            this.elave_tabPage2.UseVisualStyleBackColor = true;
            // 
            // yadda_saxla_button
            // 
            this.yadda_saxla_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.yadda_saxla_button.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.yadda_saxla_button.Location = new System.Drawing.Point(822, 233);
            this.yadda_saxla_button.Name = "yadda_saxla_button";
            this.yadda_saxla_button.Size = new System.Drawing.Size(200, 44);
            this.yadda_saxla_button.TabIndex = 7;
            this.yadda_saxla_button.Text = "Yadda saxla";
            this.yadda_saxla_button.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.Location = new System.Drawing.Point(888, 144);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(52, 24);
            this.label7.TabIndex = 6;
            this.label7.Text = "Şifrə";
            // 
            // sifre_textbox
            // 
            this.sifre_textbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.sifre_textbox.ForeColor = System.Drawing.Color.Red;
            this.sifre_textbox.Location = new System.Drawing.Point(822, 173);
            this.sifre_textbox.Name = "sifre_textbox";
            this.sifre_textbox.Size = new System.Drawing.Size(200, 26);
            this.sifre_textbox.TabIndex = 5;
            // 
            // sifreler_listbox
            // 
            this.sifreler_listbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.sifreler_listbox.FormattingEnabled = true;
            this.sifreler_listbox.ItemHeight = 24;
            this.sifreler_listbox.Items.AddRange(new object[] {
            "Admin",
            "Kassa-1",
            "Kassa-2"});
            this.sifreler_listbox.Location = new System.Drawing.Point(653, 173);
            this.sifreler_listbox.Name = "sifreler_listbox";
            this.sifreler_listbox.Size = new System.Drawing.Size(128, 148);
            this.sifreler_listbox.TabIndex = 4;
            this.sifreler_listbox.SelectedIndexChanged += new System.EventHandler(this.sifreler_listbox_SelectedIndexChanged);
            // 
            // bazaya_sorgu_textBox2
            // 
            this.bazaya_sorgu_textBox2.Location = new System.Drawing.Point(22, 108);
            this.bazaya_sorgu_textBox2.Multiline = true;
            this.bazaya_sorgu_textBox2.Name = "bazaya_sorgu_textBox2";
            this.bazaya_sorgu_textBox2.Size = new System.Drawing.Size(529, 305);
            this.bazaya_sorgu_textBox2.TabIndex = 3;
            // 
            // bazaya_iud_sorgu_button6
            // 
            this.bazaya_iud_sorgu_button6.Location = new System.Drawing.Point(22, 25);
            this.bazaya_iud_sorgu_button6.Name = "bazaya_iud_sorgu_button6";
            this.bazaya_iud_sorgu_button6.Size = new System.Drawing.Size(192, 66);
            this.bazaya_iud_sorgu_button6.TabIndex = 2;
            this.bazaya_iud_sorgu_button6.Text = "Sorğunu icra et";
            this.bazaya_iud_sorgu_button6.UseVisualStyleBackColor = true;
            this.bazaya_iud_sorgu_button6.Click += new System.EventHandler(this.bazaya_iud_sorgu_button6_Click);
            // 
            // sazlamalar_mallar_tabPage1
            // 
            this.sazlamalar_mallar_tabPage1.Controls.Add(this.sazlamalar_mallar_tableLayoutPanel12);
            this.sazlamalar_mallar_tabPage1.Location = new System.Drawing.Point(4, 29);
            this.sazlamalar_mallar_tabPage1.Name = "sazlamalar_mallar_tabPage1";
            this.sazlamalar_mallar_tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.sazlamalar_mallar_tabPage1.Size = new System.Drawing.Size(1262, 709);
            this.sazlamalar_mallar_tabPage1.TabIndex = 4;
            this.sazlamalar_mallar_tabPage1.Text = "Mallar";
            this.sazlamalar_mallar_tabPage1.UseVisualStyleBackColor = true;
            // 
            // sazlamalar_mallar_tableLayoutPanel12
            // 
            this.sazlamalar_mallar_tableLayoutPanel12.ColumnCount = 1;
            this.sazlamalar_mallar_tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.sazlamalar_mallar_tableLayoutPanel12.Controls.Add(this.sazlamalar_mallar_dgv, 0, 1);
            this.sazlamalar_mallar_tableLayoutPanel12.Controls.Add(this.tableLayoutPanel13, 0, 0);
            this.sazlamalar_mallar_tableLayoutPanel12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sazlamalar_mallar_tableLayoutPanel12.Location = new System.Drawing.Point(3, 3);
            this.sazlamalar_mallar_tableLayoutPanel12.Name = "sazlamalar_mallar_tableLayoutPanel12";
            this.sazlamalar_mallar_tableLayoutPanel12.RowCount = 3;
            this.sazlamalar_mallar_tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.sazlamalar_mallar_tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.sazlamalar_mallar_tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.sazlamalar_mallar_tableLayoutPanel12.Size = new System.Drawing.Size(1256, 703);
            this.sazlamalar_mallar_tableLayoutPanel12.TabIndex = 2;
            // 
            // sazlamalar_mallar_dgv
            // 
            this.sazlamalar_mallar_dgv.AllowUserToAddRows = false;
            this.sazlamalar_mallar_dgv.AllowUserToDeleteRows = false;
            this.sazlamalar_mallar_dgv.AllowUserToOrderColumns = true;
            this.sazlamalar_mallar_dgv.AllowUserToResizeRows = false;
            this.sazlamalar_mallar_dgv.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.sazlamalar_mallar_dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.sazlamalar_mallar_dgv.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sazlamalar_mallar_dgv.Location = new System.Drawing.Point(3, 63);
            this.sazlamalar_mallar_dgv.MultiSelect = false;
            this.sazlamalar_mallar_dgv.Name = "sazlamalar_mallar_dgv";
            this.sazlamalar_mallar_dgv.ReadOnly = true;
            this.sazlamalar_mallar_dgv.RowHeadersVisible = false;
            this.sazlamalar_mallar_dgv.Size = new System.Drawing.Size(1250, 597);
            this.sazlamalar_mallar_dgv.TabIndex = 1;
            // 
            // tableLayoutPanel13
            // 
            this.tableLayoutPanel13.ColumnCount = 5;
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 300F));
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 200F));
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 200F));
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel13.Controls.Add(this.sazlamalar_mallar_silinmeli_ay_textBox1, 0, 0);
            this.tableLayoutPanel13.Controls.Add(this.passiv_mallari_sil_button1, 1, 0);
            this.tableLayoutPanel13.Controls.Add(this.sazlamalar_mallar_hamisini_sil_button1, 2, 0);
            this.tableLayoutPanel13.Controls.Add(this.sazlamalar_mallar_birini_sil_button2, 3, 0);
            this.tableLayoutPanel13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel13.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel13.Name = "tableLayoutPanel13";
            this.tableLayoutPanel13.RowCount = 1;
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel13.Size = new System.Drawing.Size(1250, 54);
            this.tableLayoutPanel13.TabIndex = 0;
            // 
            // sazlamalar_mallar_silinmeli_ay_textBox1
            // 
            this.sazlamalar_mallar_silinmeli_ay_textBox1.Location = new System.Drawing.Point(3, 10);
            this.sazlamalar_mallar_silinmeli_ay_textBox1.Margin = new System.Windows.Forms.Padding(3, 10, 3, 3);
            this.sazlamalar_mallar_silinmeli_ay_textBox1.Name = "sazlamalar_mallar_silinmeli_ay_textBox1";
            this.sazlamalar_mallar_silinmeli_ay_textBox1.Size = new System.Drawing.Size(94, 26);
            this.sazlamalar_mallar_silinmeli_ay_textBox1.TabIndex = 1;
            this.sazlamalar_mallar_silinmeli_ay_textBox1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.sazlamalar_mallar_silinmeli_ay_textBox1_KeyPress);
            // 
            // passiv_mallari_sil_button1
            // 
            this.passiv_mallari_sil_button1.Location = new System.Drawing.Point(103, 3);
            this.passiv_mallari_sil_button1.Name = "passiv_mallari_sil_button1";
            this.passiv_mallari_sil_button1.Size = new System.Drawing.Size(291, 47);
            this.passiv_mallari_sil_button1.TabIndex = 0;
            this.passiv_mallari_sil_button1.Text = "Aylıq passiv malları sil";
            this.passiv_mallari_sil_button1.UseVisualStyleBackColor = true;
            this.passiv_mallari_sil_button1.Click += new System.EventHandler(this.passiv_mallari_sil_button1_Click);
            // 
            // sazlamalar_mallar_hamisini_sil_button1
            // 
            this.sazlamalar_mallar_hamisini_sil_button1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sazlamalar_mallar_hamisini_sil_button1.Location = new System.Drawing.Point(403, 3);
            this.sazlamalar_mallar_hamisini_sil_button1.Name = "sazlamalar_mallar_hamisini_sil_button1";
            this.sazlamalar_mallar_hamisini_sil_button1.Size = new System.Drawing.Size(194, 48);
            this.sazlamalar_mallar_hamisini_sil_button1.TabIndex = 2;
            this.sazlamalar_mallar_hamisini_sil_button1.Text = "Hamısını sil";
            this.sazlamalar_mallar_hamisini_sil_button1.UseVisualStyleBackColor = true;
            this.sazlamalar_mallar_hamisini_sil_button1.Click += new System.EventHandler(this.sazlamalar_mallar_hamisini_sil_button1_Click);
            // 
            // sazlamalar_mallar_birini_sil_button2
            // 
            this.sazlamalar_mallar_birini_sil_button2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sazlamalar_mallar_birini_sil_button2.Location = new System.Drawing.Point(603, 3);
            this.sazlamalar_mallar_birini_sil_button2.Name = "sazlamalar_mallar_birini_sil_button2";
            this.sazlamalar_mallar_birini_sil_button2.Size = new System.Drawing.Size(194, 48);
            this.sazlamalar_mallar_birini_sil_button2.TabIndex = 3;
            this.sazlamalar_mallar_birini_sil_button2.Text = "Birini sil";
            this.sazlamalar_mallar_birini_sil_button2.UseVisualStyleBackColor = true;
            this.sazlamalar_mallar_birini_sil_button2.Click += new System.EventHandler(this.sazlamalar_mallar_birini_sil_button2_Click);
            // 
            // sazlamalar_ktler_tabPage1
            // 
            this.sazlamalar_ktler_tabPage1.Controls.Add(this.tableLayoutPanel12);
            this.sazlamalar_ktler_tabPage1.Location = new System.Drawing.Point(4, 29);
            this.sazlamalar_ktler_tabPage1.Name = "sazlamalar_ktler_tabPage1";
            this.sazlamalar_ktler_tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.sazlamalar_ktler_tabPage1.Size = new System.Drawing.Size(1262, 709);
            this.sazlamalar_ktler_tabPage1.TabIndex = 5;
            this.sazlamalar_ktler_tabPage1.Text = "Kateqoriyalar";
            this.sazlamalar_ktler_tabPage1.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel12
            // 
            this.tableLayoutPanel12.ColumnCount = 2;
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 300F));
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel12.Controls.Add(this.label20, 0, 0);
            this.tableLayoutPanel12.Controls.Add(this.sazlamalar_ktler_listBox1, 0, 1);
            this.tableLayoutPanel12.Controls.Add(this.tableLayoutPanel14, 1, 1);
            this.tableLayoutPanel12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel12.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel12.Name = "tableLayoutPanel12";
            this.tableLayoutPanel12.RowCount = 2;
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel12.Size = new System.Drawing.Size(1256, 703);
            this.tableLayoutPanel12.TabIndex = 0;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.Red;
            this.label20.Location = new System.Drawing.Point(3, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(294, 50);
            this.label20.TabIndex = 0;
            this.label20.Text = "Kateqoriyalar";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // sazlamalar_ktler_listBox1
            // 
            this.sazlamalar_ktler_listBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sazlamalar_ktler_listBox1.FormattingEnabled = true;
            this.sazlamalar_ktler_listBox1.ItemHeight = 20;
            this.sazlamalar_ktler_listBox1.Location = new System.Drawing.Point(3, 53);
            this.sazlamalar_ktler_listBox1.Name = "sazlamalar_ktler_listBox1";
            this.sazlamalar_ktler_listBox1.Size = new System.Drawing.Size(294, 647);
            this.sazlamalar_ktler_listBox1.TabIndex = 1;
            this.sazlamalar_ktler_listBox1.SelectedIndexChanged += new System.EventHandler(this.sazlamalar_ktler_listBox1_SelectedIndexChanged);
            // 
            // tableLayoutPanel14
            // 
            this.tableLayoutPanel14.ColumnCount = 2;
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 300F));
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel14.Controls.Add(this.sazlamalar_ktler_adi_textBox1, 0, 0);
            this.tableLayoutPanel14.Controls.Add(this.sazlamalar_ktler_adi_deyisdir_button1, 0, 1);
            this.tableLayoutPanel14.Controls.Add(this.sazlamalar_ktler_siyahini_yenile_button1, 0, 2);
            this.tableLayoutPanel14.Controls.Add(this.sazlamalar_ktler_yeni_kt_button1, 0, 3);
            this.tableLayoutPanel14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel14.Location = new System.Drawing.Point(303, 53);
            this.tableLayoutPanel14.Name = "tableLayoutPanel14";
            this.tableLayoutPanel14.RowCount = 5;
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel14.Size = new System.Drawing.Size(950, 647);
            this.tableLayoutPanel14.TabIndex = 2;
            // 
            // sazlamalar_ktler_adi_textBox1
            // 
            this.sazlamalar_ktler_adi_textBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sazlamalar_ktler_adi_textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sazlamalar_ktler_adi_textBox1.Location = new System.Drawing.Point(3, 9);
            this.sazlamalar_ktler_adi_textBox1.Margin = new System.Windows.Forms.Padding(3, 9, 3, 3);
            this.sazlamalar_ktler_adi_textBox1.Name = "sazlamalar_ktler_adi_textBox1";
            this.sazlamalar_ktler_adi_textBox1.Size = new System.Drawing.Size(294, 32);
            this.sazlamalar_ktler_adi_textBox1.TabIndex = 0;
            // 
            // sazlamalar_ktler_adi_deyisdir_button1
            // 
            this.sazlamalar_ktler_adi_deyisdir_button1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sazlamalar_ktler_adi_deyisdir_button1.Location = new System.Drawing.Point(3, 53);
            this.sazlamalar_ktler_adi_deyisdir_button1.Name = "sazlamalar_ktler_adi_deyisdir_button1";
            this.sazlamalar_ktler_adi_deyisdir_button1.Size = new System.Drawing.Size(294, 44);
            this.sazlamalar_ktler_adi_deyisdir_button1.TabIndex = 1;
            this.sazlamalar_ktler_adi_deyisdir_button1.Text = "Dəyişdir";
            this.sazlamalar_ktler_adi_deyisdir_button1.UseVisualStyleBackColor = true;
            this.sazlamalar_ktler_adi_deyisdir_button1.Click += new System.EventHandler(this.sazlamalar_ktler_adi_deyisdir_button1_Click);
            // 
            // sazlamalar_ktler_siyahini_yenile_button1
            // 
            this.sazlamalar_ktler_siyahini_yenile_button1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sazlamalar_ktler_siyahini_yenile_button1.Location = new System.Drawing.Point(3, 103);
            this.sazlamalar_ktler_siyahini_yenile_button1.Name = "sazlamalar_ktler_siyahini_yenile_button1";
            this.sazlamalar_ktler_siyahini_yenile_button1.Size = new System.Drawing.Size(294, 44);
            this.sazlamalar_ktler_siyahini_yenile_button1.TabIndex = 2;
            this.sazlamalar_ktler_siyahini_yenile_button1.Text = "Siyahını yenilə";
            this.sazlamalar_ktler_siyahini_yenile_button1.UseVisualStyleBackColor = true;
            this.sazlamalar_ktler_siyahini_yenile_button1.Click += new System.EventHandler(this.sazlamalar_ktler_siyahini_yenile_button1_Click);
            // 
            // sazlamalar_ktler_yeni_kt_button1
            // 
            this.sazlamalar_ktler_yeni_kt_button1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sazlamalar_ktler_yeni_kt_button1.Location = new System.Drawing.Point(3, 153);
            this.sazlamalar_ktler_yeni_kt_button1.Name = "sazlamalar_ktler_yeni_kt_button1";
            this.sazlamalar_ktler_yeni_kt_button1.Size = new System.Drawing.Size(294, 44);
            this.sazlamalar_ktler_yeni_kt_button1.TabIndex = 3;
            this.sazlamalar_ktler_yeni_kt_button1.Text = "Yeni Kateqoriya";
            this.sazlamalar_ktler_yeni_kt_button1.UseVisualStyleBackColor = true;
            this.sazlamalar_ktler_yeni_kt_button1.Click += new System.EventHandler(this.sazlamalar_ktler_yeni_kt_button1_Click);
            // 
            // diger_tabPage1
            // 
            this.diger_tabPage1.Controls.Add(this.diger_esas_tabControl1);
            this.diger_tabPage1.Location = new System.Drawing.Point(4, 29);
            this.diger_tabPage1.Name = "diger_tabPage1";
            this.diger_tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.diger_tabPage1.Size = new System.Drawing.Size(1276, 748);
            this.diger_tabPage1.TabIndex = 6;
            this.diger_tabPage1.Text = "DİGƏR";
            this.diger_tabPage1.UseVisualStyleBackColor = true;
            // 
            // diger_esas_tabControl1
            // 
            this.diger_esas_tabControl1.Controls.Add(this.borclar_tabPage1);
            this.diger_esas_tabControl1.Controls.Add(this.borclular_tabPage2);
            this.diger_esas_tabControl1.Controls.Add(this.silinmis_mallar_tabPage1);
            this.diger_esas_tabControl1.Controls.Add(this.kodsuz_mallar_tabPage1);
            this.diger_esas_tabControl1.Controls.Add(this.malin_qaytarilmasi_tabPage1);
            this.diger_esas_tabControl1.Controls.Add(this.diger_balans_tabPage1);
            this.diger_esas_tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.diger_esas_tabControl1.Location = new System.Drawing.Point(3, 3);
            this.diger_esas_tabControl1.Name = "diger_esas_tabControl1";
            this.diger_esas_tabControl1.SelectedIndex = 0;
            this.diger_esas_tabControl1.Size = new System.Drawing.Size(1270, 742);
            this.diger_esas_tabControl1.TabIndex = 0;
            this.diger_esas_tabControl1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.diger_esas_tabControl1_MouseClick);
            // 
            // borclar_tabPage1
            // 
            this.borclar_tabPage1.Controls.Add(this.tableLayoutPanel7);
            this.borclar_tabPage1.Location = new System.Drawing.Point(4, 29);
            this.borclar_tabPage1.Name = "borclar_tabPage1";
            this.borclar_tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.borclar_tabPage1.Size = new System.Drawing.Size(1262, 709);
            this.borclar_tabPage1.TabIndex = 0;
            this.borclar_tabPage1.Text = "FİRMALAR";
            this.borclar_tabPage1.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel7
            // 
            this.tableLayoutPanel7.ColumnCount = 2;
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 800F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel7.Controls.Add(this.tableLayoutPanel8, 0, 0);
            this.tableLayoutPanel7.Controls.Add(this.borclar_listBox1, 0, 1);
            this.tableLayoutPanel7.Controls.Add(this.tableLayoutPanel9, 1, 1);
            this.tableLayoutPanel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel7.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            this.tableLayoutPanel7.RowCount = 2;
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel7.Size = new System.Drawing.Size(1256, 703);
            this.tableLayoutPanel7.TabIndex = 27;
            // 
            // tableLayoutPanel8
            // 
            this.tableLayoutPanel8.ColumnCount = 4;
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 400F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 200F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel8.Controls.Add(this.label11, 0, 0);
            this.tableLayoutPanel8.Controls.Add(this.borclar_axtar_textBox2, 2, 0);
            this.tableLayoutPanel8.Controls.Add(this.label12, 1, 0);
            this.tableLayoutPanel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel8.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel8.Name = "tableLayoutPanel8";
            this.tableLayoutPanel8.RowCount = 1;
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel8.Size = new System.Drawing.Size(794, 34);
            this.tableLayoutPanel8.TabIndex = 0;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(3, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(394, 34);
            this.label11.TabIndex = 19;
            this.label11.Text = "Borclu olduğumuz firmalar";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // borclar_axtar_textBox2
            // 
            this.borclar_axtar_textBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.borclar_axtar_textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.borclar_axtar_textBox2.Location = new System.Drawing.Point(503, 3);
            this.borclar_axtar_textBox2.Name = "borclar_axtar_textBox2";
            this.borclar_axtar_textBox2.Size = new System.Drawing.Size(194, 26);
            this.borclar_axtar_textBox2.TabIndex = 23;
            this.borclar_axtar_textBox2.KeyUp += new System.Windows.Forms.KeyEventHandler(this.borclar_axtar_textBox2_KeyUp);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(403, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(94, 34);
            this.label12.TabIndex = 22;
            this.label12.Text = "Axtar:";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // borclar_listBox1
            // 
            this.borclar_listBox1.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.borclar_listBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.borclar_listBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.borclar_listBox1.FormattingEnabled = true;
            this.borclar_listBox1.ItemHeight = 20;
            this.borclar_listBox1.Location = new System.Drawing.Point(3, 43);
            this.borclar_listBox1.Name = "borclar_listBox1";
            this.borclar_listBox1.Size = new System.Drawing.Size(794, 657);
            this.borclar_listBox1.TabIndex = 20;
            this.borclar_listBox1.Tag = "";
            this.borclar_listBox1.SelectedIndexChanged += new System.EventHandler(this.borclar_listBox1_SelectedIndexChanged);
            // 
            // tableLayoutPanel9
            // 
            this.tableLayoutPanel9.ColumnCount = 1;
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel9.Controls.Add(this.groupBox1, 0, 0);
            this.tableLayoutPanel9.Controls.Add(this.tableLayoutPanel11, 0, 1);
            this.tableLayoutPanel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel9.Location = new System.Drawing.Point(803, 43);
            this.tableLayoutPanel9.Name = "tableLayoutPanel9";
            this.tableLayoutPanel9.RowCount = 3;
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 200F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel9.Size = new System.Drawing.Size(450, 657);
            this.tableLayoutPanel9.TabIndex = 21;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.groupBox1.Controls.Add(this.borclar_yeni_musteri_textBox);
            this.groupBox1.Controls.Add(this.borclar_yeni_musteri_button);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(444, 194);
            this.groupBox1.TabIndex = 21;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Yeni Firma qeydiyyatı";
            // 
            // borclar_yeni_musteri_textBox
            // 
            this.borclar_yeni_musteri_textBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.borclar_yeni_musteri_textBox.Location = new System.Drawing.Point(98, 56);
            this.borclar_yeni_musteri_textBox.Name = "borclar_yeni_musteri_textBox";
            this.borclar_yeni_musteri_textBox.Size = new System.Drawing.Size(191, 23);
            this.borclar_yeni_musteri_textBox.TabIndex = 7;
            // 
            // borclar_yeni_musteri_button
            // 
            this.borclar_yeni_musteri_button.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.borclar_yeni_musteri_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.borclar_yeni_musteri_button.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.borclar_yeni_musteri_button.Location = new System.Drawing.Point(44, 100);
            this.borclar_yeni_musteri_button.Name = "borclar_yeni_musteri_button";
            this.borclar_yeni_musteri_button.Size = new System.Drawing.Size(199, 40);
            this.borclar_yeni_musteri_button.TabIndex = 5;
            this.borclar_yeni_musteri_button.Text = "Qeydiyyat";
            this.borclar_yeni_musteri_button.UseVisualStyleBackColor = false;
            this.borclar_yeni_musteri_button.Click += new System.EventHandler(this.borclar_yeni_musteri_button_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(15, 58);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(80, 17);
            this.label13.TabIndex = 6;
            this.label13.Text = "Firma adı:";
            // 
            // tableLayoutPanel11
            // 
            this.tableLayoutPanel11.ColumnCount = 4;
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 160F));
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 200F));
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel11.Controls.Add(this.borclar_odenisi_yadda_saxla_button1, 2, 0);
            this.tableLayoutPanel11.Controls.Add(this.label14, 0, 0);
            this.tableLayoutPanel11.Controls.Add(this.borclar_borcumuzun_miqdari_textBox1, 1, 0);
            this.tableLayoutPanel11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel11.Location = new System.Drawing.Point(3, 203);
            this.tableLayoutPanel11.Name = "tableLayoutPanel11";
            this.tableLayoutPanel11.RowCount = 1;
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel11.Size = new System.Drawing.Size(444, 44);
            this.tableLayoutPanel11.TabIndex = 22;
            // 
            // borclar_odenisi_yadda_saxla_button1
            // 
            this.borclar_odenisi_yadda_saxla_button1.BackColor = System.Drawing.Color.Yellow;
            this.borclar_odenisi_yadda_saxla_button1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.borclar_odenisi_yadda_saxla_button1.ForeColor = System.Drawing.Color.Crimson;
            this.borclar_odenisi_yadda_saxla_button1.Location = new System.Drawing.Point(303, 3);
            this.borclar_odenisi_yadda_saxla_button1.Name = "borclar_odenisi_yadda_saxla_button1";
            this.borclar_odenisi_yadda_saxla_button1.Size = new System.Drawing.Size(194, 38);
            this.borclar_odenisi_yadda_saxla_button1.TabIndex = 0;
            this.borclar_odenisi_yadda_saxla_button1.Text = "Yadda saxla";
            this.borclar_odenisi_yadda_saxla_button1.UseVisualStyleBackColor = false;
            this.borclar_odenisi_yadda_saxla_button1.Click += new System.EventHandler(this.borclar_ode_button1_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label14.Location = new System.Drawing.Point(3, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(154, 44);
            this.label14.TabIndex = 1;
            this.label14.Text = "Borcumuz:";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // borclar_borcumuzun_miqdari_textBox1
            // 
            this.borclar_borcumuzun_miqdari_textBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.borclar_borcumuzun_miqdari_textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.borclar_borcumuzun_miqdari_textBox1.Location = new System.Drawing.Point(163, 3);
            this.borclar_borcumuzun_miqdari_textBox1.Name = "borclar_borcumuzun_miqdari_textBox1";
            this.borclar_borcumuzun_miqdari_textBox1.Size = new System.Drawing.Size(134, 29);
            this.borclar_borcumuzun_miqdari_textBox1.TabIndex = 2;
            this.borclar_borcumuzun_miqdari_textBox1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.borclar_borcumuzun_miqdari_textBox1_KeyPress);
            // 
            // borclular_tabPage2
            // 
            this.borclular_tabPage2.Controls.Add(this.borclar_tableLayoutPanel1);
            this.borclular_tabPage2.Location = new System.Drawing.Point(4, 29);
            this.borclular_tabPage2.Name = "borclular_tabPage2";
            this.borclular_tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.borclular_tabPage2.Size = new System.Drawing.Size(1262, 709);
            this.borclular_tabPage2.TabIndex = 1;
            this.borclular_tabPage2.Text = "BORCLULAR";
            this.borclular_tabPage2.UseVisualStyleBackColor = true;
            // 
            // borclar_tableLayoutPanel1
            // 
            this.borclar_tableLayoutPanel1.ColumnCount = 2;
            this.borclar_tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 600F));
            this.borclar_tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.borclar_tableLayoutPanel1.Controls.Add(this.borclar_axtar_tableLayoutPanel2, 0, 0);
            this.borclar_tableLayoutPanel1.Controls.Add(this.borclular_musleriler_listBox, 0, 1);
            this.borclar_tableLayoutPanel1.Controls.Add(this.brc_yeni_tableLayoutPanel3, 1, 1);
            this.borclar_tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.borclar_tableLayoutPanel1.Location = new System.Drawing.Point(3, 3);
            this.borclar_tableLayoutPanel1.Name = "borclar_tableLayoutPanel1";
            this.borclar_tableLayoutPanel1.RowCount = 2;
            this.borclar_tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.borclar_tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.borclar_tableLayoutPanel1.Size = new System.Drawing.Size(1256, 703);
            this.borclar_tableLayoutPanel1.TabIndex = 26;
            // 
            // borclar_axtar_tableLayoutPanel2
            // 
            this.borclar_axtar_tableLayoutPanel2.ColumnCount = 4;
            this.borclar_axtar_tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 200F));
            this.borclar_axtar_tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.borclar_axtar_tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 200F));
            this.borclar_axtar_tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.borclar_axtar_tableLayoutPanel2.Controls.Add(this.mus_label47, 0, 0);
            this.borclar_axtar_tableLayoutPanel2.Controls.Add(this.borclular_axtar_textBox2, 2, 0);
            this.borclar_axtar_tableLayoutPanel2.Controls.Add(this.axtar_psv_label48, 1, 0);
            this.borclar_axtar_tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.borclar_axtar_tableLayoutPanel2.Location = new System.Drawing.Point(3, 3);
            this.borclar_axtar_tableLayoutPanel2.Name = "borclar_axtar_tableLayoutPanel2";
            this.borclar_axtar_tableLayoutPanel2.RowCount = 1;
            this.borclar_axtar_tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.borclar_axtar_tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.borclar_axtar_tableLayoutPanel2.Size = new System.Drawing.Size(594, 34);
            this.borclar_axtar_tableLayoutPanel2.TabIndex = 0;
            // 
            // mus_label47
            // 
            this.mus_label47.AutoSize = true;
            this.mus_label47.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mus_label47.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mus_label47.Location = new System.Drawing.Point(3, 0);
            this.mus_label47.Name = "mus_label47";
            this.mus_label47.Size = new System.Drawing.Size(194, 34);
            this.mus_label47.TabIndex = 19;
            this.mus_label47.Text = "Müştərilər";
            this.mus_label47.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // borclular_axtar_textBox2
            // 
            this.borclular_axtar_textBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.borclular_axtar_textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.borclular_axtar_textBox2.Location = new System.Drawing.Point(303, 3);
            this.borclular_axtar_textBox2.Name = "borclular_axtar_textBox2";
            this.borclular_axtar_textBox2.Size = new System.Drawing.Size(194, 26);
            this.borclular_axtar_textBox2.TabIndex = 23;
            this.borclular_axtar_textBox2.KeyUp += new System.Windows.Forms.KeyEventHandler(this.borclular_axtar_textBox2_KeyUp);
            // 
            // axtar_psv_label48
            // 
            this.axtar_psv_label48.AutoSize = true;
            this.axtar_psv_label48.Dock = System.Windows.Forms.DockStyle.Fill;
            this.axtar_psv_label48.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.axtar_psv_label48.Location = new System.Drawing.Point(203, 0);
            this.axtar_psv_label48.Name = "axtar_psv_label48";
            this.axtar_psv_label48.Size = new System.Drawing.Size(94, 34);
            this.axtar_psv_label48.TabIndex = 22;
            this.axtar_psv_label48.Text = "Axtar:";
            this.axtar_psv_label48.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // borclular_musleriler_listBox
            // 
            this.borclular_musleriler_listBox.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.borclular_musleriler_listBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.borclular_musleriler_listBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.borclular_musleriler_listBox.FormattingEnabled = true;
            this.borclular_musleriler_listBox.ItemHeight = 20;
            this.borclular_musleriler_listBox.Location = new System.Drawing.Point(3, 43);
            this.borclular_musleriler_listBox.Name = "borclular_musleriler_listBox";
            this.borclular_musleriler_listBox.Size = new System.Drawing.Size(594, 657);
            this.borclular_musleriler_listBox.TabIndex = 20;
            this.borclular_musleriler_listBox.Tag = "";
            // 
            // brc_yeni_tableLayoutPanel3
            // 
            this.brc_yeni_tableLayoutPanel3.ColumnCount = 1;
            this.brc_yeni_tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.brc_yeni_tableLayoutPanel3.Controls.Add(this.yeni_musteri_groupBox33, 0, 0);
            this.brc_yeni_tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.brc_yeni_tableLayoutPanel3.Location = new System.Drawing.Point(603, 43);
            this.brc_yeni_tableLayoutPanel3.Name = "brc_yeni_tableLayoutPanel3";
            this.brc_yeni_tableLayoutPanel3.RowCount = 2;
            this.brc_yeni_tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 300F));
            this.brc_yeni_tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.brc_yeni_tableLayoutPanel3.Size = new System.Drawing.Size(650, 657);
            this.brc_yeni_tableLayoutPanel3.TabIndex = 21;
            // 
            // yeni_musteri_groupBox33
            // 
            this.yeni_musteri_groupBox33.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.yeni_musteri_groupBox33.Controls.Add(this.borclular_yeni_musteri_textBox);
            this.yeni_musteri_groupBox33.Controls.Add(this.borclular_yeni_musteri_button);
            this.yeni_musteri_groupBox33.Controls.Add(this.ad_sad_label49_psv);
            this.yeni_musteri_groupBox33.Dock = System.Windows.Forms.DockStyle.Fill;
            this.yeni_musteri_groupBox33.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.yeni_musteri_groupBox33.Location = new System.Drawing.Point(3, 3);
            this.yeni_musteri_groupBox33.Name = "yeni_musteri_groupBox33";
            this.yeni_musteri_groupBox33.Size = new System.Drawing.Size(644, 294);
            this.yeni_musteri_groupBox33.TabIndex = 21;
            this.yeni_musteri_groupBox33.TabStop = false;
            this.yeni_musteri_groupBox33.Text = "Yeni Müştəri";
            // 
            // borclular_yeni_musteri_textBox
            // 
            this.borclular_yeni_musteri_textBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.borclular_yeni_musteri_textBox.Location = new System.Drawing.Point(110, 56);
            this.borclular_yeni_musteri_textBox.Name = "borclular_yeni_musteri_textBox";
            this.borclular_yeni_musteri_textBox.Size = new System.Drawing.Size(191, 23);
            this.borclular_yeni_musteri_textBox.TabIndex = 7;
            this.borclular_yeni_musteri_textBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.borclular_yeni_musteri_textBox_KeyDown);
            // 
            // borclular_yeni_musteri_button
            // 
            this.borclular_yeni_musteri_button.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.borclular_yeni_musteri_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.borclular_yeni_musteri_button.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.borclular_yeni_musteri_button.Location = new System.Drawing.Point(44, 100);
            this.borclular_yeni_musteri_button.Name = "borclular_yeni_musteri_button";
            this.borclular_yeni_musteri_button.Size = new System.Drawing.Size(199, 40);
            this.borclular_yeni_musteri_button.TabIndex = 5;
            this.borclular_yeni_musteri_button.Text = "Yeni Müştəri";
            this.borclular_yeni_musteri_button.UseVisualStyleBackColor = false;
            this.borclular_yeni_musteri_button.Click += new System.EventHandler(this.borclular_yeni_musteri_button_Click);
            // 
            // ad_sad_label49_psv
            // 
            this.ad_sad_label49_psv.AutoSize = true;
            this.ad_sad_label49_psv.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ad_sad_label49_psv.Location = new System.Drawing.Point(18, 58);
            this.ad_sad_label49_psv.Name = "ad_sad_label49_psv";
            this.ad_sad_label49_psv.Size = new System.Drawing.Size(91, 20);
            this.ad_sad_label49_psv.TabIndex = 6;
            this.ad_sad_label49_psv.Text = "Ad/Soyad:";
            // 
            // silinmis_mallar_tabPage1
            // 
            this.silinmis_mallar_tabPage1.Controls.Add(this.silinmis_mali_tam_sil);
            this.silinmis_mallar_tabPage1.Controls.Add(this.silinmis_mali_geri_qaytar);
            this.silinmis_mallar_tabPage1.Controls.Add(this.label18);
            this.silinmis_mallar_tabPage1.Controls.Add(this.label17);
            this.silinmis_mallar_tabPage1.Controls.Add(this.silinmis_mallar_kodlari);
            this.silinmis_mallar_tabPage1.Controls.Add(this.silinmis_mallar_adlari);
            this.silinmis_mallar_tabPage1.Location = new System.Drawing.Point(4, 29);
            this.silinmis_mallar_tabPage1.Name = "silinmis_mallar_tabPage1";
            this.silinmis_mallar_tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.silinmis_mallar_tabPage1.Size = new System.Drawing.Size(1262, 709);
            this.silinmis_mallar_tabPage1.TabIndex = 2;
            this.silinmis_mallar_tabPage1.Text = "SİLİNMİŞ MALLAR";
            this.silinmis_mallar_tabPage1.UseVisualStyleBackColor = true;
            // 
            // silinmis_mali_tam_sil
            // 
            this.silinmis_mali_tam_sil.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.silinmis_mali_tam_sil.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.silinmis_mali_tam_sil.Location = new System.Drawing.Point(710, 144);
            this.silinmis_mali_tam_sil.Name = "silinmis_mali_tam_sil";
            this.silinmis_mali_tam_sil.Size = new System.Drawing.Size(186, 55);
            this.silinmis_mali_tam_sil.TabIndex = 11;
            this.silinmis_mali_tam_sil.Text = "Tam sil";
            this.silinmis_mali_tam_sil.UseVisualStyleBackColor = true;
            this.silinmis_mali_tam_sil.Click += new System.EventHandler(this.silinmis_mali_tam_sil_Click);
            // 
            // silinmis_mali_geri_qaytar
            // 
            this.silinmis_mali_geri_qaytar.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.silinmis_mali_geri_qaytar.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.silinmis_mali_geri_qaytar.Location = new System.Drawing.Point(710, 60);
            this.silinmis_mali_geri_qaytar.Name = "silinmis_mali_geri_qaytar";
            this.silinmis_mali_geri_qaytar.Size = new System.Drawing.Size(186, 55);
            this.silinmis_mali_geri_qaytar.TabIndex = 10;
            this.silinmis_mali_geri_qaytar.Text = "Geri qaytar";
            this.silinmis_mali_geri_qaytar.UseVisualStyleBackColor = true;
            this.silinmis_mali_geri_qaytar.Click += new System.EventHandler(this.silinmis_mali_geri_qaytar_Click);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label18.Location = new System.Drawing.Point(490, 27);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(64, 20);
            this.label18.TabIndex = 9;
            this.label18.Text = "Kodları";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label17.Location = new System.Drawing.Point(167, 27);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(55, 20);
            this.label17.TabIndex = 8;
            this.label17.Text = "Adları";
            // 
            // silinmis_mallar_kodlari
            // 
            this.silinmis_mallar_kodlari.FormattingEnabled = true;
            this.silinmis_mallar_kodlari.ItemHeight = 20;
            this.silinmis_mallar_kodlari.Location = new System.Drawing.Point(425, 60);
            this.silinmis_mallar_kodlari.Name = "silinmis_mallar_kodlari";
            this.silinmis_mallar_kodlari.Size = new System.Drawing.Size(196, 444);
            this.silinmis_mallar_kodlari.TabIndex = 7;
            this.silinmis_mallar_kodlari.SelectedIndexChanged += new System.EventHandler(this.silinmis_mallar_kodlari_SelectedIndexChanged);
            // 
            // silinmis_mallar_adlari
            // 
            this.silinmis_mallar_adlari.FormattingEnabled = true;
            this.silinmis_mallar_adlari.ItemHeight = 20;
            this.silinmis_mallar_adlari.Location = new System.Drawing.Point(24, 60);
            this.silinmis_mallar_adlari.Name = "silinmis_mallar_adlari";
            this.silinmis_mallar_adlari.Size = new System.Drawing.Size(368, 444);
            this.silinmis_mallar_adlari.TabIndex = 6;
            this.silinmis_mallar_adlari.SelectedIndexChanged += new System.EventHandler(this.silinmis_mallar_adlari_SelectedIndexChanged);
            // 
            // kodsuz_mallar_tabPage1
            // 
            this.kodsuz_mallar_tabPage1.Controls.Add(this.kodsuz_mallar_yenile_button1);
            this.kodsuz_mallar_tabPage1.Controls.Add(this.strix_kodlar_label);
            this.kodsuz_mallar_tabPage1.Controls.Add(this.mallarin_kodlari_listbox);
            this.kodsuz_mallar_tabPage1.Controls.Add(this.yukle_duymesi);
            this.kodsuz_mallar_tabPage1.Controls.Add(this.legv_et_button);
            this.kodsuz_mallar_tabPage1.Controls.Add(this.hamisini_sec_button);
            this.kodsuz_mallar_tabPage1.Controls.Add(this.bar_kodsuz_mallarin_siyahisi);
            this.kodsuz_mallar_tabPage1.Controls.Add(this.mallarin_siyahisi_listbox);
            this.kodsuz_mallar_tabPage1.Location = new System.Drawing.Point(4, 29);
            this.kodsuz_mallar_tabPage1.Name = "kodsuz_mallar_tabPage1";
            this.kodsuz_mallar_tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.kodsuz_mallar_tabPage1.Size = new System.Drawing.Size(1262, 709);
            this.kodsuz_mallar_tabPage1.TabIndex = 4;
            this.kodsuz_mallar_tabPage1.Text = "KODSUZ MALLAR";
            this.kodsuz_mallar_tabPage1.UseVisualStyleBackColor = true;
            // 
            // kodsuz_mallar_yenile_button1
            // 
            this.kodsuz_mallar_yenile_button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.kodsuz_mallar_yenile_button1.Location = new System.Drawing.Point(28, 374);
            this.kodsuz_mallar_yenile_button1.Name = "kodsuz_mallar_yenile_button1";
            this.kodsuz_mallar_yenile_button1.Size = new System.Drawing.Size(89, 30);
            this.kodsuz_mallar_yenile_button1.TabIndex = 14;
            this.kodsuz_mallar_yenile_button1.Text = "Yenilə";
            this.kodsuz_mallar_yenile_button1.UseVisualStyleBackColor = true;
            this.kodsuz_mallar_yenile_button1.Click += new System.EventHandler(this.kodsuz_mallar_yenile_button1_Click);
            // 
            // strix_kodlar_label
            // 
            this.strix_kodlar_label.AutoSize = true;
            this.strix_kodlar_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.strix_kodlar_label.Location = new System.Drawing.Point(588, 20);
            this.strix_kodlar_label.Name = "strix_kodlar_label";
            this.strix_kodlar_label.Size = new System.Drawing.Size(60, 20);
            this.strix_kodlar_label.TabIndex = 13;
            this.strix_kodlar_label.Text = "Kodlar";
            // 
            // mallarin_kodlari_listbox
            // 
            this.mallarin_kodlari_listbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mallarin_kodlari_listbox.FormattingEnabled = true;
            this.mallarin_kodlari_listbox.ItemHeight = 16;
            this.mallarin_kodlari_listbox.Location = new System.Drawing.Point(518, 46);
            this.mallarin_kodlari_listbox.Name = "mallarin_kodlari_listbox";
            this.mallarin_kodlari_listbox.Size = new System.Drawing.Size(221, 308);
            this.mallarin_kodlari_listbox.TabIndex = 12;
            this.mallarin_kodlari_listbox.SelectedIndexChanged += new System.EventHandler(this.mallarin_kodlari_listbox_SelectedIndexChanged);
            // 
            // yukle_duymesi
            // 
            this.yukle_duymesi.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.yukle_duymesi.Location = new System.Drawing.Point(392, 374);
            this.yukle_duymesi.Name = "yukle_duymesi";
            this.yukle_duymesi.Size = new System.Drawing.Size(120, 30);
            this.yukle_duymesi.TabIndex = 11;
            this.yukle_duymesi.Text = "Yüklə";
            this.yukle_duymesi.UseVisualStyleBackColor = true;
            this.yukle_duymesi.Click += new System.EventHandler(this.yukle_duymesi_Click);
            // 
            // legv_et_button
            // 
            this.legv_et_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.legv_et_button.Location = new System.Drawing.Point(267, 374);
            this.legv_et_button.Name = "legv_et_button";
            this.legv_et_button.Size = new System.Drawing.Size(118, 30);
            this.legv_et_button.TabIndex = 10;
            this.legv_et_button.Text = "Ləğv et";
            this.legv_et_button.UseVisualStyleBackColor = true;
            this.legv_et_button.Click += new System.EventHandler(this.legv_et_button_Click);
            // 
            // hamisini_sec_button
            // 
            this.hamisini_sec_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.hamisini_sec_button.Location = new System.Drawing.Point(123, 374);
            this.hamisini_sec_button.Name = "hamisini_sec_button";
            this.hamisini_sec_button.Size = new System.Drawing.Size(138, 30);
            this.hamisini_sec_button.TabIndex = 9;
            this.hamisini_sec_button.Text = "Hamısını seç";
            this.hamisini_sec_button.UseVisualStyleBackColor = true;
            this.hamisini_sec_button.Click += new System.EventHandler(this.hamisini_sec_button_Click);
            // 
            // bar_kodsuz_mallarin_siyahisi
            // 
            this.bar_kodsuz_mallarin_siyahisi.AutoSize = true;
            this.bar_kodsuz_mallarin_siyahisi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bar_kodsuz_mallarin_siyahisi.Location = new System.Drawing.Point(119, 20);
            this.bar_kodsuz_mallarin_siyahisi.Name = "bar_kodsuz_mallarin_siyahisi";
            this.bar_kodsuz_mallarin_siyahisi.Size = new System.Drawing.Size(229, 20);
            this.bar_kodsuz_mallarin_siyahisi.TabIndex = 8;
            this.bar_kodsuz_mallarin_siyahisi.Text = "Bar kodsuz malların siyahısı";
            // 
            // mallarin_siyahisi_listbox
            // 
            this.mallarin_siyahisi_listbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.mallarin_siyahisi_listbox.FormattingEnabled = true;
            this.mallarin_siyahisi_listbox.Location = new System.Drawing.Point(28, 46);
            this.mallarin_siyahisi_listbox.Name = "mallarin_siyahisi_listbox";
            this.mallarin_siyahisi_listbox.Size = new System.Drawing.Size(484, 310);
            this.mallarin_siyahisi_listbox.TabIndex = 7;
            this.mallarin_siyahisi_listbox.SelectedIndexChanged += new System.EventHandler(this.mallarin_siyahisi_listbox_SelectedIndexChanged);
            // 
            // malin_qaytarilmasi_tabPage1
            // 
            this.malin_qaytarilmasi_tabPage1.Controls.Add(this.malin_qaytarilmasi_sqcem_label37);
            this.malin_qaytarilmasi_tabPage1.Controls.Add(this.malin_qaytarilmasi_sq_label37);
            this.malin_qaytarilmasi_tabPage1.Controls.Add(this.label36);
            this.malin_qaytarilmasi_tabPage1.Controls.Add(this.label30);
            this.malin_qaytarilmasi_tabPage1.Controls.Add(this.malin_qaytarilmasi_qaytar_button1);
            this.malin_qaytarilmasi_tabPage1.Controls.Add(this.malin_qaytarilmasi_miqdar_textBox2);
            this.malin_qaytarilmasi_tabPage1.Controls.Add(this.label24);
            this.malin_qaytarilmasi_tabPage1.Controls.Add(this.malin_qaytarilmasi_bar_kod_textBox1);
            this.malin_qaytarilmasi_tabPage1.Controls.Add(this.label23);
            this.malin_qaytarilmasi_tabPage1.Location = new System.Drawing.Point(4, 29);
            this.malin_qaytarilmasi_tabPage1.Name = "malin_qaytarilmasi_tabPage1";
            this.malin_qaytarilmasi_tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.malin_qaytarilmasi_tabPage1.Size = new System.Drawing.Size(1262, 709);
            this.malin_qaytarilmasi_tabPage1.TabIndex = 5;
            this.malin_qaytarilmasi_tabPage1.Text = "MALIN QAYTARILMASI";
            this.malin_qaytarilmasi_tabPage1.UseVisualStyleBackColor = true;
            // 
            // malin_qaytarilmasi_sqcem_label37
            // 
            this.malin_qaytarilmasi_sqcem_label37.AutoSize = true;
            this.malin_qaytarilmasi_sqcem_label37.Location = new System.Drawing.Point(257, 197);
            this.malin_qaytarilmasi_sqcem_label37.Name = "malin_qaytarilmasi_sqcem_label37";
            this.malin_qaytarilmasi_sqcem_label37.Size = new System.Drawing.Size(0, 20);
            this.malin_qaytarilmasi_sqcem_label37.TabIndex = 8;
            // 
            // malin_qaytarilmasi_sq_label37
            // 
            this.malin_qaytarilmasi_sq_label37.AutoSize = true;
            this.malin_qaytarilmasi_sq_label37.Location = new System.Drawing.Point(257, 148);
            this.malin_qaytarilmasi_sq_label37.Name = "malin_qaytarilmasi_sq_label37";
            this.malin_qaytarilmasi_sq_label37.Size = new System.Drawing.Size(0, 20);
            this.malin_qaytarilmasi_sq_label37.TabIndex = 7;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(52, 197);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(154, 20);
            this.label36.TabIndex = 6;
            this.label36.Text = "Cəm satış qiyməti:";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(90, 148);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(116, 20);
            this.label30.TabIndex = 5;
            this.label30.Text = "Satış qiyməti:";
            // 
            // malin_qaytarilmasi_qaytar_button1
            // 
            this.malin_qaytarilmasi_qaytar_button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.malin_qaytarilmasi_qaytar_button1.ForeColor = System.Drawing.Color.Red;
            this.malin_qaytarilmasi_qaytar_button1.Location = new System.Drawing.Point(428, 54);
            this.malin_qaytarilmasi_qaytar_button1.Name = "malin_qaytarilmasi_qaytar_button1";
            this.malin_qaytarilmasi_qaytar_button1.Size = new System.Drawing.Size(116, 42);
            this.malin_qaytarilmasi_qaytar_button1.TabIndex = 4;
            this.malin_qaytarilmasi_qaytar_button1.Text = "Qaytar";
            this.malin_qaytarilmasi_qaytar_button1.UseVisualStyleBackColor = true;
            this.malin_qaytarilmasi_qaytar_button1.Click += new System.EventHandler(this.malin_qaytarilmasi_qaytar_button1_Click);
            // 
            // malin_qaytarilmasi_miqdar_textBox2
            // 
            this.malin_qaytarilmasi_miqdar_textBox2.Location = new System.Drawing.Point(274, 70);
            this.malin_qaytarilmasi_miqdar_textBox2.Name = "malin_qaytarilmasi_miqdar_textBox2";
            this.malin_qaytarilmasi_miqdar_textBox2.Size = new System.Drawing.Size(118, 26);
            this.malin_qaytarilmasi_miqdar_textBox2.TabIndex = 3;
            this.malin_qaytarilmasi_miqdar_textBox2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.malin_qaytarilmasi_miqdar_textBox2_KeyPress);
            this.malin_qaytarilmasi_miqdar_textBox2.KeyUp += new System.Windows.Forms.KeyEventHandler(this.malin_qaytarilmasi_miqdar_textBox2_KeyUp);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(274, 34);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(63, 20);
            this.label24.TabIndex = 2;
            this.label24.Text = "Miqdar";
            // 
            // malin_qaytarilmasi_bar_kod_textBox1
            // 
            this.malin_qaytarilmasi_bar_kod_textBox1.Location = new System.Drawing.Point(20, 70);
            this.malin_qaytarilmasi_bar_kod_textBox1.Name = "malin_qaytarilmasi_bar_kod_textBox1";
            this.malin_qaytarilmasi_bar_kod_textBox1.Size = new System.Drawing.Size(215, 26);
            this.malin_qaytarilmasi_bar_kod_textBox1.TabIndex = 1;
            this.malin_qaytarilmasi_bar_kod_textBox1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.malin_qaytarilmasi_bar_kod_textBox1_KeyDown);
            this.malin_qaytarilmasi_bar_kod_textBox1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.malin_qaytarilmasi_bar_kod_textBox1_KeyPress);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(20, 34);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(73, 20);
            this.label23.TabIndex = 0;
            this.label23.Text = "Bar Kod";
            // 
            // diger_balans_tabPage1
            // 
            this.diger_balans_tabPage1.Controls.Add(this.tableLayoutPanel22);
            this.diger_balans_tabPage1.Location = new System.Drawing.Point(4, 29);
            this.diger_balans_tabPage1.Name = "diger_balans_tabPage1";
            this.diger_balans_tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.diger_balans_tabPage1.Size = new System.Drawing.Size(1262, 709);
            this.diger_balans_tabPage1.TabIndex = 6;
            this.diger_balans_tabPage1.Text = "Balans";
            this.diger_balans_tabPage1.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel22
            // 
            this.tableLayoutPanel22.ColumnCount = 1;
            this.tableLayoutPanel22.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel22.Controls.Add(this.tableLayoutPanel23, 0, 0);
            this.tableLayoutPanel22.Controls.Add(this.tableLayoutPanel24, 0, 3);
            this.tableLayoutPanel22.Controls.Add(this.tableLayoutPanel25, 0, 1);
            this.tableLayoutPanel22.Controls.Add(this.tableLayoutPanel27, 0, 2);
            this.tableLayoutPanel22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel22.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel22.Name = "tableLayoutPanel22";
            this.tableLayoutPanel22.RowCount = 4;
            this.tableLayoutPanel22.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel22.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel22.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel22.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel22.Size = new System.Drawing.Size(1256, 703);
            this.tableLayoutPanel22.TabIndex = 4;
            // 
            // tableLayoutPanel23
            // 
            this.tableLayoutPanel23.ColumnCount = 2;
            this.tableLayoutPanel23.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 500F));
            this.tableLayoutPanel23.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel23.Controls.Add(this.label50, 0, 0);
            this.tableLayoutPanel23.Controls.Add(this.magazanin_balansi_label50, 1, 0);
            this.tableLayoutPanel23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel23.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel23.Name = "tableLayoutPanel23";
            this.tableLayoutPanel23.RowCount = 1;
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel23.Size = new System.Drawing.Size(1250, 94);
            this.tableLayoutPanel23.TabIndex = 0;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label50.Font = new System.Drawing.Font("Microsoft Sans Serif", 40F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.ForeColor = System.Drawing.Color.Red;
            this.label50.Location = new System.Drawing.Point(3, 0);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(494, 94);
            this.label50.TabIndex = 1;
            this.label50.Text = "Balans AZN: ";
            this.label50.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // magazanin_balansi_label50
            // 
            this.magazanin_balansi_label50.AutoSize = true;
            this.magazanin_balansi_label50.Dock = System.Windows.Forms.DockStyle.Fill;
            this.magazanin_balansi_label50.Font = new System.Drawing.Font("Microsoft Sans Serif", 40F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.magazanin_balansi_label50.ForeColor = System.Drawing.Color.Green;
            this.magazanin_balansi_label50.Location = new System.Drawing.Point(503, 0);
            this.magazanin_balansi_label50.Name = "magazanin_balansi_label50";
            this.magazanin_balansi_label50.Size = new System.Drawing.Size(744, 94);
            this.magazanin_balansi_label50.TabIndex = 0;
            this.magazanin_balansi_label50.Text = "000";
            this.magazanin_balansi_label50.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel24
            // 
            this.tableLayoutPanel24.ColumnCount = 2;
            this.tableLayoutPanel24.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel24.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 300F));
            this.tableLayoutPanel24.Controls.Add(this.balans_emeliyyatlar_dgv, 0, 0);
            this.tableLayoutPanel24.Controls.Add(this.tableLayoutPanel26, 0, 1);
            this.tableLayoutPanel24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel24.Location = new System.Drawing.Point(3, 183);
            this.tableLayoutPanel24.Name = "tableLayoutPanel24";
            this.tableLayoutPanel24.RowCount = 2;
            this.tableLayoutPanel24.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel24.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel24.Size = new System.Drawing.Size(1250, 517);
            this.tableLayoutPanel24.TabIndex = 1;
            // 
            // balans_emeliyyatlar_dgv
            // 
            this.balans_emeliyyatlar_dgv.AllowUserToAddRows = false;
            this.balans_emeliyyatlar_dgv.AllowUserToDeleteRows = false;
            this.balans_emeliyyatlar_dgv.AllowUserToOrderColumns = true;
            this.balans_emeliyyatlar_dgv.AllowUserToResizeRows = false;
            this.balans_emeliyyatlar_dgv.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.balans_emeliyyatlar_dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.balans_emeliyyatlar_dgv.Dock = System.Windows.Forms.DockStyle.Fill;
            this.balans_emeliyyatlar_dgv.Location = new System.Drawing.Point(3, 3);
            this.balans_emeliyyatlar_dgv.MultiSelect = false;
            this.balans_emeliyyatlar_dgv.Name = "balans_emeliyyatlar_dgv";
            this.balans_emeliyyatlar_dgv.ReadOnly = true;
            this.balans_emeliyyatlar_dgv.RowHeadersVisible = false;
            this.balans_emeliyyatlar_dgv.Size = new System.Drawing.Size(944, 471);
            this.balans_emeliyyatlar_dgv.TabIndex = 5;
            // 
            // tableLayoutPanel26
            // 
            this.tableLayoutPanel26.ColumnCount = 5;
            this.tableLayoutPanel26.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
            this.tableLayoutPanel26.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel26.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
            this.tableLayoutPanel26.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel26.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel26.Controls.Add(this.label58, 2, 0);
            this.tableLayoutPanel26.Controls.Add(this.label57, 0, 0);
            this.tableLayoutPanel26.Controls.Add(this.balans_emeliyyatlari_setir_sayi_label58, 1, 0);
            this.tableLayoutPanel26.Controls.Add(this.balans_emeliyyatlari_cem_pul_label58, 3, 0);
            this.tableLayoutPanel26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel26.Location = new System.Drawing.Point(3, 480);
            this.tableLayoutPanel26.Name = "tableLayoutPanel26";
            this.tableLayoutPanel26.RowCount = 1;
            this.tableLayoutPanel26.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel26.Size = new System.Drawing.Size(944, 34);
            this.tableLayoutPanel26.TabIndex = 4;
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label58.Location = new System.Drawing.Point(243, 0);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(134, 34);
            this.label58.TabIndex = 2;
            this.label58.Text = "Cəm məbləğ:";
            this.label58.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label57.Location = new System.Drawing.Point(3, 0);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(134, 34);
            this.label57.TabIndex = 0;
            this.label57.Text = "Sətir sayı:";
            this.label57.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // balans_emeliyyatlari_setir_sayi_label58
            // 
            this.balans_emeliyyatlari_setir_sayi_label58.AutoSize = true;
            this.balans_emeliyyatlari_setir_sayi_label58.Dock = System.Windows.Forms.DockStyle.Fill;
            this.balans_emeliyyatlari_setir_sayi_label58.Location = new System.Drawing.Point(143, 0);
            this.balans_emeliyyatlari_setir_sayi_label58.Name = "balans_emeliyyatlari_setir_sayi_label58";
            this.balans_emeliyyatlari_setir_sayi_label58.Size = new System.Drawing.Size(94, 34);
            this.balans_emeliyyatlari_setir_sayi_label58.TabIndex = 1;
            this.balans_emeliyyatlari_setir_sayi_label58.Text = ":::";
            this.balans_emeliyyatlari_setir_sayi_label58.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // balans_emeliyyatlari_cem_pul_label58
            // 
            this.balans_emeliyyatlari_cem_pul_label58.AutoSize = true;
            this.balans_emeliyyatlari_cem_pul_label58.Dock = System.Windows.Forms.DockStyle.Fill;
            this.balans_emeliyyatlari_cem_pul_label58.Location = new System.Drawing.Point(383, 0);
            this.balans_emeliyyatlari_cem_pul_label58.Name = "balans_emeliyyatlari_cem_pul_label58";
            this.balans_emeliyyatlari_cem_pul_label58.Size = new System.Drawing.Size(94, 34);
            this.balans_emeliyyatlari_cem_pul_label58.TabIndex = 3;
            this.balans_emeliyyatlari_cem_pul_label58.Text = ":::";
            this.balans_emeliyyatlari_cem_pul_label58.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel25
            // 
            this.tableLayoutPanel25.ColumnCount = 9;
            this.tableLayoutPanel25.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 180F));
            this.tableLayoutPanel25.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 180F));
            this.tableLayoutPanel25.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel25.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tableLayoutPanel25.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 220F));
            this.tableLayoutPanel25.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tableLayoutPanel25.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 220F));
            this.tableLayoutPanel25.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
            this.tableLayoutPanel25.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel25.Controls.Add(this.son_dateTimePicker1, 6, 0);
            this.tableLayoutPanel25.Controls.Add(this.balansa_medaxil_button1, 0, 0);
            this.tableLayoutPanel25.Controls.Add(this.balansa_mexaric_button1, 1, 0);
            this.tableLayoutPanel25.Controls.Add(this.balansi_yenile_button1, 2, 0);
            this.tableLayoutPanel25.Controls.Add(this.label51, 3, 0);
            this.tableLayoutPanel25.Controls.Add(this.label56, 5, 0);
            this.tableLayoutPanel25.Controls.Add(this.bas_dateTimePicker1, 4, 0);
            this.tableLayoutPanel25.Controls.Add(this.balans_medaxil_tipi_comboBox1, 7, 0);
            this.tableLayoutPanel25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel25.Location = new System.Drawing.Point(3, 103);
            this.tableLayoutPanel25.Name = "tableLayoutPanel25";
            this.tableLayoutPanel25.RowCount = 1;
            this.tableLayoutPanel25.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel25.Size = new System.Drawing.Size(1250, 34);
            this.tableLayoutPanel25.TabIndex = 2;
            // 
            // son_dateTimePicker1
            // 
            this.son_dateTimePicker1.CustomFormat = "yyyy-MM-dd HH:mm:ss";
            this.son_dateTimePicker1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.son_dateTimePicker1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.son_dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.son_dateTimePicker1.Location = new System.Drawing.Point(803, 3);
            this.son_dateTimePicker1.Name = "son_dateTimePicker1";
            this.son_dateTimePicker1.Size = new System.Drawing.Size(214, 23);
            this.son_dateTimePicker1.TabIndex = 8;
            // 
            // balansa_medaxil_button1
            // 
            this.balansa_medaxil_button1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.balansa_medaxil_button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.balansa_medaxil_button1.Location = new System.Drawing.Point(3, 3);
            this.balansa_medaxil_button1.Name = "balansa_medaxil_button1";
            this.balansa_medaxil_button1.Size = new System.Drawing.Size(174, 28);
            this.balansa_medaxil_button1.TabIndex = 2;
            this.balansa_medaxil_button1.Text = "Balansa mədaxil";
            this.balansa_medaxil_button1.UseVisualStyleBackColor = true;
            this.balansa_medaxil_button1.Click += new System.EventHandler(this.balansa_medaxil_button1_Click);
            // 
            // balansa_mexaric_button1
            // 
            this.balansa_mexaric_button1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.balansa_mexaric_button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.balansa_mexaric_button1.Location = new System.Drawing.Point(183, 3);
            this.balansa_mexaric_button1.Name = "balansa_mexaric_button1";
            this.balansa_mexaric_button1.Size = new System.Drawing.Size(174, 28);
            this.balansa_mexaric_button1.TabIndex = 3;
            this.balansa_mexaric_button1.Text = "Balansdan məxaric";
            this.balansa_mexaric_button1.UseVisualStyleBackColor = true;
            this.balansa_mexaric_button1.Click += new System.EventHandler(this.balansa_mexaric_button1_Click);
            // 
            // balansi_yenile_button1
            // 
            this.balansi_yenile_button1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.balansi_yenile_button1.Location = new System.Drawing.Point(363, 3);
            this.balansi_yenile_button1.Name = "balansi_yenile_button1";
            this.balansi_yenile_button1.Size = new System.Drawing.Size(94, 28);
            this.balansi_yenile_button1.TabIndex = 4;
            this.balansi_yenile_button1.Text = "Yenilə";
            this.balansi_yenile_button1.UseVisualStyleBackColor = true;
            this.balansi_yenile_button1.Click += new System.EventHandler(this.balansi_yenile_button1_Click);
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label51.Location = new System.Drawing.Point(463, 0);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(54, 34);
            this.label51.TabIndex = 5;
            this.label51.Text = "Baş";
            this.label51.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label56.Location = new System.Drawing.Point(743, 0);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(54, 34);
            this.label56.TabIndex = 6;
            this.label56.Text = "Son";
            this.label56.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // bas_dateTimePicker1
            // 
            this.bas_dateTimePicker1.CustomFormat = "yyyy-MM-dd HH:mm:ss";
            this.bas_dateTimePicker1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bas_dateTimePicker1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bas_dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.bas_dateTimePicker1.Location = new System.Drawing.Point(523, 3);
            this.bas_dateTimePicker1.Name = "bas_dateTimePicker1";
            this.bas_dateTimePicker1.Size = new System.Drawing.Size(214, 23);
            this.bas_dateTimePicker1.TabIndex = 7;
            // 
            // balans_medaxil_tipi_comboBox1
            // 
            this.balans_medaxil_tipi_comboBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.balans_medaxil_tipi_comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.balans_medaxil_tipi_comboBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.balans_medaxil_tipi_comboBox1.FormattingEnabled = true;
            this.balans_medaxil_tipi_comboBox1.Items.AddRange(new object[] {
            "Mədaxil-Məxaric",
            "Mədaxil",
            "Məxaric"});
            this.balans_medaxil_tipi_comboBox1.Location = new System.Drawing.Point(1023, 3);
            this.balans_medaxil_tipi_comboBox1.Name = "balans_medaxil_tipi_comboBox1";
            this.balans_medaxil_tipi_comboBox1.Size = new System.Drawing.Size(134, 23);
            this.balans_medaxil_tipi_comboBox1.TabIndex = 9;
            // 
            // tableLayoutPanel27
            // 
            this.tableLayoutPanel27.ColumnCount = 5;
            this.tableLayoutPanel27.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel27.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 200F));
            this.tableLayoutPanel27.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 160F));
            this.tableLayoutPanel27.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 200F));
            this.tableLayoutPanel27.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel27.Controls.Add(this.label59, 0, 0);
            this.tableLayoutPanel27.Controls.Add(this.balans_firma_adlari_comboBox1, 1, 0);
            this.tableLayoutPanel27.Controls.Add(this.balans_yeni_firma_button1, 2, 0);
            this.tableLayoutPanel27.Controls.Add(this.balans_bugun_checkBox1, 3, 0);
            this.tableLayoutPanel27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel27.Location = new System.Drawing.Point(3, 143);
            this.tableLayoutPanel27.Name = "tableLayoutPanel27";
            this.tableLayoutPanel27.RowCount = 1;
            this.tableLayoutPanel27.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel27.Size = new System.Drawing.Size(1250, 34);
            this.tableLayoutPanel27.TabIndex = 3;
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label59.Location = new System.Drawing.Point(3, 0);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(94, 34);
            this.label59.TabIndex = 0;
            this.label59.Text = "Firma:";
            this.label59.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // balans_firma_adlari_comboBox1
            // 
            this.balans_firma_adlari_comboBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.balans_firma_adlari_comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.balans_firma_adlari_comboBox1.FormattingEnabled = true;
            this.balans_firma_adlari_comboBox1.Location = new System.Drawing.Point(103, 3);
            this.balans_firma_adlari_comboBox1.Name = "balans_firma_adlari_comboBox1";
            this.balans_firma_adlari_comboBox1.Size = new System.Drawing.Size(194, 28);
            this.balans_firma_adlari_comboBox1.TabIndex = 1;
            // 
            // balans_yeni_firma_button1
            // 
            this.balans_yeni_firma_button1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.balans_yeni_firma_button1.Location = new System.Drawing.Point(303, 3);
            this.balans_yeni_firma_button1.Name = "balans_yeni_firma_button1";
            this.balans_yeni_firma_button1.Size = new System.Drawing.Size(154, 28);
            this.balans_yeni_firma_button1.TabIndex = 2;
            this.balans_yeni_firma_button1.Text = "Yeni firma";
            this.balans_yeni_firma_button1.UseVisualStyleBackColor = true;
            this.balans_yeni_firma_button1.Click += new System.EventHandler(this.balans_yeni_firma_button1_Click);
            // 
            // balans_bugun_checkBox1
            // 
            this.balans_bugun_checkBox1.AutoSize = true;
            this.balans_bugun_checkBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.balans_bugun_checkBox1.Location = new System.Drawing.Point(463, 3);
            this.balans_bugun_checkBox1.Name = "balans_bugun_checkBox1";
            this.balans_bugun_checkBox1.Size = new System.Drawing.Size(194, 28);
            this.balans_bugun_checkBox1.TabIndex = 3;
            this.balans_bugun_checkBox1.Text = "Bu gün";
            this.balans_bugun_checkBox1.UseVisualStyleBackColor = true;
            // 
            // yeni_mal_4_button1
            // 
            this.yeni_mal_4_button1.Location = new System.Drawing.Point(467, 6);
            this.yeni_mal_4_button1.Name = "yeni_mal_4_button1";
            this.yeni_mal_4_button1.Size = new System.Drawing.Size(147, 37);
            this.yeni_mal_4_button1.TabIndex = 3;
            this.yeni_mal_4_button1.Text = "Yeni Mal-4";
            this.yeni_mal_4_button1.UseVisualStyleBackColor = true;
            this.yeni_mal_4_button1.Visible = false;
            this.yeni_mal_4_button1.Click += new System.EventHandler(this.yeni_mal_4_button1_Click_1);
            // 
            // yeni_mal_3_button1
            // 
            this.yeni_mal_3_button1.Location = new System.Drawing.Point(314, 6);
            this.yeni_mal_3_button1.Name = "yeni_mal_3_button1";
            this.yeni_mal_3_button1.Size = new System.Drawing.Size(147, 37);
            this.yeni_mal_3_button1.TabIndex = 2;
            this.yeni_mal_3_button1.Text = "Yeni Mal-3";
            this.yeni_mal_3_button1.UseVisualStyleBackColor = true;
            this.yeni_mal_3_button1.Visible = false;
            this.yeni_mal_3_button1.Click += new System.EventHandler(this.yeni_mal_3_button1_Click_1);
            // 
            // yeni_mal_2_button1
            // 
            this.yeni_mal_2_button1.Location = new System.Drawing.Point(161, 6);
            this.yeni_mal_2_button1.Name = "yeni_mal_2_button1";
            this.yeni_mal_2_button1.Size = new System.Drawing.Size(147, 37);
            this.yeni_mal_2_button1.TabIndex = 1;
            this.yeni_mal_2_button1.Text = "Yeni Mal-2";
            this.yeni_mal_2_button1.UseVisualStyleBackColor = true;
            this.yeni_mal_2_button1.Visible = false;
            this.yeni_mal_2_button1.Click += new System.EventHandler(this.yeni_mal_2_button1_Click_1);
            // 
            // yeni_mal_1_button1
            // 
            this.yeni_mal_1_button1.Location = new System.Drawing.Point(8, 6);
            this.yeni_mal_1_button1.Name = "yeni_mal_1_button1";
            this.yeni_mal_1_button1.Size = new System.Drawing.Size(147, 37);
            this.yeni_mal_1_button1.TabIndex = 0;
            this.yeni_mal_1_button1.Text = "Yeni Mal-1";
            this.yeni_mal_1_button1.UseVisualStyleBackColor = true;
            this.yeni_mal_1_button1.Visible = false;
            this.yeni_mal_1_button1.Click += new System.EventHandler(this.yeni_mal_1_button1_Click);
            // 
            // gmv2TableAdapter
            // 
            this.gmv2TableAdapter.ClearBeforeFill = true;
            // 
            // Admin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1284, 781);
            this.Controls.Add(this.esas_tabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Admin";
            this.Text = "Admin";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Admin_FormClosing);
            this.Load += new System.EventHandler(this.Admin_Load);
            this.esas_tabControl1.ResumeLayout(false);
            this.mallar_tabPage1.ResumeLayout(false);
            this.mallar_tabControl1.ResumeLayout(false);
            this.mallar_hisse_tabPage1.ResumeLayout(false);
            this.mallar_esas_tableLayoutPanel1.ResumeLayout(false);
            this.mallar_asagi_tableLayoutPanel5.ResumeLayout(false);
            this.mallar_asagi_tableLayoutPanel5.PerformLayout();
            this.mallari_bolen_spliter.Panel1.ResumeLayout(false);
            this.mallari_bolen_spliter.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.mallari_bolen_spliter)).EndInit();
            this.mallari_bolen_spliter.ResumeLayout(false);
            this.mallar_siyahi_bolen_tableLayoutPanel6.ResumeLayout(false);
            this.mallar_esas_cedvel_tableLayoutPanel7.ResumeLayout(false);
            this.mallar_xeber_tableLayoutPanel8.ResumeLayout(false);
            this.mallar_xeber_tableLayoutPanel8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.mallar_dgv_esas)).EndInit();
            this.mallar_daxil_tableLayoutPanel9.ResumeLayout(false);
            this.mallar_daxil_tableLayoutPanel9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.daxil_dgv)).EndInit();
            this.duymeler_tableLayoutPanel10.ResumeLayout(false);
            this.real_mallar_tabPage1.ResumeLayout(false);
            this.mallar_real_mallar_esas_tableLayoutPanel19.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.rm_dgv)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.tableLayoutPanel20.ResumeLayout(false);
            this.tableLayoutPanel20.PerformLayout();
            this.yeni_mal_tabPage2.ResumeLayout(false);
            this.yeni_mal_tableLayoutPanel1.ResumeLayout(false);
            this.getirilen_mallar_tabPage1.ResumeLayout(false);
            this.getirilen_mallar_tabControl2.ResumeLayout(false);
            this.getirilen_mallar_esas_tabPage1.ResumeLayout(false);
            this.getirilen_mallar_tableLayoutPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.getirilen_m_adv)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gmv2BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mpdeaDataSet)).EndInit();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.getirilen_mallarin_umumi_siyahisi_d_g_v)).EndInit();
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel5.PerformLayout();
            this.tableLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel6.PerformLayout();
            this.tableLayoutPanel17.ResumeLayout(false);
            this.tableLayoutPanel17.PerformLayout();
            this.tableLayoutPanel18.ResumeLayout(false);
            this.tableLayoutPanel18.PerformLayout();
            this.hesabat_tabPage1.ResumeLayout(false);
            this.hesabat_tabControl1.ResumeLayout(false);
            this.hesabat_kassa_tabPage1.ResumeLayout(false);
            this.hesabat_kassa_tableLayoutPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.hesabat_esas_dgv)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.hesabat_bonus_kartlari_tabPage1.ResumeLayout(false);
            this.tableLayoutPanel10.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.abk_silinme_dgv)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.kassada_silinen_mallar_tabPage1.ResumeLayout(false);
            this.kassada_silinen_esas_tableLayoutPanel12.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.kassada_silinenler_dgv)).EndInit();
            this.kassada_silinen_panel3.ResumeLayout(false);
            this.kassada_silinen_panel3.PerformLayout();
            this.hesabat_malin_qaytarilmasi_tabPage1.ResumeLayout(false);
            this.tableLayoutPanel15.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.hes_malin_qayt_dgv)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.tableLayoutPanel16.ResumeLayout(false);
            this.tableLayoutPanel16.PerformLayout();
            this.hesabat_borclular_tabPage1.ResumeLayout(false);
            this.tableLayoutPanel19.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.hes_brlar_dgv)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.tableLayoutPanel21.ResumeLayout(false);
            this.tableLayoutPanel21.PerformLayout();
            this.bonus_tabPage1.ResumeLayout(false);
            this.bonus_esas_tableLayoutPanel1.ResumeLayout(false);
            this.siyahi_bonus_tableLayoutPanel2.ResumeLayout(false);
            this.siyahi_bonus_tableLayoutPanel2.PerformLayout();
            this.bonus_sag_tableLayoutPanel3.ResumeLayout(false);
            this.yeni_b_kart_groupBox3.ResumeLayout(false);
            this.yeni_b_kart_groupBox3.PerformLayout();
            this.bonus_axtaris_groupBox4.ResumeLayout(false);
            this.bonus_axtaris_groupBox4.PerformLayout();
            this.sazlamalar_tabPage1.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.bonus_k_tabPage1.ResumeLayout(false);
            this.bonus_k_tabPage1.PerformLayout();
            this.elave_tabPage2.ResumeLayout(false);
            this.elave_tabPage2.PerformLayout();
            this.sazlamalar_mallar_tabPage1.ResumeLayout(false);
            this.sazlamalar_mallar_tableLayoutPanel12.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.sazlamalar_mallar_dgv)).EndInit();
            this.tableLayoutPanel13.ResumeLayout(false);
            this.tableLayoutPanel13.PerformLayout();
            this.sazlamalar_ktler_tabPage1.ResumeLayout(false);
            this.tableLayoutPanel12.ResumeLayout(false);
            this.tableLayoutPanel12.PerformLayout();
            this.tableLayoutPanel14.ResumeLayout(false);
            this.tableLayoutPanel14.PerformLayout();
            this.diger_tabPage1.ResumeLayout(false);
            this.diger_esas_tabControl1.ResumeLayout(false);
            this.borclar_tabPage1.ResumeLayout(false);
            this.tableLayoutPanel7.ResumeLayout(false);
            this.tableLayoutPanel8.ResumeLayout(false);
            this.tableLayoutPanel8.PerformLayout();
            this.tableLayoutPanel9.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tableLayoutPanel11.ResumeLayout(false);
            this.tableLayoutPanel11.PerformLayout();
            this.borclular_tabPage2.ResumeLayout(false);
            this.borclar_tableLayoutPanel1.ResumeLayout(false);
            this.borclar_axtar_tableLayoutPanel2.ResumeLayout(false);
            this.borclar_axtar_tableLayoutPanel2.PerformLayout();
            this.brc_yeni_tableLayoutPanel3.ResumeLayout(false);
            this.yeni_musteri_groupBox33.ResumeLayout(false);
            this.yeni_musteri_groupBox33.PerformLayout();
            this.silinmis_mallar_tabPage1.ResumeLayout(false);
            this.silinmis_mallar_tabPage1.PerformLayout();
            this.kodsuz_mallar_tabPage1.ResumeLayout(false);
            this.kodsuz_mallar_tabPage1.PerformLayout();
            this.malin_qaytarilmasi_tabPage1.ResumeLayout(false);
            this.malin_qaytarilmasi_tabPage1.PerformLayout();
            this.diger_balans_tabPage1.ResumeLayout(false);
            this.tableLayoutPanel22.ResumeLayout(false);
            this.tableLayoutPanel23.ResumeLayout(false);
            this.tableLayoutPanel23.PerformLayout();
            this.tableLayoutPanel24.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.balans_emeliyyatlar_dgv)).EndInit();
            this.tableLayoutPanel26.ResumeLayout(false);
            this.tableLayoutPanel26.PerformLayout();
            this.tableLayoutPanel25.ResumeLayout(false);
            this.tableLayoutPanel25.PerformLayout();
            this.tableLayoutPanel27.ResumeLayout(false);
            this.tableLayoutPanel27.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl esas_tabControl1;
        private System.Windows.Forms.TabPage mallar_tabPage1;
        private System.Windows.Forms.TabPage yeni_mal_tabPage2;
        private System.Windows.Forms.TabPage getirilen_mallar_tabPage1;
        private System.Windows.Forms.TabPage hesabat_tabPage1;
        private System.Windows.Forms.TabPage bonus_tabPage1;
        private System.Windows.Forms.TabPage sazlamalar_tabPage1;
        private System.Windows.Forms.TabPage diger_tabPage1;
        private System.Windows.Forms.TabControl diger_esas_tabControl1;
        private System.Windows.Forms.TabPage borclar_tabPage1;
        private System.Windows.Forms.TabPage borclular_tabPage2;
        private System.Windows.Forms.TabPage silinmis_mallar_tabPage1;
        //private System.Windows.Forms.TabPage komek_tabPage1;
        //private System.Windows.Forms.TabPage test_tabPage1;
        private System.Windows.Forms.Button yeni_mal_4_button1;
        private System.Windows.Forms.Button yeni_mal_3_button1;
        private System.Windows.Forms.Button yeni_mal_2_button1;
        private System.Windows.Forms.Button yeni_mal_1_button1;
        private System.Windows.Forms.TabControl mallar_tabControl1;
        private System.Windows.Forms.TabPage mallar_hisse_tabPage1;
        private System.Windows.Forms.TableLayoutPanel mallar_esas_tableLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel mallar_asagi_tableLayoutPanel5;
        private System.Windows.Forms.Button tam_ekran_mallar;
        private System.Windows.Forms.Label satis_cemi_mallar;
        private System.Windows.Forms.Button admin_daxil_olan_mallar_endirim_button;
        private System.Windows.Forms.Label psv_satis_label25;
        private System.Windows.Forms.Label psv_alis_label20;
        private System.Windows.Forms.Label alis_cemi_mallar;
        private System.Windows.Forms.SplitContainer mallari_bolen_spliter;
        private System.Windows.Forms.TableLayoutPanel mallar_siyahi_bolen_tableLayoutPanel6;
        private System.Windows.Forms.TreeView mallar_treeview_mallar;
        private System.Windows.Forms.TableLayoutPanel mallar_esas_cedvel_tableLayoutPanel7;
        private System.Windows.Forms.TableLayoutPanel mallar_xeber_tableLayoutPanel8;
        private System.Windows.Forms.Label xeberdarliq_label_mallar;
        private System.Windows.Forms.TextBox axtaris_textbox_mallar;
        private System.Windows.Forms.Label xeberdarliqlar_aktiv_label_1;
        private System.Windows.Forms.DataGridView mallar_dgv_esas;
        private System.Windows.Forms.TableLayoutPanel mallar_daxil_tableLayoutPanel9;
        private System.Windows.Forms.DataGridView daxil_dgv;
        private System.Windows.Forms.TableLayoutPanel duymeler_tableLayoutPanel10;
        private System.Windows.Forms.Button mallar_temizle_duymesi;
        private System.Windows.Forms.Button daxil_ok_mallar;
        private System.Windows.Forms.Button yeni_mal_mallar;
        private System.Windows.Forms.Button sil_getirilen_mallardan_birini;
        private System.Windows.Forms.Button daxil_legv_mallar;
        private System.Windows.Forms.Label psv_daxil_label57;
        private System.Windows.Forms.TableLayoutPanel yeni_mal_tableLayoutPanel1;
        private System.Windows.Forms.ListBox yeni_mal_kt_listBox1;
        private System.Windows.Forms.TableLayoutPanel borclar_tableLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel borclar_axtar_tableLayoutPanel2;
        private System.Windows.Forms.Label mus_label47;
        private System.Windows.Forms.TextBox borclular_axtar_textBox2;
        private System.Windows.Forms.Label axtar_psv_label48;
        private System.Windows.Forms.ListBox borclular_musleriler_listBox;
        private System.Windows.Forms.TableLayoutPanel brc_yeni_tableLayoutPanel3;
        private System.Windows.Forms.GroupBox yeni_musteri_groupBox33;
        private System.Windows.Forms.TextBox borclular_yeni_musteri_textBox;
        private System.Windows.Forms.Button borclular_yeni_musteri_button;
        private System.Windows.Forms.Label ad_sad_label49_psv;
        private System.Windows.Forms.TableLayoutPanel bonus_esas_tableLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel siyahi_bonus_tableLayoutPanel2;
        private System.Windows.Forms.Label musteriler_psv_label4;
        private System.Windows.Forms.ListBox musteriler_listbox_bonus;
        private System.Windows.Forms.TableLayoutPanel bonus_sag_tableLayoutPanel3;
        private System.Windows.Forms.GroupBox yeni_b_kart_groupBox3;
        private System.Windows.Forms.TextBox yeni_kart_text_ad_soyad;
        private System.Windows.Forms.TextBox yeni_kart_kod;
        private System.Windows.Forms.Button yeni_bonus_karti_duymesi;
        private System.Windows.Forms.Label kod_label_kart;
        private System.Windows.Forms.Label ad_label_kart;
        private System.Windows.Forms.Button kohne_bonus_kartini_deyis;
        private System.Windows.Forms.GroupBox bonus_axtaris_groupBox4;
        private System.Windows.Forms.TextBox axtar_textbox_koda_gore;
        private System.Windows.Forms.Label bar_kod_label_axtar;
        private System.Windows.Forms.TextBox axtar_textbox_ada_gore;
        private System.Windows.Forms.Label ad_label_axtar;
        private System.Windows.Forms.Button bonus_kartini_sil_button5;
        private System.Windows.Forms.TabControl hesabat_tabControl1;
        private System.Windows.Forms.TabPage hesabat_kassa_tabPage1;
        private System.Windows.Forms.TableLayoutPanel hesabat_kassa_tableLayoutPanel1;
        private System.Windows.Forms.DataGridView hesabat_esas_dgv;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox axtar_text_hesabat;
        private System.Windows.Forms.ComboBox mal_tipleri_combobox_hesabat;
        private System.Windows.Forms.ComboBox kassalar_combobox_hesabat;
        private System.Windows.Forms.Label evvel_label;
        private System.Windows.Forms.Label son_label;
        private System.Windows.Forms.Button tarix_araligi_duymesi_hesabat;
        private System.Windows.Forms.DateTimePicker bas_tarix_hesabat;
        private System.Windows.Forms.DateTimePicker son_tarix_hesabat;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label cesid_sayi_label;
        private System.Windows.Forms.Label umumi_say_label;
        private System.Windows.Forms.Label umumi_say_label_aktiv;
        private System.Windows.Forms.Label cesid_sayi_label_aktiv;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label hesabat_satis_cemi_aktiv_label3;
        private System.Windows.Forms.Label hesabat_gelir_cemi_aktiv_label3;
        private System.Windows.Forms.Button hesabat_cedveli_cap_et_button1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage bonus_k_tabPage1;
        private System.Windows.Forms.Button sazlamalar_deyisiklikleri_kassaya_gonder_button;
        private System.Windows.Forms.CheckBox srok_aktiv_edilsin_checkBox;
        private System.Windows.Forms.Button alici_bildirisi_gunu_button;
        private System.Windows.Forms.CheckBox cekde_musterilerin_sroku_cap_olunsun_checkBox;
        private System.Windows.Forms.Button butun_musterilerin_srok_gununu_deyis_button;
        private System.Windows.Forms.CheckBox cekde_musteri_xali_gorunsun_checkBox;
        private System.Windows.Forms.Button admin_sazlamalar_faiz_standart_button;
        private System.Windows.Forms.Button butun_musterilerin_bonus_faizini_deyis_button;
        private System.Windows.Forms.TabPage elave_tabPage2;
        private System.Windows.Forms.TextBox bazaya_sorgu_textBox2;
        private System.Windows.Forms.Button bazaya_iud_sorgu_button6;
        private System.Windows.Forms.Button hesabat_kassani_bagla_button1;
        private System.Windows.Forms.TabControl getirilen_mallar_tabControl2;
        private System.Windows.Forms.TabPage getirilen_mallar_esas_tabPage1;
        private System.Windows.Forms.TableLayoutPanel getirilen_mallar_tableLayoutPanel2;
        private System.Windows.Forms.Button silinmis_mali_tam_sil;
        private System.Windows.Forms.Button silinmis_mali_geri_qaytar;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ListBox silinmis_mallar_kodlari;
        private System.Windows.Forms.ListBox silinmis_mallar_adlari;
        private ADGV.AdvancedDataGridView getirilen_m_adv;
        private mpdeaDataSet mpdeaDataSet;
        private System.Windows.Forms.BindingSource gmv2BindingSource;
        private mpdeaDataSetTableAdapters.gmv2TableAdapter gmv2TableAdapter;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Button gm_yenile_button1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.DateTimePicker son_tarix_qalan_mallarin;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.DateTimePicker bas_tarix_qalan_mallarin;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label gm_setir_sayi_label6;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label gm_cem_satis_meblegi_label7;
        private System.Windows.Forms.Label cem_mebleg_label7_passiv;
        private System.Windows.Forms.Label gm_cem_mebleg_label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label gm_cem_gelir_label7;
        private System.Windows.Forms.Button gm_bugun_button1;
        private System.Windows.Forms.Button yadda_saxla_button;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox sifre_textbox;
        private System.Windows.Forms.ListBox sifreler_listbox;
        private System.Windows.Forms.Button mali_redakte_et_button1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label gm_endirimli_cem_mebleg_label10;
        private System.Windows.Forms.ComboBox hesabat_satis_tipi_comboBox1;
        private System.Windows.Forms.Button hesabat_bugun_button1;
        private System.Windows.Forms.TabPage kodsuz_mallar_tabPage1;
        private System.Windows.Forms.Button kodsuz_mallar_yenile_button1;
        private System.Windows.Forms.Label strix_kodlar_label;
        private System.Windows.Forms.ListBox mallarin_kodlari_listbox;
        private System.Windows.Forms.Button yukle_duymesi;
        private System.Windows.Forms.Button legv_et_button;
        private System.Windows.Forms.Button hamisini_sec_button;
        private System.Windows.Forms.Label bar_kodsuz_mallarin_siyahisi;
        private System.Windows.Forms.CheckedListBox mallarin_siyahisi_listbox;
        //private System.Windows.Forms.TabPage sazlama_terezi_tabPage1;
        private System.Windows.Forms.DataGridViewTextBoxColumn kodDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn adDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn barKodDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tarixDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn miqdarDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn alışDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn məbləğDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn satışDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn satışMəbləğiDataGridViewTextBoxColumn;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel7;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel8;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox borclar_axtar_textBox2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ListBox borclar_listBox1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel9;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox borclar_yeni_musteri_textBox;
        private System.Windows.Forms.Button borclar_yeni_musteri_button;
        private System.Windows.Forms.Label label13;
        //private System.Windows.Forms.TabPage proqrami_sifirla_tabPage1;
        //private System.Windows.Forms.Button proqrami_sifirla_icra_et_button1;
        //private System.Windows.Forms.TextBox proqrami_sifirla_text_textBox1;
        //private System.Windows.Forms.Button diger_baza_ile_elaqe_testi_button1;
        //private System.Windows.Forms.Button yeni_proqramama_kecid_et_button1;
        private System.Windows.Forms.TabPage hesabat_bonus_kartlari_tabPage1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel10;
        private System.Windows.Forms.DataGridView abk_silinme_dgv;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button bonus_silinme_ok_button2;
        private System.Windows.Forms.DateTimePicker abk_silinme_bas_dateTimePicker1;
        private System.Windows.Forms.DateTimePicker abk_silinme_son_dateTimePicker1;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox abk_silinme_axtar_textBox1;
        private System.Windows.Forms.TabPage sazlamalar_mallar_tabPage1;
        private System.Windows.Forms.TextBox sazlamalar_mallar_silinmeli_ay_textBox1;
        private System.Windows.Forms.Button passiv_mallari_sil_button1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel11;
        private System.Windows.Forms.Button borclar_odenisi_yadda_saxla_button1;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox borclar_borcumuzun_miqdari_textBox1;
        private System.Windows.Forms.TabPage kassada_silinen_mallar_tabPage1;
        private System.Windows.Forms.TableLayoutPanel kassada_silinen_esas_tableLayoutPanel12;
        private System.Windows.Forms.DataGridView kassada_silinenler_dgv;
        private System.Windows.Forms.Panel kassada_silinen_panel3;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Button kassaad_silinen_ok_button2;
        private System.Windows.Forms.DateTimePicker kassada_silinen_bas_dateTimePicker1;
        private System.Windows.Forms.DateTimePicker kassada_silinen_son_dateTimePicker1;
        private System.Windows.Forms.ComboBox kassada_silinenler_kassalar_comboBox3;
        private System.Windows.Forms.TableLayoutPanel sazlamalar_mallar_tableLayoutPanel12;
        private System.Windows.Forms.DataGridView sazlamalar_mallar_dgv;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel13;
        private System.Windows.Forms.Button sazlamalar_mallar_hamisini_sil_button1;
        private System.Windows.Forms.Button sazlamalar_mallar_birini_sil_button2;
        private System.Windows.Forms.ComboBox mal_ktleri_combobox_hesabat;
        //private System.Windows.Forms.TextBox komekler_olan_textBox1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TabPage sazlamalar_ktler_tabPage1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel12;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.ListBox sazlamalar_ktler_listBox1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel14;
        private System.Windows.Forms.TextBox sazlamalar_ktler_adi_textBox1;
        private System.Windows.Forms.Button sazlamalar_ktler_adi_deyisdir_button1;
        private System.Windows.Forms.Button sazlamalar_ktler_siyahini_yenile_button1;
        private System.Windows.Forms.Button sazlamalar_ktler_yeni_kt_button1;
        private System.Windows.Forms.ListBox mallar_list_mallar;
        private System.Windows.Forms.TabPage malin_qaytarilmasi_tabPage1;
        private System.Windows.Forms.Button malin_qaytarilmasi_qaytar_button1;
        private System.Windows.Forms.TextBox malin_qaytarilmasi_miqdar_textBox2;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox malin_qaytarilmasi_bar_kod_textBox1;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Button mallar_qaytar_button1;
        private System.Windows.Forms.TabPage hesabat_malin_qaytarilmasi_tabPage1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel15;
        private System.Windows.Forms.DataGridView hes_malin_qayt_dgv;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.ComboBox hesabat_qaytar_mal_ktleri_comboBox3;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Button hesabat_qaytar_ok_button2;
        private System.Windows.Forms.DateTimePicker hesabat_qaytar_bas_dateTimePicker1;
        private System.Windows.Forms.DateTimePicker hesabat_qaytar_son_dateTimePicker1;
        private System.Windows.Forms.TextBox hesabat_qaytar_axtar_txt;
        private System.Windows.Forms.ComboBox hesabat_qaytar_mal_tipleri_comboBox3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel16;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label hesabat_qaytar_umumi_say_label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label malin_qaytarilmasi_sqcem_label37;
        private System.Windows.Forms.Label malin_qaytarilmasi_sq_label37;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.DataGridView getirilen_mallarin_umumi_siyahisi_d_g_v;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel17;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label gm_mdcem_label40;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel18;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label gm_sqcem_label40;
        private System.Windows.Forms.TabPage real_mallar_tabPage1;
        private System.Windows.Forms.TableLayoutPanel mallar_real_mallar_esas_tableLayoutPanel19;
        private System.Windows.Forms.DataGridView rm_dgv;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.ComboBox mal_ktleri_combobox_rm;
        private System.Windows.Forms.Button rm_ok_button2;
        private System.Windows.Forms.TextBox axtar_text_rm;
        private System.Windows.Forms.ComboBox mal_tipleri_combobox_rm;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel20;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label rm_say_label42;
        private System.Windows.Forms.Label rm_cem_mq__label42;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label rm_cem_sq_label42;
        private System.Windows.Forms.Label rm_cem_md_label42;
        private System.Windows.Forms.Label rm_cem_gelir_label42;
        private System.Windows.Forms.TabPage hesabat_borclular_tabPage1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel19;
        private System.Windows.Forms.DataGridView hes_brlar_dgv;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.ComboBox hes_brclar_borc_tipi_comboBox2;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Button hes_brlar_ok_button2;
        private System.Windows.Forms.DateTimePicker hes_brlar_bas_dateTimePicker;
        private System.Windows.Forms.DateTimePicker hes_brlar_son_dateTimePicker;
        private System.Windows.Forms.TextBox hes_brlar_axtar_textBox;
        private System.Windows.Forms.ComboBox brlar_combobox_hesabat;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel21;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label umumi_say_label_aktiv_hes_brlar;
        private System.Windows.Forms.Label cem_mebleg_label_aktiv_hes_brlar;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.TabPage diger_balans_tabPage1;
        private System.Windows.Forms.Button balansa_medaxil_button1;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label magazanin_balansi_label50;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel22;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel23;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel24;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel25;
        private System.Windows.Forms.Button balansa_mexaric_button1;
        private System.Windows.Forms.Button balansi_yenile_button1;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.DateTimePicker son_dateTimePicker1;
        private System.Windows.Forms.DateTimePicker bas_dateTimePicker1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel26;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label balans_emeliyyatlari_setir_sayi_label58;
        private System.Windows.Forms.DataGridView balans_emeliyyatlar_dgv;
        private System.Windows.Forms.ComboBox balans_medaxil_tipi_comboBox1;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label balans_emeliyyatlari_cem_pul_label58;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel27;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.ComboBox balans_firma_adlari_comboBox1;
        private System.Windows.Forms.Button balans_yeni_firma_button1;
        private System.Windows.Forms.CheckBox balans_bugun_checkBox1;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label hesabat_satis_cemi_endirimli_aktiv_label3;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label kassa_endirim_meblegi_label62;
        private System.Windows.Forms.CheckBox bonusyes;
        private System.Windows.Forms.CheckBox chekyes;
        private System.Windows.Forms.TextBox txtkasasayi;
        private System.Windows.Forms.Label label62;
    }
}