﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MagazaProqramiDEA
{
    public partial class Kassa : Form
    {   //hazir
        private int kk;

        public static string bk = "";
        string borclunun_adi_siyahidan_secilen = "";
        // faylin cap olunmasi ucun obyekt
        System.IO.StreamReader faylinCapi;
        // cap olunan faylin fontu ucun
        System.Drawing.Font printFontu;

        // axtarilan malin kodu bu deyisende saxlanilir
        string axtarilan_malin_kodu = "";

        static string indiki_tarix_silinen_f7_ucun = "";
       

        // bu listler satilan malin melumatlarini list olaraq saxlayacaq
        public static List<string> adList = new List<string>();

        public static List<double> sqList = new List<double>(); public static List<double> sqEndirimliList = new List<double>();

        public static List<double> mqList = new List<double>();

        public static List<double> sqcemList = new List<double>();

        public static List<string> bkList = new List<string>();
        public static List<int> tipList = new List<int>();

        public static List<int> tipsatisList = new List<int>();
        public static List<int> tipdeneList = new List<int>();
        //

        int bonusVerildi = 0;

        string bonusXali = "";
        string umumiBonusXali = "";

        string bonus_musteri_adi = "";
        private bool alicinin_sroku_limite_catib;
      
        public Kassa()
        {
            InitializeComponent();
        }
        //hazir
        public Kassa(int secilenIndeks)
        {
            InitializeComponent();
            this.kk = secilenIndeks;
        }
        //hazir
        private void Kassa_Load(object sender, EventArgs e)
        {
             this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None; 
            this.Text = "Kassa-" + kk;


            kassa_label.Text = "KASSA-" + kk;

            skaner_textbox.Focus();

            marketin_adi_label.Text = Baza.magazaAdi;

            if (Baza.tipSatis == 0)
            {
                kassa_alis_satis_rejimi_label4.Text = "S a t ı ş";
            }
            else if (Baza.tipSatis == 1)
            {
                kassa_alis_satis_rejimi_label4.Text = "Q a y t a r ı ş";
            }

            Baza.vaxti_kecen_bonuslari_sifirla_ve_tarixini_yenile();
            Baza.kohnelenBonusKartlariniSilTamam();
            Baza.mallar_update();

        }

        //hazir 
        public void axtaris_ucun_mallari_yukle()
        {

            this.mallar_dgv_kassa.DefaultCellStyle.Font = new Font("Tahoma", 14);

            mallar_dgv_kassa.DataSource = Baza.verilmis_sorguya_gore_dataset_ver("SELECT id as Kod,ad as 'Malın Adı',bk as 'Bar Kod',sq as 'Satış Qiyməti',plukodu as Plu  FROM mallar   where   aktiv=1 order by ad asc ;");
            mallar_dgv_kassa.DataMember = Baza.sTable;

            int en = Baza.ekranEn;

            DataGridViewColumn c0 = mallar_dgv_kassa.Columns[0];
            c0.Width = en / 100 * 8;
            DataGridViewColumn c1 = mallar_dgv_kassa.Columns[1];
            c1.Width = en / 100 * 50;
            DataGridViewColumn c2 = mallar_dgv_kassa.Columns[2];
            c2.Width = en / 100 * 16;
            DataGridViewColumn c3 = mallar_dgv_kassa.Columns[3];
            c3.Width = en / 100 * 16;
            DataGridViewColumn c4 = mallar_dgv_kassa.Columns[4];
            c4.Width = en / 100 * 8;


            borclular_cedvelini_yenile();
            
        }

        //hazir 
        public void borclular_cedvelini_yenile()
        {

            this.borclular_dgv_kassa.DefaultCellStyle.Font = new Font("Tahoma", 14);

            borclular_dgv_kassa.DataSource = Baza.verilmis_sorguya_gore_dataset_ver("SELECT id as Kod,ad as Ad,borc as Borc FROM borclular   where  aktiv=1 order by ad asc ");
            borclular_dgv_kassa.DataMember = Baza.sTable;
            kassada_borclularin_umumi_borcunu_hesabla();
        }

        //hazir 
        public void kassada_borclularin_umumi_borcunu_hesabla()
        {

            double umumi_borc = 0;
            int borclu_sayi = 0;
            borclu_sayi = borclular_dgv_kassa.RowCount;


            for (int i = 0; i < borclu_sayi; i++)
            {
                double borc = Convert.ToDouble("" + borclular_dgv_kassa.Rows[i].Cells[2].Value);
                umumi_borc += borc;
            }
            kassa_borclular_umumi_borc_aktiv_label4.Text = "" + umumi_borc;

        } 

        //hazir
        //private void Kassa_FormClosing(object sender, FormClosingEventArgs e)
        //{
        //    if (Baza.sifrem.Equals("2223")) { System.Windows.Forms.Application.Exit(); }
        //    else
        //    {
        //        if (e.CloseReason == CloseReason.UserClosing)
        //        {
        //            e.Cancel = true;

        //            if (MessageBox.Show("Proqramı bağlamağa əminsiniz?", Baza.adminAdi, MessageBoxButtons.YesNo) == DialogResult.Yes)
        //            {
        //                System.Windows.Forms.Application.Exit();
        //            }
        //            else
        //            {

        //            }
        //        }
        //    }
        //}


        //hazir 
        private void skaner_textbox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                Baza.bk_qlobal = skaner_textbox.Text;
                bk = Baza.bk_qlobal;

                satisa_basla(bk);

            }
            else
                if (e.KeyCode == Keys.F1)
                {
                    kassaF1();

                }
                else
                    if (e.KeyCode == Keys.F2)
                    {
                        kassada_f2_duymesine_basilir();

                    }
                    else
                        if (e.KeyCode == Keys.F11)
                        {
                            kassaF11();

                        }
                        else
                            if (e.KeyCode == Keys.F9)
                            {
                                kassaF9();

                            }
                        else if (e.KeyCode == Keys.F8)
                        {

                            kassaF8();
                        }
                        else

                            if (e.KeyCode == Keys.F7)
                            {

                                kassaF7();

                            }
                            else if (e.KeyCode == Keys.F3)
                            {
                                kassaF3();
                             
                            }
                            else




                                if (e.KeyCode == Keys.Up || e.KeyCode == Keys.Down)
                                {

                                    kassa_dgv.Focus();
                                }
                                else
                                    if (e.KeyCode == Keys.F6)
                                    {
                                        kassa_dgv.Focus();


                                    }
                                    else

                                        if (e.KeyCode == Keys.F5)
                                        {
                                            kassaF5();

                                        }
                                        else
                                            if (e.KeyCode == Keys.F4)
                                            {
                                                kassaF4();

                                            }
                                            else
                                                if (e.KeyCode == Keys.F10)
                                                {
                                                    kassaF10();

                                                }
        }
        public static double malinSatishiUcunTetbiqOlunanFaiz = 0;
        //hazir
        private void kassaF10()
        {


            bool endirimFaizleHesablansin = Baza.cedvelden_tek_setir("info", "daxili", "ad", "kassada-endirim-faizle-olsun-ya-meblegle").Equals("1");
            if (endirimFaizleHesablansin)
            {
                double tetbiqOlunanFaiz = 0;

                string faiz = Microsoft.VisualBasic.Interaction.InputBox("Tətbiq olunan endirim faizini daxil edin", "Endirim faizi", "10");
                if (faiz.Trim().Equals(""))
                {
                    Baza.msg("Boş qoymaq olmaz"); malinSatishiUcunTetbiqOlunanFaiz = 0;
                }
                else
                {
                    try
                    {
                        tetbiqOlunanFaiz = Double.Parse(faiz);

                    }
                    catch (Exception xeta)
                    {
                        tetbiqOlunanFaiz = 0;
                        Baza.msg("Ədədi düzgün daxil etmədiniz\n\n" + xeta.ToString());
                    }
                    malinSatishiUcunTetbiqOlunanFaiz = tetbiqOlunanFaiz;
                }
                if (malinSatishiUcunTetbiqOlunanFaiz < 0 || malinSatishiUcunTetbiqOlunanFaiz > 100) { malinSatishiUcunTetbiqOlunanFaiz = 0; }
                kassa_endirim_faizi_label2.Text = "" + malinSatishiUcunTetbiqOlunanFaiz;
                double umumiPulEndirimli = (Baza.kassaCem / 100) * (100 - malinSatishiUcunTetbiqOlunanFaiz);
                Baza.kassaCemEndirimli = umumiPulEndirimli;
                cem_mebleg_aktiv_label.Text = "" + umumiPulEndirimli;
                satilanMallarinEndirimliQiymetleriniHesablaVeListeYaz(malinSatishiUcunTetbiqOlunanFaiz);
            }
            else
            {
                double yekunMeblegDouble = 0;

                string yekunMebleg = Microsoft.VisualBasic.Interaction.InputBox("Endirimli yekun məbləği daxil edin", "Yekun məbləğ", ""+Baza.kassaCem);
                if (yekunMebleg.Trim().Equals(""))
                {
                    Baza.msg("Boş qoymaq olmaz"); yekunMeblegDouble = 0;
                }
                else
                {
                    try
                    {
                        yekunMeblegDouble = Double.Parse(yekunMebleg);

                    }
                    catch (Exception xeta)
                    {
                        yekunMeblegDouble = 0;
                        Baza.msg("Ədədi düzgün daxil etmədiniz\n\n" + xeta.ToString());
                    }
                    
                }
                if (yekunMeblegDouble == 0) { malinSatishiUcunTetbiqOlunanFaiz = 0; }
                else
                {
 
  double umumiPulEndirimli = yekunMeblegDouble;

                Baza.kassaCemEndirimli = umumiPulEndirimli;

                cem_mebleg_aktiv_label.Text = "" + umumiPulEndirimli;

              
                double tetbiqOlunanFaiz = umumiPulEndirimli * 100 / Baza.kassaCem;
                tetbiqOlunanFaiz = 100.0 - tetbiqOlunanFaiz;
                malinSatishiUcunTetbiqOlunanFaiz = tetbiqOlunanFaiz;
                tetbiqOlunanFaiz = Math.Round(tetbiqOlunanFaiz,2);
                satilanMallarinEndirimliQiymetleriniHesablaVeListeYaz(tetbiqOlunanFaiz); kassa_endirim_faizi_label2.Text = "" + tetbiqOlunanFaiz;
                }
              
            }
            

           
                        
        }
        //hazir
        private void satilanMallarinEndirimliQiymetleriniHesablaVeListeYaz(double malinSatishiUcunTetbiqOlunanFaiz)
        {
            for (int i = 0; i < sqList.Count; i++)
            {
                   
                double sq=sqList[i];
                double sqen = (sq / 100.0) * (100 - malinSatishiUcunTetbiqOlunanFaiz);
            
            sqEndirimliList[i]=sqen;
            }

           
        


         
          
                 
        }

        private void kassaF9()
        {
            borca_yaz_alishi_Duymesi_Basildi();
        }
        //hazir 
        private void kassaF4()
        {
            try
            {
                string kod = Microsoft.VisualBasic.Interaction.InputBox("Malın kodunu daxil edin", "Satıcı", "");

                if (Baza.cedvelde_serti_odeyen_setir_sayi("mallar", " where bk ='" + kod + "'") == 1)
                {
                    string ad = Baza.cedvelden_tek_setir("mallar", "ad", "bk", kod);

                    double sq = Baza.cedvelden_tek_double("mallar", "sq", "bk", kod, 4);


                    MessageBox.Show("Malın adı : " + ad + "\nMalın bar kodu : " + kod + "\nMalın satış qiyməti : " + sq + " AZN");
                }
                else
                {

                    MessageBox.Show("Bu mal bazada yoxdur");

                }

            }
            catch { }

            skaner_textbox.Text = "";
            skaner_textbox.Focus();
        }
        //hazir 
        private void kassaF3()
        {
            try
            {

                double mg = Convert.ToDouble(Microsoft.VisualBasic.Interaction.InputBox("Məbləği daxil edin", "Satıcı", ""));

                double qaliq = mg - Baza.kassaCemEndirimli;

                qaliq_pul_aktiv_label.Text = "" + qaliq + "";

            }
            catch { }
            skaner_textbox.Text = "";
            skaner_textbox.Focus();
        }
        //hazir 
        private void kassaF8()
        {
            string abkBK = Microsoft.VisualBasic.Interaction.InputBox("Alıcının bonus kartını daxil edin", Baza.adminAdi, "");
            if (abkBK.Trim().Equals(""))
            {

            }
            else
            {
                if (Baza.cedvelde_serti_odeyen_setir_sayi("abk", " where bk='" + abkBK + "'") == 1)
                { 
                    double bonusFaizi = Baza.alicinin_bar_koduna_gore_bonus_faizi(abkBK);
                    string adi = Baza.cedvelden_tek_setir("abk", "ad", "bk", abkBK);

                    double cekdeOlanPul = double.Parse(Microsoft.VisualBasic.Interaction.InputBox("Məbləği daxil edin", Baza.adminAdi, ""));
                     
                    double bonus = (cekdeOlanPul / 100) * bonusFaizi;

                    double bonusIntYekun = bonus;

                    double alicinin_hazirki_xali = Baza.cedvelden_tek_double("abk", "bonus", "bk", abkBK, 4);

                    alicinin_hazirki_xali += bonusIntYekun;


                    Baza.iud( "UPDATE abk   SET bonus='" + alicinin_hazirki_xali + "' where bk='" + abkBK + "'");

                    Baza.msg("Ad : " + adi + "\n\nBonus Xalı : " + alicinin_hazirki_xali);

                }
                else
                {

                    MessageBox.Show("Bu bonus kartı bazada yoxdur");
                }
            }
        }
        //hazir 
        private void kassaF1()
        {
            kassa_tabControl.SelectedIndex = 1;

            mallar_dgv_kassa.Focus();

            malSiyahisiText.Text = "";

            malSiyahisiAxtar();
        }
        //hazir 
        private void kassaF5()
        {
            string bk = Microsoft.VisualBasic.Interaction.InputBox("Alıcının bonus kartını daxil edin", "Kassa", "");

            if (Baza.cedvelde_serti_odeyen_setir_sayi("abk", " where bk='" + bk + "'") == 1)
            {
                string adSoyad = Baza.cedvelden_tek_setir("abk", "ad", "bk", bk);

                double bonus = Baza.cedvelden_tek_double("abk", "bonus", "bk", bk, 4);

                Hediyye hediyye = new Hediyye();

                hediyye.adSoyad = adSoyad;

                hediyye.bonus = bonus;

                hediyye.bk = bk;

                hediyye.Show();
            }
            else
            { 
                MessageBox.Show("Bu bonus kartı bazada yoxdur");
            }
        }
        //hazir 
        private void kassaF11()
        {
            kassa_tabControl.SelectedIndex = 2;

            borclular_dgv_kassa.Focus();

            kassa_borclular_axtar_textBox.Text = "";
        }

        //hazir 
        private void kassada_sil_metodu(int idk)
        {

            string ad = "";
            double sq = 0;
            double mq = 0;
            double sqcem = 0;
            string bk = "";

            if (indiki_tarix_silinen_f7_ucun.Equals(""))
            {

                indiki_tarix_silinen_f7_ucun = Baza.indiki_tarix();

            }


            string kassaTarixi = indiki_tarix_silinen_f7_ucun;


            ad = adList.ElementAt(idk);
            sq = sqList.ElementAt(idk);
            mq = mqList.ElementAt(idk);
            sqcem = sqcemList.ElementAt(idk);
            bk = bkList.ElementAt(idk);

            Baza.kassada_f7_ile_silinen_mali_bazaya_yaz(ad, sq, mq, sqcem, bk, kk, kassaTarixi);
        }

        //hazir 
        public void malSiyahisiAxtar()
        {
            string axtarilan = malSiyahisiText.Text;

            try
            {
                foreach (DataGridViewRow setir in mallar_dgv_kassa.Rows)
                {
                    if (setir.Cells[1].Value.ToString().ToLower().StartsWith(axtarilan.Trim().ToLower()))
                    {
                        int secilesi_indeks_iki = setir.Index;

                        mallar_dgv_kassa.CurrentRow.Selected = false;

                        mallar_dgv_kassa.CurrentCell = mallar_dgv_kassa.Rows[secilesi_indeks_iki].Cells[0];

                        mallar_dgv_kassa.Rows[secilesi_indeks_iki].Selected = true;

                        mallar_dgv_kassa.FirstDisplayedScrollingRowIndex = mallar_dgv_kassa.SelectedRows[0].Index;


                        break;
                    }
                } axtarilan_malin_kodu = mallar_dgv_kassa.Rows[mallar_dgv_kassa.SelectedCells[0].RowIndex].Cells[2].FormattedValue.ToString();

            }
            catch
            {

            }
        }
        //hazir 
        private void kassada_f2_duymesine_basilir()
        {

            if (kassa_dgv.Rows.Count == 0)
            {

            }
            else
            {

                ksF2();
                indiki_tarix_silinen_f7_ucun = "";
                kassa_dgv.Rows.Clear();
            }

            skaner_textbox.Text = "";
            qaliq_pul_aktiv_label.Text = "";
            skaner_textbox.Focus();
        }

        //hazir 
        
        public void satisa_basla(string skaner_text)
        {


            bool tereziMaliSatilir = false;

            if (skaner_text.Length >= 12 && skaner_text.StartsWith("220"))
            {
                string ceki_malin_kodu = skaner_text.Substring(2, 5);

                tereziMaliSatilir = Baza.bu_kod_ceki_malin_kodudur(ceki_malin_kodu);

                if (tereziMaliSatilir)
                {
                    tip3_kod_satish(skaner_text);

                    skaner_textbox.Text = "";
                    skaner_textbox.Focus();
                }
            }


            if (tereziMaliSatilir) { }
            else
            {
                if (skaner_text.Trim().Equals(""))
                {

                    barKodBazadaYoxdurSesli();
                     
                }
                else
                {
                    bool bazadaVar = Baza.cedvelde_serti_odeyen_setir_sayi("mallar", "where bk='" + skaner_text + "'") == 1;
                    if (bazadaVar)
                    {



                        bool aktiv = Baza.cedvelden_tek_int("mallar", "aktiv", "bk", skaner_text) == 1;

                        if (aktiv)
                        {
                            string ad = Baza.cedvelden_tek_setir("mallar", "ad", "bk", skaner_text);
                            double md = Baza.cedvelden_tek_double("mallar", "md", "bk", skaner_text, 4);
                            double sq = Baza.cedvelden_tek_double("mallar", "sq", "bk", skaner_text, 4);
                            double mq = Baza.cedvelden_tek_double("mallar", "mq", "bk", skaner_text, 3);

                            double sqtek = Baza.cedvelden_tek_double("mallar", "sqtek", "bk", skaner_text, 4);

                            int mqtek = Baza.cedvelden_tek_int("mallar", "mqtek", "bk", skaner_text);

                            int plukodu = Baza.cedvelden_tek_int("mallar", "plukodu", "bk", skaner_text);

                            int tip = Baza.cedvelden_tek_int("mallar", "tip", "bk", skaner_text);
                            int kt = Baza.cedvelden_tek_int("mallar", "kt", "bk", skaner_text);
                            int qutusayi = Baza.cedvelden_tek_int("mallar", "qutusayi", "bk", skaner_text);


                            MalSayi ms = new MalSayi(ad, skaner_text, md, sq, mq, aktiv, sqtek, mqtek, plukodu, tip, kt, qutusayi, this);

                            ms.Show(); 
                            skaner_textbox.Text = "";
                        }
                        else { Baza.msg("Bu mal aktiv deyil"); skaner_textbox.Text = "";  }




                    }
                    else { barKodBazadaYoxdurSesli(); }

                }
            }

        }
        //hazir 
        private void barKodBazadaYoxdurSesli()
        {
            System.Media.SoundPlayer ses = new System.Media.SoundPlayer();

            ses.SoundLocation = "C:/hhmdxeht/MagazaProqramiDEA/ses.wav";


            ses.Play();
            skaner_textbox.Text = "";
           Baza.msg("Bu kodlu mal bazada yoxdur");
        }
        // hazirdir 
        public void tip3_kod_satish(string bk_uzun)
        {
            string bk = bk_uzun.Substring(2, 5);

            string mqs = bk_uzun.Substring(7, 6);

            mqs = mqs.Substring(0, 2) + "." + mqs.Substring(2, 3);

            double mq = Convert.ToDouble(mqs);

            string ad = Baza.cedvelden_tek_setir("mallar", "ad", "bk", bk);

            bool buArtiqVar = bkList.Contains(bk);

            if (buArtiqVar)
            {
                int indeks = bkList.IndexOf(bk);
                mqList[indeks] = mqList[indeks] + mq;

                double sqcem = sqList[indeks] * mqList[indeks];
                sqcem = Math.Round(sqcem, 4);

                sqcemList[indeks] = sqcem;

            }
            else
            {
                adList.Add("" + ad);

                double sq = Baza.cedvelden_tek_double("mallar", "sq", "bk", bk, 4);

                sqList.Add(sq);

                mqList.Add(mq);

                double sqcem = sq * mq;
                sqcem = Math.Round(sqcem, 4);

                sqcemList.Add(sqcem);

                bkList.Add(bk);

                tipList.Add(3);

                tipsatisList.Add(Baza.tipSatis);
                tipdeneList.Add(0);
                kassa_dgv.Rows.Add();

            } malin_melumatlarini_cedvele_yaz();
        }
        // hazir 
        public void kassaCedvelineYeniSetirElaveEt()
        {
            kassa_dgv.Rows.Add();
        }
        //hazir dir 
        public void malin_melumatlarini_cedvele_yaz()
        {


            for (int i = 0; i < adList.Count; i++)
            {
                kassa_dgv.Rows[i].Cells[0].Value = "" + adList[i];
                kassa_dgv.Rows[i].Cells[1].Value = "" + sqList[i];
                kassa_dgv.Rows[i].Cells[2].Value = "" + mqList[i];
                kassa_dgv.Rows[i].Cells[3].Value = "" + sqcemList[i];
                kassa_dgv.Rows[i].Cells[4].Value = "" + bkList[i];
            }



            double cem = 0.0;

            for (int i2 = 0; i2 < adList.Count; i2++)
            {
                double d = sqcemList[i2];

                cem += d;

            }

            cem = Math.Round(cem, 2);


            Baza.kassaCem = cem; Baza.kassaCemEndirimli = cem;
            cem_mebleg_aktiv_label.Text = ("" + cem + "");

        }
        //hazir 
        public void ksF2()
        {


            try
            {
                for (int i = 0; i < adList.Count; i++)
                {
                    Baza.iud("insert into satilanindi (ad,bk,sq,sqen,mq,sqcem,tip,kk,tipsatis,tipdene) values ('" + adList[i] + "','" + bkList[i] + "','" + sqList[i] + "','" + sqEndirimliList[i] + "','" + mqList[i] + "','" + sqcemList[i] + "'," + tipList[i] + "," + kk + "," + tipsatisList[i] + "," + tipdeneList[i] + ")");

                }
                Baza.tarixleriYenile();
#pragma warning disable CS0219 // Variable is assigned but its value is never used
                string ceki_ayiran_sorgu = "";
#pragma warning restore CS0219 // Variable is assigned but its value is never used


                ksF2InsertSatilanlar();
                string srok_tarixi = "";

                listleriTemizle();
                string cemS = cem_mebleg_aktiv_label.Text;

                double cemD = Convert.ToDouble(cemS );

                skaner_textbox.Text = "";

                cem_mebleg_aktiv_label.Text = "0";

                if (Baza.cedvelden_tek_int("info", "daxili", "ad", "bonusyes")==1)
                    { 
                string abkBK = Microsoft.VisualBasic.Interaction.InputBox("Alıcının bonus kartını daxil edin", Baza.adminAdi, "");



                if (abkBK.Trim().Equals(""))
                {
                    bonusVerildi = 0;
                    bonusXali = "";
                }
                else
                {
                    if (Baza.cedvelde_serti_odeyen_setir_sayi("abk", " where bk='" + abkBK + "'") == 1)
                    {

                        bool bonus_kartinin_sroku_kecib = Baza.bu_bonus_kartinin_sroku_kecib(abkBK);

                        if (bonus_kartinin_sroku_kecib)
                        {
                            Baza.bu_alicinin_bonusunu_sifirla_ve_tarixini_yenile(abkBK);

                        }
                        bool alicinin_sroku_limite_catib = false;

                        alicinin_sroku_limite_catib = Baza.alicinin_sroku_limite_catib_yoxsa_yox(abkBK);

                        this.alicinin_sroku_limite_catib = alicinin_sroku_limite_catib;

                        srok_tarixi = "";


                        if (alicinin_sroku_limite_catib)
                        {
                            srok_tarixi = Baza.srokTarixi;
                        }



                        double bonus_faizi = Baza.alicinin_bar_koduna_gore_bonus_faizi(abkBK);

                        string adi = Baza.abk_bar_koduna_gore_adi(abkBK);

                        double satis_pulu = cemD;
                        double bonus = (satis_pulu / 100) * bonus_faizi;

                        double bonus_int = bonus;

                        double alicinin_hazirki_xali = Baza.abk_bonus_xali(abkBK);

                        alicinin_hazirki_xali += bonus_int;


                        Baza.iud("UPDATE abk   SET bonus='" + alicinin_hazirki_xali + "' where bk='" + abkBK + "'");



                        Baza.msg("Ad : " + adi + "\n\nBonus Xalı : " + alicinin_hazirki_xali);

                        bonusVerildi = 1;
                        bonusXali = "" + bonus_int;

                        umumiBonusXali = alicinin_hazirki_xali + "";

                        bonus_musteri_adi = "" + adi;
                    }
                    else
                    {

                        Baza.msg("Bu bonus kartı bazada yoxdur");
                    }

                }


                }
                //int cekSistemiIshlesinmi = .Baza.cedvelden_tek_setir("info", "daxili", "ad", "chekyes");
                int cekSistemiIshlesinmi = Baza.cedvelden_tek_int("info", "daxili", "ad", "chekyes");

                if (cekSistemiIshlesinmi==1)
                {

                    Baza.iud("update   satilanindi set aktiv=0 where kk<>" + kk);
                    Baza.iud("update     satilanindi set aktiv=1 where kk=" + kk);


                    TextWriter tw = new StreamWriter(@"C:\hhmdxeht\MagazaProqramiDEA\cek.txt");

                    tw.WriteLine("             " + Baza.magazaAdi + "                  ");
                    tw.WriteLine("**************************************************");
                    tw.WriteLine("KASSİR:  " + kk);
                    tw.WriteLine("**************************************************");

                    tw.WriteLine(Baza.magazaUnvani);
                    tw.WriteLine("**************************************************");
                    tw.WriteLine("TARİX:   " + Baza.indiki_tarix());
                    tw.WriteLine("**************************************************");
                    tw.WriteLine("ADI           MİQDAR   QIYMƏT   CƏMİ");
                    tw.WriteLine(" ");

                    string[] sutun_adlari = new string[] { "ad", "mq", "sq", "sqcem" };

                    List<string>[] melumatlar = Baza.cedvelden_melumat_oxumaq_cox_sutun("cekucun", sutun_adlari, (" where kk=" + kk));


                    for (int i = 0; i < melumatlar[0].Count; i++)
                    {

                        string ad = melumatlar[0][i] + "";

                        int uzunu = ad.Length;

                        if (uzunu > 13) { ad = ad.Substring(0, 13); }


                        if (uzunu < 13)
                        {
                            for (int j = 0; j < (13 - uzunu); j++)
                            {
                                ad += " ";
                            }

                        }


                        string mq = melumatlar[1][i] + "";

                        uzunu = mq.Length;

                        if (uzunu > 8) { mq = mq.Substring(0, 8); }


                        if (uzunu < 8)
                        {
                            for (int j = 0; j < (8 - uzunu); j++)
                            {
                                mq += " ";
                            }

                        }

                        string sq = melumatlar[2][i] + "";

                        uzunu = sq.Length;

                        if (uzunu > 8) { sq = sq.Substring(0, 8); }
                        if (uzunu < 8)
                        {
                            for (int j = 0; j < (8 - uzunu); j++)
                            {
                                sq += " ";
                            }

                        }


                        string sqcem = melumatlar[3][i] + "";

                        string s = "" + ad + " " + mq + " " + sq + " " + sqcem;

                        tw.WriteLine(s);

                    }
                    double umumiPul = Baza.cedvelde_sutunun_cemleri("cekucun", "sqcem", ("where kk=" + kk));
                     tw.WriteLine("**************************************************");
                    tw.WriteLine("       CƏMİ:    " + umumiPul + " AZN");
                        umumiPul = (umumiPul/100.0)*(100.0-malinSatishiUcunTetbiqOlunanFaiz);
                    this.umumiPul = umumiPul;
                
                    if (malinSatishiUcunTetbiqOlunanFaiz>0)
                    {
                        tw.WriteLine("**************************************************");
                        tw.WriteLine("      YEKUN:    " + umumiPul + " AZN");
                    }
                 malinSatishiUcunTetbiqOlunanFaiz = 0;
                   


                   

                   

                    tw.WriteLine(" ");



                    double verilenPul = umumiPul;

                    string qaliq_pul_label_text = qaliq_pul_aktiv_label.Text;

                    if (!qaliq_pul_label_text.Trim().Equals(""))
                    {
                        verilenPul += double.Parse(qaliq_pul_label_text);


                        verilenPul = Math.Round(verilenPul, 4);
                    }


                    double qaliq = verilenPul - umumiPul;

                    tw.WriteLine("VERİLƏN PUL:    " + verilenPul + " AZN");
                    tw.WriteLine(" ");
                    tw.WriteLine("      QALIQ:    " + qaliq + " AZN");
                    tw.WriteLine(" ");

                    if (bonusVerildi == 1)
                    {
                        tw.WriteLine("Müştəri: " + bonus_musteri_adi); 
                        tw.WriteLine(" ");

                        bool cekde_umumi_xal_gorunsun = Baza.cekde_alicinin_umumi_xali_gorunur_yoxsa_yox();

                        if (cekde_umumi_xal_gorunsun)
                        {
                            tw.WriteLine("Ümumi Bonus xalı: " + umumiBonusXali);

                            tw.WriteLine(" ");


                        }
                        else { }
                        

                        bool cekde_srok_cap_olunsun = false;
                         
                        cekde_srok_cap_olunsun = Baza.cekde_srok_cap_olunsun_yoxsa_yox();
                     
                        if (cekde_srok_cap_olunsun && alicinin_sroku_limite_catib)
                        {
                            tw.WriteLine("Son hədiyyə tarixi: " + srok_tarixi); 
                            tw.WriteLine(" ");
                        }

                         
                    }

                    else { }


                    if (borc_yazilan_musteri_label1.Text.Equals(":::"))
                    {
                        nisyeVerilenMushterininAdi = "";
                        string qeyd = "Kassa " + kk + "-də Satış edildi";
                        kassadaSatishEdildiVeUmumiMeblegBalansaElaveEdildi(qeyd, this.umumiPul);
                    }
                    else
                    {
                        nisyeVerilenMushterininAdi = borc_yazilan_musteri_label1.Text;
                        tw.WriteLine("Nisyə verilən müştərinin adı : " + nisyeVerilenMushterininAdi); tw.WriteLine(" ");

                        double musterinin_real_borcu = Baza.cedvelden_tek_double("borclular", "borc", "ad", nisyeVerilenMushterininAdi, 4);

                        musterinin_real_borcu = musterinin_real_borcu + umumiPul;
                        Baza.iud("UPDATE borclular  SET borc='" + musterinin_real_borcu + "' where ad='" + nisyeVerilenMushterininAdi + "'");




                        Baza.iud("insert into brlarop (kk,musteri,tarix,pul) values(" + kk + ",'" + nisyeVerilenMushterininAdi + "','" + Baza.indiki_tarix() + "','" + umumiPul + "' )");





                    }

                    tw.WriteLine("              Təşəkkür edirik!");
                    tw.Close();

                   


                    ceki_yadda_saxla();
                  

                    faylinCapi = new System.IO.StreamReader(@"C:\hhmdxeht\MagazaProqramiDEA\cek.txt");
                  
                    printFontu = new System.Drawing.Font("Courier New", 8, FontStyle.Bold);
                    //if (MessageBox.Show("Çek çap olunsun?", "Kassa", MessageBoxButtons.YesNo) == DialogResult.Yes)
                    {
                        if (!borc_yazilan_musteri_label1.Text.Equals(":::"))
                        {
                            

                            kassa_printDocument1.Print();
                            faylinCapi = new System.IO.StreamReader(@"C:\hhmdxeht\MagazaProqramiDEA\cek.txt");
                            printFontu = new System.Drawing.Font("Courier New", 8, FontStyle.Bold);
                        }
                        kassa_printDocument1.Print();
                    }
                  
                    faylinCapi.Close();
                  
                    Baza.satilan_mallari_bazadan_azalt_baza_sinifi(kk);

                    Baza.iud("delete from  satilanindi  where kk=" + kk);


                    borc_yazilan_musteri_label1.Text = ":::";

                }
                else
                {
                    Baza.satilan_mallari_bazadan_azalt_baza_sinifi(kk);


                    Baza.iud("delete from  satilanindi  where kk=" + kk);




                }

                kassa_endirim_faizi_label2.Text = "0";
            }
            catch (Exception xeta) { Baza.msg("Kassa:ksF2\n\n" + xeta.ToString()); }

        }string nisyeVerilenMushterininAdi = "";
        double umumiPul = 0;
        private void kassadaSatishEdildiVeUmumiMeblegBalansaElaveEdildi(string qeyd, double umumiPul)
        {

            double cariBalans = Baza.cedvelden_tek_double("info", "daxili", "ad", "balans_miqdari", 4);

            cariBalans += umumiPul;
            Baza.iud("update info set daxili='" + cariBalans + "' where ad='balans_miqdari'");



            Baza.iud("insert into balansemeliyyatlari (tarix,tip,qeyd,mebleg) values ('" + Baza.indiki_tarix() + "'," + 1 + ",'" + qeyd + "','" + umumiPul + "')");
                            

        }

        //hazir 
        private void ksF2InsertSatilanlar()
        {
            for (int i = 0; i < adList.Count; i++)
            {
                string ad = adList[i];

                string bk = "" + bkList[i];
                double mq = mqList[i];
                string tarix = Baza.indi;
                int kk = this.kk;
                int tip = tipList[i];
                int kt = Baza.cedvelden_tek_int("mallar", "kt", "bk", bk);
                int qutusayi = Baza.cedvelden_tek_int("mallar", "qutusayi", "bk", bk);
                double sq = sqList[i]; double sqen = sqEndirimliList[i];

                double md = Baza.cedvelden_tek_double("mallar", "md", "bk", bk, 4);


                int tipsatis = tipsatisList[i];
                int tipdene = tipdeneList[i];

                string yazilar = "";


                if (tipdene == 0)
                {
                    yazilar = "'" + ad + "','" + bk + "','" + mq + "',0,'" + tarix + "'," + kk + "," + tip + "," + kt + ",'" + sq + "','" + sqen + "','0','" + md + "'," + tipsatis + "," + tipdene + "";
                }
                else if (tipdene == 1)
                {
                    yazilar = "'" + ad + "','" + bk + "','" + mq + "',0,'" + tarix + "'," + kk + "," + tip + "," + kt + ",'" + sq + "','" + sqen + "','0','" + md / qutusayi + "'," + tipsatis + "," + tipdene + "";

                }

                Baza.cedvele_melumat_yazmaq("satilanlar", "ad,bk,mq,mqtek,tarix,kk,tip,kt,sq,sqen,sqtek,md,tipsatis,tipdene", yazilar);

            }
        }
        //hazir
        private void ceki_yadda_saxla()
        {

            if (!Directory.Exists(@"C:\hhmdxeht\MagazaProqramiDEA\cekler"))
            {

                Directory.CreateDirectory(@"C:\hhmdxeht\MagazaProqramiDEA\cekler");
            }

            string indi = Baza.indiki_tarix();

            indi = indi.Replace(":", "-");



            File.Copy(@"C:\hhmdxeht\MagazaProqramiDEA\cek.txt", @"C:\hhmdxeht\MagazaProqramiDEA\cekler\" + indi + ".txt");

        }
        //hazir 
        private void kassa_printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {

            float yPos = 0f;
            int count = 0;

            float leftMargin = e.MarginBounds.Left;

            float topMargin = e.MarginBounds.Top;

            string line = null;

            float linesPerPage = e.MarginBounds.Height / printFontu.GetHeight(e.Graphics);

            while (count < linesPerPage)
            {
                line = faylinCapi.ReadLine();

                if (line == null)
                {
                    break;
                }
                yPos = 0 + count * printFontu.GetHeight(e.Graphics);
                e.Graphics.DrawString(line, printFontu, Brushes.Black, 0, yPos, new StringFormat());
                count++;

            }
            if (line != null)
            {
                e.HasMorePages = true;
            }
        }
        //hazir 
        private void borclular_dgv_kassa_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            borclular_dan_biri_secildi();
        }

        //hazir 
        private void borclular_dan_biri_secildi()
        {  
            string ad = borclular_dgv_kassa.Rows[borclular_dgv_kassa.SelectedCells[0].RowIndex].Cells[1].FormattedValue.ToString();
             
            double odenen_borc = 0; 
            try
            {
                odenen_borc = Convert.ToDouble(Microsoft.VisualBasic.Interaction.InputBox("Müştərinin aldığı yaxud verdiyi borcun miqdarını daxil edin", "Müştərinin adı :::   " + ad, "1", -1, -1));
            }
            catch (Exception xeta)
            {
                odenen_borc = 0; 
                Baza.msg("Kassa:borclular_dan_biri_secildi.\n\nDüzgün ədəd daxil edilmədi\n\n" + xeta.ToString());
            }
            finally { }



            if (odenen_borc == 0) { }

            else
            {


                double musterinin_real_borcu = Baza.cedvelden_tek_double("borclular", "borc", "ad", ad, 4);
                if (odenen_borc < 0)
                {

                    if ((musterinin_real_borcu + odenen_borc) >= 0)
                    {
                        musterinin_real_borcu = musterinin_real_borcu + odenen_borc;


                        Baza.iud("UPDATE borclular  SET borc='" + musterinin_real_borcu + "' where ad='" + ad + "'");


                        Baza.iud("insert into brlarop (kk,musteri,tarix,pul) values(" + kk + ",'" + ad + "','" + Baza.indiki_tarix() + "','" + odenen_borc + "' )");


                        borclular_cedvelini_yenile();


                        double cariBalans = Baza.cedvelden_tek_double("info", "daxili", "ad", "balans_miqdari", 4);
  double qaytarilanBorc=-1*odenen_borc;

  cariBalans += qaytarilanBorc;
                        Baza.iud("update info set daxili='" + cariBalans + "' where ad='balans_miqdari'");


                      
                        string qeyd = "" + ad + " - adlı müştəri borcunu qaytarır. Məbləğ = " + qaytarilanBorc;
                        Baza.iud("insert into balansemeliyyatlari (tarix,tip,qeyd,mebleg,firma) values ('" + Baza.indiki_tarix() + "'," + 1 + ",'" + qeyd + "','" + (qaytarilanBorc) + "','')");
                            






                    }
                    else
                    {
                        Baza.msg("Düzgün ədəd daxil edilmədi.\n\nMüştərinin borcu daxil ediləndən azdır.");
                    }

                }
                else
                {

                   // musterinin_real_borcu = musterinin_real_borcu + odenen_borc;
                  //  Baza.iud("UPDATE borclular  SET borc='" + musterinin_real_borcu + "' where ad='" + ad + "'");

                    borclular_cedvelini_yenile();


                    //Baza.iud("insert into brlarop (kk,musteri,tarix,pul) values(" + kk + ",'" + ad + "','" + Baza.indiki_tarix() + "','" + odenen_borc + "' )");


                }

                 
            }
            kassa_borclular_axtar_textBox.Text = "";  
        } 

        //hazir
        private void borclular_dgv_kassa_MouseClick(object sender, MouseEventArgs e)
        {
            borclunun_adi_siyahidan_secilen = borclular_dgv_kassa.Rows[borclular_dgv_kassa.SelectedCells[0].RowIndex].Cells[1].FormattedValue.ToString();
        }
        // hazir oldu
        private void borclulari_axtar()
        {
            string axtarilan = kassa_borclular_axtar_textBox.Text;

            try
            {
                foreach (DataGridViewRow setiri in borclular_dgv_kassa.Rows)
                {
                    if (setiri.Cells[1].Value.ToString().ToLower().StartsWith(axtarilan.Trim().ToLower()))
                    {
                        int secilesi_indeks_iki = setiri.Index;

                        borclular_dgv_kassa.CurrentRow.Selected = false;

                        borclular_dgv_kassa.CurrentCell = borclular_dgv_kassa.Rows[secilesi_indeks_iki].Cells[0];

                        borclular_dgv_kassa.Rows[secilesi_indeks_iki].Selected = true;

                        borclular_dgv_kassa.FirstDisplayedScrollingRowIndex = borclular_dgv_kassa.SelectedRows[0].Index;


                        break;
                    }
                } borclunun_adi_siyahidan_secilen = borclular_dgv_kassa.Rows[borclular_dgv_kassa.SelectedCells[0].RowIndex].Cells[1].FormattedValue.ToString();

            }
            catch
            {

            }
        }
        
        
        //bitdi hazir oldu
        private void borclular_dgv_kassa_KeyUp(object sender, KeyEventArgs e)
        {
             

            if (e.KeyCode == Keys.Up || e.KeyCode == Keys.Down)
            {
                kassa_borclular_axtar_textBox.Text = "";

                borclunun_adi_siyahidan_secilen = borclular_dgv_kassa.Rows[borclular_dgv_kassa.SelectedCells[0].RowIndex].Cells[1].FormattedValue.ToString();

            }
            else
                if (e.KeyCode == Keys.Left || e.KeyCode == Keys.Right)
                { 
                }


                else


                    if (e.KeyCode == Keys.Back)
                    {
                        string t = kassa_borclular_axtar_textBox.Text;

                        if (t.Length > 0)
                            t = t.Substring(0, t.Length - 1);
                        kassa_borclular_axtar_textBox.Text = t;
                        borclulari_axtar();
                    }
                    else
                        if (e.KeyCode == Keys.Space)
                        {
                            string t = kassa_borclular_axtar_textBox.Text;
                            t = t + " ";
                            kassa_borclular_axtar_textBox.Text = t;
                            borclulari_axtar();
                        }

                        else
                            if (e.KeyCode >= Keys.A && e.KeyCode <= Keys.Z
)
                            {

                                kassa_borclular_axtar_textBox.Text = kassa_borclular_axtar_textBox.Text + e.KeyData;


                                borclulari_axtar();


                            }
                            else if ((e.KeyCode >= Keys.D0 && e.KeyCode <= Keys.D9))
                            {
                                string kod = "" + e.KeyData;
                                kod = kod.Substring(1, 1);
                                 
                                kassa_borclular_axtar_textBox.Text = kassa_borclular_axtar_textBox.Text + kod;
                                borclulari_axtar();

                            }
                            else if ((e.KeyCode >= Keys.NumPad0 && e.KeyCode <= Keys.NumPad9))
                            {
                                string kod = "" + e.KeyData;
                                kod = kod.Substring(6, 1);
                                kassa_borclular_axtar_textBox.Text = kassa_borclular_axtar_textBox.Text + kod;
                                borclulari_axtar();
                            }
                            else if (e.KeyCode == Keys.OemMinus)
                            {
                                string t = kassa_borclular_axtar_textBox.Text;
                                t = t + "-";
                                kassa_borclular_axtar_textBox.Text = t;


                                borclulari_axtar();
                            }
                            else
                            {
                                //   axtaris_textbox_mallar.Text = axtaris_textbox_mallar.Text + e.KeyData;
                            }





        }
        //hazir 
        private void mallar_dgv_kassa_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F2)
            {
                kassa_tabControl.SelectedIndex = 0;
                skaner_textbox.Text = "";

                skaner_textbox.Focus();



            }
            else
                if (e.KeyCode == Keys.Up || e.KeyCode == Keys.Down)
                {
                    malSiyahisiText.Text = "";
                    axtarilan_malin_kodu = mallar_dgv_kassa.Rows[mallar_dgv_kassa.SelectedCells[0].RowIndex].Cells[2].FormattedValue.ToString();

                }
                else
                    if (e.KeyCode == Keys.Left || e.KeyCode == Keys.Right) { e.SuppressKeyPress = true; }


                    else


                        if (e.KeyCode == Keys.Back)
                        {
                            string t = malSiyahisiText.Text;
                            if (t.Length > 0)
                                t = t.Substring(0, t.Length - 1);
                            malSiyahisiText.Text = t;
                            malSiyahisiAxtar();
                        }
                        else
                            if (e.KeyCode == Keys.Space)
                            {
                                string t = malSiyahisiText.Text;
                                t = t + " ";
                                malSiyahisiText.Text = t;
                                malSiyahisiAxtar();
                            }

                            else
                                if (e.KeyCode >= Keys.A && e.KeyCode <= Keys.Z
    )
                                {
                                    malSiyahisiText.Text = malSiyahisiText.Text + e.KeyData;

                                    malSiyahisiAxtar();


                                }
                                else if ((e.KeyCode >= Keys.D0 && e.KeyCode <= Keys.D9))
                                {
                                    string kod = "" + e.KeyData;
                                    kod = kod.Substring(1, 1);
                                    malSiyahisiText.Text = malSiyahisiText.Text + kod; malSiyahisiAxtar();
                                }
                                else if ((e.KeyCode >= Keys.NumPad0 && e.KeyCode <= Keys.NumPad9))
                                {
                                    string kod = "" + e.KeyData;
                                    kod = kod.Substring(6, 1);
                                    malSiyahisiText.Text = malSiyahisiText.Text + kod; malSiyahisiAxtar();
                                }
                                else if (e.KeyCode == Keys.OemMinus)
                                {
                                    string t = malSiyahisiText.Text;
                                    t = t + "-";
                                    malSiyahisiText.Text = t;
                                    malSiyahisiAxtar();
                                }
                                else
                                {
                                    //   malSiyahisiText.Text = malSiyahisiText.Text + e.KeyData;
                                }

        }
        //hazir 
        private void listleriTemizle()
        {
            adList.Clear();
            sqList.Clear(); sqEndirimliList.Clear();
            mqList.Clear();
            sqcemList.Clear();
            bkList.Clear();
            tipList.Clear();
            tipsatisList.Clear();
            tipdeneList.Clear();
        }
        //hazir 
        private void mallar_dgv_kassa_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                kassaMallarSiyahidanSecilir();

            }
        }
        //hazir 
        private void kassaMallarSiyahidanSecilir()
        {
            

            axtarilan_malin_kodu = mallar_dgv_kassa.Rows[mallar_dgv_kassa.SelectedCells[0].RowIndex].Cells[2].FormattedValue.ToString();
            bk = axtarilan_malin_kodu;
            satisa_basla(axtarilan_malin_kodu);
        }
        //hazir 
        private void mallar_dgv_kassa_MouseClick(object sender, MouseEventArgs e)
        {
            axtarilan_malin_kodu = mallar_dgv_kassa.Rows[mallar_dgv_kassa.SelectedCells[0].RowIndex].Cells[2].FormattedValue.ToString();
        }
        //hazir 
        private void skaner_textbox_KeyUp(object sender, KeyEventArgs e)
        {
            if ( e.KeyCode == Keys.F12)
            {

                if (Baza.tipSatis == 0)
                {
                    Baza.tipSatis = 1;
                    kassa_alis_satis_rejimi_label4.Text = "Q a y t a r ı ş";
                    skaner_textbox.Text = "";
                    kassa_dgv.BackgroundColor = Color.Red;

                }
                else
                {
                    Baza.tipSatis = 0;
                    kassa_alis_satis_rejimi_label4.Text = "S a t ı ş";
                    skaner_textbox.Text = ""; kassa_dgv.BackgroundColor = Color.LightSteelBlue;
                }

            }

        }
        //hazir 
        private void kassa_dgv_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F11)
            {
                kassaF11();


            }
            else if (e.KeyCode == Keys.D0 || e.KeyCode == Keys.D1 || e.KeyCode == Keys.D2 || e.KeyCode == Keys.D3 || e.KeyCode == Keys.D4 || e.KeyCode == Keys.D5 || e.KeyCode == Keys.D6 || e.KeyCode == Keys.D7 || e.KeyCode == Keys.D8 || e.KeyCode == Keys.D9)
            {
                skaner_textbox.Text = "" + ("" + e.KeyData + "").Substring(1, 1);

                skaner_textbox.Focus();
                skaner_textbox.SelectionStart = 1;
                skaner_textbox.SelectionLength = 0;

            }
            else if (e.KeyCode == Keys.F6)
            {
                skaner_textbox.Focus();


            }
            else if (e.KeyCode == Keys.F2)
            {
                kassada_f2_duymesine_basilir();

            }
            else if (e.KeyCode == Keys.F5)
            {
                kassaCedvelF5();

            }
            else if (e.KeyCode == Keys.F7)
            {
                kassaF7();

            }
            else if (e.KeyCode == Keys.F1)
            {
                kassaF1();

            }



            else { }
        }
        //hazir 
        private void kassaCedvelF5()
        {
            try
            {
                int indeks = kassa_dgv.CurrentCell.RowIndex;

                double miqdar = mqList[indeks];

                miqdar = double.Parse(Microsoft.VisualBasic.Interaction.InputBox("Malın miqdarının dəyişdirilməsi", "", "" + miqdar));
                miqdar = Math.Round(miqdar,3);
                mqList[indeks] = miqdar;

                sqcemList[indeks] = sqList[indeks] * mqList[indeks];

                malin_melumatlarini_cedvele_yaz();
            }
            catch { }
        }
        //hazir 
        private void kassaF7()
        {
            kassa_dgv.Focus();

            try
            {
                int idk = kassa_dgv.CurrentCell.RowIndex;

                kassada_sil_metodu(idk);

                adList.RemoveAt(idk);
                sqList.RemoveAt(idk);
                mqList.RemoveAt(idk);
                sqcemList.RemoveAt(idk);
                bkList.RemoveAt(idk);
                tipList.RemoveAt(idk);
                tipsatisList.RemoveAt(idk);
                tipdeneList.RemoveAt(idk);


                kassa_dgv.Rows.RemoveAt(idk);


                malin_melumatlarini_cedvele_yaz();
                qaliq_pul_aktiv_label.Text = "0";
            }
            catch { }
        }
        //hazir 
        private void mallar_dgv_kassa_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            kassaMallarSiyahidanSecilir();
        }
        //hazir 
        private void borclular_dgv_kassa_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F11)
            {
                kassa_tabControl.SelectedIndex = 0;
                skaner_textbox.Focus();
                skaner_textbox.Text = "";
            }
            else if (e.KeyCode == Keys.Up || e.KeyCode == Keys.Down)
            {
                kassa_borclular_axtar_textBox.Text = "";
            }
            else if (e.KeyCode == Keys.Left || e.KeyCode == Keys.Right)
            {
                
            }
            else if (e.KeyCode == Keys.Enter)
            {

                borclular_dan_biri_secildi();
            }
            else if (e.KeyCode == Keys.Delete)
            {

                if (MessageBox.Show("Müştərini silməyə əminsiniz?", "Müştərinin adı : " + borclunun_adi_siyahidan_secilen, MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    if (Baza.iud("delete from borclular where ad='" + borclunun_adi_siyahidan_secilen + "'"))
                    {
                        Baza.msg("Silindi");
                    }
                    else
                    {
                        Baza.msg("Silinmədi");

                    }
                    borclular_cedvelini_yenile();
                }
            }


        }

        private void kassa_dgv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void borca_yaz_alishi_button1_Click(object sender, EventArgs e)
        {
            borca_yaz_alishi_Duymesi_Basildi();

           


        }

        private void borca_yaz_alishi_Duymesi_Basildi()
        { 
            
            
            if(borc_yazilan_musteri_label1.Text.Equals(":::")){
            
           // string umumiPulString = cem_mebleg_aktiv_label.Text;


            // double umumiPul = Convert.ToDouble(umumiPulString.Substring(0, umumiPulString.Length - 4));
            BorcluSecimiForm borcluSiyahisi = new BorcluSecimiForm(this);
            borcluSiyahisi.Show();}else{borc_yazilan_musteri_label1.Text=":::";}
             
        }
        public void borclununAdiniGoster()
        {
            borc_yazilan_musteri_label1.Text = BorcluSecimiForm.secilenBorcluAdi;
        }


    }
}
