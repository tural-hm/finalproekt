﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MagazaProqramiDEA
{
    public partial class BalansaMedaxilMexaric : Form
    {
        int tip;
        public BalansaMedaxilMexaric(int tip)
        {
            InitializeComponent();
            this.tip = tip;
            if (tip == 1)
            {
                emeliyyatin_tipi_label1.Text = "Mədaxil olunan məbləği daxil edin"; label3.Visible = false;
                firmalar_comboBox1.Visible = false;
                yeni_firma_button1.Visible = false;

            }
            else if (tip == 0)
            {
                emeliyyatin_tipi_label1.Text = "Məxaric olunan məbləği daxil edin";
                label3.Visible=true;
firmalar_comboBox1.Visible=true;
yeni_firma_button1.Visible = true;
firmalar_comboBox1.Items.Add("Firmalar");
foreach (string s in Baza.cedvelden_melumat_oxumaq_tek_sutun("borclar", "kime", ""))
{
    firmalar_comboBox1.Items.Add(s);
} firmalar_comboBox1.SelectedIndex = 0;


            }
        }

        private void daxil_olunan_mebleg_textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            Baza.doubleYazmagaIcaze(sender, e);
        }

        private void testiqlemek_duymesi_button1_Click(object sender, EventArgs e)
        {
            switch (tip)
            {
                case 0:
                    {
                        string meblegString = daxil_olunan_mebleg_textBox1.Text.Trim();
                        if (meblegString.Equals(""))
                        {
                            Baza.msg("Düzgün ədəd daxil etmək lazımdır.");
                        }
                        else
                        {
                            double cariBalans = Baza.cedvelden_tek_double("info", "daxili", "ad", "balans_miqdari", 4);
                            double mebleg = Double.Parse(meblegString);
                            cariBalans -= mebleg;
                            Baza.iud("update info set daxili='" + cariBalans + "' where ad='balans_miqdari'");
                            string qeyd = qeyd_textBox1.Text.Trim();
                            string firma = ""+firmalar_comboBox1.SelectedItem;
                            if (firma.Equals("Firmalar")) { firma = ""; } else { Baza.iud("update borclar set borc=borc-" + mebleg + " where kime='" + firma + "'"); }
                            Baza.iud("insert into balansemeliyyatlari (tarix,tip,qeyd,mebleg,firma) values ('" + Baza.indiki_tarix() + "'," + 0 + ",'" + qeyd + "','" + mebleg + "','"+firma+"')");
                            this.Close();
                        }
                    }; break;
                case 1:
                    {
                        string meblegString = daxil_olunan_mebleg_textBox1.Text.Trim();
                        if (meblegString.Equals(""))
                        {
                            Baza.msg("Düzgün ədəd daxil etmək lazımdır.");
                        }
                        else
                        {
                            double cariBalans = Baza.cedvelden_tek_double("info", "daxili", "ad", "balans_miqdari", 4);
                            double mebleg = Double.Parse(meblegString);
                            cariBalans += mebleg;
                            Baza.iud("update info set daxili='" + cariBalans + "' where ad='balans_miqdari'");
                            string qeyd = qeyd_textBox1.Text.Trim();
                            Baza.iud("insert into balansemeliyyatlari (tarix,tip,qeyd,mebleg) values ('" + Baza.indiki_tarix() + "'," + 1 + ",'" + qeyd + "','" + mebleg + "')");
                            this.Close();
                        }
                    }; break;
                default: { }; break;
            }
            
        }

        private void yeni_firma_button1_Click(object sender, EventArgs e)
        {

            string yeniFirmaAdi = Microsoft.VisualBasic.Interaction.InputBox("Yeni firmanın adını daxil edin", "Yeni firma", "");

            if (yeniFirmaAdi.Trim().Equals("")) { }
            else
            {
                string yeniFirmaTelefonu = Microsoft.VisualBasic.Interaction.InputBox("Yeni firmanın telefonunu daxil edin", "Yeni firma telefonu", "");
                string yeniFirmaSahibi = Microsoft.VisualBasic.Interaction.InputBox("Yeni firmanın sahibinin adını daxil edin", "Yeni firma sahibi", "");


                string yeniFirmaNumayendesi = Microsoft.VisualBasic.Interaction.InputBox("Yeni firmanın nümayəndəsinin adını daxil edin", "Yeni firma nümayəndəsi", "");


             
                Baza.iud("insert into borclar (kime,tarix,tel,sahibi,numayende) values ('" + yeniFirmaAdi + "','" + Baza.indiki_tarix() + "','" + yeniFirmaTelefonu + "','" + yeniFirmaSahibi + "','" + yeniFirmaNumayendesi + "')");


                firmalar_comboBox1.Items.Add(yeniFirmaAdi);
            }

        }

        private void BalansaMedaxilMexaric_Load(object sender, EventArgs e)
        {

        }
    }
}
