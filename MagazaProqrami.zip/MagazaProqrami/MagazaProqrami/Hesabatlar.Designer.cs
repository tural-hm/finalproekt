﻿namespace MagazaProqramiDEA
{
    partial class Hesabatlar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Hesabatlar));
            this.esas_tabControl1 = new System.Windows.Forms.TabControl();
            this.kassa_tabPage1 = new System.Windows.Forms.TabPage();
            this.esas_kassa_tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.kassa_list_tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.kassalar_listBox1 = new System.Windows.Forms.ListBox();
            this.satis_tipi_groupBox1 = new System.Windows.Forms.GroupBox();
            this.qaytarilanlar_radioButton2 = new System.Windows.Forms.RadioButton();
            this.satilanlar_radioButton1 = new System.Windows.Forms.RadioButton();
            this.silinenler_checkBox1 = new System.Windows.Forms.CheckBox();
            this.esas_tabControl1.SuspendLayout();
            this.kassa_tabPage1.SuspendLayout();
            this.esas_kassa_tableLayoutPanel1.SuspendLayout();
            this.kassa_list_tableLayoutPanel1.SuspendLayout();
            this.satis_tipi_groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // esas_tabControl1
            // 
            this.esas_tabControl1.Controls.Add(this.kassa_tabPage1);
            this.esas_tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.esas_tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.esas_tabControl1.Location = new System.Drawing.Point(0, 0);
            this.esas_tabControl1.Name = "esas_tabControl1";
            this.esas_tabControl1.SelectedIndex = 0;
            this.esas_tabControl1.Size = new System.Drawing.Size(988, 531);
            this.esas_tabControl1.TabIndex = 0;
            // 
            // kassa_tabPage1
            // 
            this.kassa_tabPage1.Controls.Add(this.esas_kassa_tableLayoutPanel1);
            this.kassa_tabPage1.Location = new System.Drawing.Point(4, 29);
            this.kassa_tabPage1.Name = "kassa_tabPage1";
            this.kassa_tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.kassa_tabPage1.Size = new System.Drawing.Size(980, 498);
            this.kassa_tabPage1.TabIndex = 0;
            this.kassa_tabPage1.Text = "KASSA";
            this.kassa_tabPage1.UseVisualStyleBackColor = true;
            // 
            // esas_kassa_tableLayoutPanel1
            // 
            this.esas_kassa_tableLayoutPanel1.ColumnCount = 2;
            this.esas_kassa_tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 200F));
            this.esas_kassa_tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.esas_kassa_tableLayoutPanel1.Controls.Add(this.kassa_list_tableLayoutPanel1, 0, 0);
            this.esas_kassa_tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.esas_kassa_tableLayoutPanel1.Location = new System.Drawing.Point(3, 3);
            this.esas_kassa_tableLayoutPanel1.Name = "esas_kassa_tableLayoutPanel1";
            this.esas_kassa_tableLayoutPanel1.RowCount = 1;
            this.esas_kassa_tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.esas_kassa_tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 560F));
            this.esas_kassa_tableLayoutPanel1.Size = new System.Drawing.Size(974, 492);
            this.esas_kassa_tableLayoutPanel1.TabIndex = 0;
            // 
            // kassa_list_tableLayoutPanel1
            // 
            this.kassa_list_tableLayoutPanel1.ColumnCount = 1;
            this.kassa_list_tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.kassa_list_tableLayoutPanel1.Controls.Add(this.kassalar_listBox1, 0, 0);
            this.kassa_list_tableLayoutPanel1.Controls.Add(this.satis_tipi_groupBox1, 0, 1);
            this.kassa_list_tableLayoutPanel1.Controls.Add(this.silinenler_checkBox1, 0, 2);
            this.kassa_list_tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.kassa_list_tableLayoutPanel1.Location = new System.Drawing.Point(3, 3);
            this.kassa_list_tableLayoutPanel1.Name = "kassa_list_tableLayoutPanel1";
            this.kassa_list_tableLayoutPanel1.RowCount = 4;
            this.kassa_list_tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 300F));
            this.kassa_list_tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.kassa_list_tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.kassa_list_tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.kassa_list_tableLayoutPanel1.Size = new System.Drawing.Size(194, 486);
            this.kassa_list_tableLayoutPanel1.TabIndex = 0;
            // 
            // kassalar_listBox1
            // 
            this.kassalar_listBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.kassalar_listBox1.FormattingEnabled = true;
            this.kassalar_listBox1.ItemHeight = 20;
            this.kassalar_listBox1.Location = new System.Drawing.Point(3, 3);
            this.kassalar_listBox1.Name = "kassalar_listBox1";
            this.kassalar_listBox1.Size = new System.Drawing.Size(188, 294);
            this.kassalar_listBox1.TabIndex = 0;
            // 
            // satis_tipi_groupBox1
            // 
            this.satis_tipi_groupBox1.Controls.Add(this.qaytarilanlar_radioButton2);
            this.satis_tipi_groupBox1.Controls.Add(this.satilanlar_radioButton1);
            this.satis_tipi_groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.satis_tipi_groupBox1.Location = new System.Drawing.Point(3, 303);
            this.satis_tipi_groupBox1.Name = "satis_tipi_groupBox1";
            this.satis_tipi_groupBox1.Size = new System.Drawing.Size(188, 94);
            this.satis_tipi_groupBox1.TabIndex = 1;
            this.satis_tipi_groupBox1.TabStop = false;
            // 
            // qaytarilanlar_radioButton2
            // 
            this.qaytarilanlar_radioButton2.AutoSize = true;
            this.qaytarilanlar_radioButton2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.qaytarilanlar_radioButton2.Location = new System.Drawing.Point(34, 55);
            this.qaytarilanlar_radioButton2.Name = "qaytarilanlar_radioButton2";
            this.qaytarilanlar_radioButton2.Size = new System.Drawing.Size(120, 21);
            this.qaytarilanlar_radioButton2.TabIndex = 1;
            this.qaytarilanlar_radioButton2.TabStop = true;
            this.qaytarilanlar_radioButton2.Text = "Qaytarılanlar";
            this.qaytarilanlar_radioButton2.UseVisualStyleBackColor = true;
            this.qaytarilanlar_radioButton2.CheckedChanged += new System.EventHandler(this.qaytarilanlar_radioButton2_CheckedChanged);
            // 
            // satilanlar_radioButton1
            // 
            this.satilanlar_radioButton1.AutoSize = true;
            this.satilanlar_radioButton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.satilanlar_radioButton1.Location = new System.Drawing.Point(34, 24);
            this.satilanlar_radioButton1.Name = "satilanlar_radioButton1";
            this.satilanlar_radioButton1.Size = new System.Drawing.Size(95, 21);
            this.satilanlar_radioButton1.TabIndex = 0;
            this.satilanlar_radioButton1.TabStop = true;
            this.satilanlar_radioButton1.Text = "Satılanlar";
            this.satilanlar_radioButton1.UseVisualStyleBackColor = true;
            this.satilanlar_radioButton1.CheckedChanged += new System.EventHandler(this.satilanlar_radioButton1_CheckedChanged);
            // 
            // silinenler_checkBox1
            // 
            this.silinenler_checkBox1.AutoSize = true;
            this.silinenler_checkBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.silinenler_checkBox1.Location = new System.Drawing.Point(3, 403);
            this.silinenler_checkBox1.Name = "silinenler_checkBox1";
            this.silinenler_checkBox1.Size = new System.Drawing.Size(188, 34);
            this.silinenler_checkBox1.TabIndex = 2;
            this.silinenler_checkBox1.Text = "Silinənlər";
            this.silinenler_checkBox1.UseVisualStyleBackColor = true;
            // 
            // Hesabatlar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(988, 531);
            this.Controls.Add(this.esas_tabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Hesabatlar";
            this.Text = "Hesabatlar";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Hesabatlar_Load);
            this.esas_tabControl1.ResumeLayout(false);
            this.kassa_tabPage1.ResumeLayout(false);
            this.esas_kassa_tableLayoutPanel1.ResumeLayout(false);
            this.kassa_list_tableLayoutPanel1.ResumeLayout(false);
            this.kassa_list_tableLayoutPanel1.PerformLayout();
            this.satis_tipi_groupBox1.ResumeLayout(false);
            this.satis_tipi_groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl esas_tabControl1;
        private System.Windows.Forms.TabPage kassa_tabPage1;
        private System.Windows.Forms.TableLayoutPanel esas_kassa_tableLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel kassa_list_tableLayoutPanel1;
        private System.Windows.Forms.ListBox kassalar_listBox1;
        private System.Windows.Forms.GroupBox satis_tipi_groupBox1;
        private System.Windows.Forms.RadioButton qaytarilanlar_radioButton2;
        private System.Windows.Forms.RadioButton satilanlar_radioButton1;
        private System.Windows.Forms.CheckBox silinenler_checkBox1;
    }
}