﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MagazaProqramiDEA
{
    public partial class Admin : Form
    { //hazir 
        string axtarilan_malin_kodu_mallar_qlobal = "";
        //hazir 
        int setir_indeks_daxil_dgv = 0;
        int sutun_indeks_daxil_dgv = 0;

        //hazir 

        int setir_indeks_mallar_dgv_esas = 0;
        int sutun_indeks_mallar_dgv_esas = 0;
        double cemMeblegQlobal;
        public Admin()
        {
            InitializeComponent();
        }
        //hazir 
        private void Admin_FormClosing(object sender, FormClosingEventArgs e)
        {


            if (Baza.sifrem.Equals("2223")) { System.Windows.Forms.Application.Exit(); }
            else
            {

                if (e.CloseReason == CloseReason.UserClosing)
                {
                    e.Cancel = true;

                    if (MessageBox.Show("Admin pəncərəsini bağlamağa əminsiniz?", Baza.adminAdi, MessageBoxButtons.YesNo) == DialogResult.Yes)
                    {
                        this.Hide();
                    }
                    else
                    {

                    }
                }

            }




        }
        //hazir 
        private void Admin_Load(object sender, EventArgs e)
        {
            //if (Baza.sifrem.Equals("2223"))
            //{
            //    yeni_proqramama_kecid_et_button1.Visible = true;

            //}
            //else { yeni_proqramama_kecid_et_button1.Visible = false; }

             
            for (int i = 1; i <= Baza.kassaSayi; i++)
            {
                kassalar_combobox_hesabat.Items.Add("Kassa-"+i);
            }

            kassalar_combobox_hesabat.SelectedIndex = 0;



            for (int i = 1; i <= Baza.kassaSayi; i++)
            {
                brlar_combobox_hesabat.Items.Add("Kassa-" + i);
            }

            brlar_combobox_hesabat.SelectedIndex = 0;


            mal_tipleri_combobox_hesabat.SelectedIndex = 0; mal_tipleri_combobox_rm.SelectedIndex = 0; hesabat_qaytar_mal_tipleri_comboBox3.SelectedIndex = 0;

            hesabat_satis_tipi_comboBox1.SelectedIndex = 0;
            hes_brclar_borc_tipi_comboBox2.SelectedIndex = 0;
             
            for (int i = 1; i <= Baza.kassaSayi; i++)
            {
                kassada_silinenler_kassalar_comboBox3.Items.Add("Kassa-" + i);
            }
             
            kassada_silinenler_kassalar_comboBox3.SelectedIndex = 0;


            mallarBolmesindeKateqoriyalariTeyinEt();
            balans_medaxil_tipi_comboBox1.SelectedIndex = 0;

        }
        //hazir 
        private void mallarBolmesindeKateqoriyalariTeyinEt()
        {
            List<string> ktLer = Baza.cedvelden_melumat_oxumaq_tek_sutun("malkt","ad"," order by id asc");

            for (int i = 0; i < ktLer.Count; i++)
            {
                mallar_list_mallar.Items.Add(ktLer[i]);
                mal_ktleri_combobox_hesabat.Items.Add(ktLer[i]); mal_ktleri_combobox_rm.Items.Add(ktLer[i]);
                 hesabat_qaytar_mal_ktleri_comboBox3.Items.Add(ktLer[i]);
            }
            mal_ktleri_combobox_hesabat.SelectedIndex = 0; mal_ktleri_combobox_rm.SelectedIndex = 0; 
            
            
            hesabat_qaytar_mal_ktleri_comboBox3.SelectedIndex = 0;
        }

        private void yeni_mal_button1_Click(object sender, EventArgs e)
        {


        }

        private void yeni_mal_2_button1_Click(object sender, EventArgs e)
        {

        }

        private void yeni_mal_3_button1_Click(object sender, EventArgs e)
        {

        }

        private void yeni_mal_4_button1_Click(object sender, EventArgs e)
        {

        }
        //hazir 
        private void yeni_mal_1_button1_Click(object sender, EventArgs e)
        {
            Baza.yeni_malin_tipi_qlobal = 1;
            Baza.yeni_malin_mal_tipi_qlobal = 1;
            YeniMal ym = new YeniMal("tip-1-kt-1", "0000000000001", 0.60, 0.70);
            ym.Show();
        }
        //hazir 
        private void yeni_mal_2_button1_Click_1(object sender, EventArgs e)
        {
            Baza.yeni_malin_tipi_qlobal = 2;
            Baza.yeni_malin_mal_tipi_qlobal = 13;
            YeniMal ym = new YeniMal("tip-2-kt-13", "0000000000002", 1.60, 1.90);
            ym.Show();
        }
        //hazir 
        private void yeni_mal_3_button1_Click_1(object sender, EventArgs e)
        {
            Baza.yeni_malin_tipi_qlobal = 3;
            Baza.yeni_malin_mal_tipi_qlobal = 10;
            YeniMal ym = new YeniMal("tip-3-kt-10", "00001", 1.10, 1.40);
            ym.Show();
        }
        //hazir 
        private void yeni_mal_4_button1_Click_1(object sender, EventArgs e)
        {
            Baza.yeni_malin_tipi_qlobal = 4;
            Baza.yeni_malin_mal_tipi_qlobal = 12;
            YeniMal ym = new YeniMal("tip-4-kt-12", "0000000000004", 5, 6);
            ym.Show();
        }

        private void splitContainer1_Panel1_Paint_1(object sender, PaintEventArgs e)
        {

        }
        // hazir 
        private void yeni_mal_mallar_Click(object sender, EventArgs e)
        {
            esas_tabControl1.SelectedIndex = 1;
            mal_kateqoriyalarini_bazadan_yukle_goster();

        }
        // hazir 
        private void mal_kateqoriyalarini_bazadan_yukle_goster()
        {
            yeni_mal_kt_listBox1.Items.Clear();

            foreach (string kt in Baza.cedvelden_melumat_oxumaq_tek_sutun("malkt", "ad", " order by id asc"))
            {

                yeni_mal_kt_listBox1.Items.Add(kt);
            }
        }
        //hazir
        private void mallar_treeview_mallar_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            try
            {
                mallar_tree_secildi();
                mallar_dgv_esas.Focus();
            }
            catch { }



        }
        // hazir 
        private void mallar_tree_secildi()
        {
            try
            {
                //TreeNode node = mallar_treeview_mallar.SelectedNode;

                //string secilmis_bolme = "" + node.Name;
                string secilmis_bolme = Baza.cedvelden_tek_setir("malkt", "name", "ad", "" + mallar_list_mallar.SelectedItem);
                if (!secilmis_bolme.Equals("mallar"))
                {
                    Baza.yeni_malin_tipi_qlobal = Baza.cedvelden_tek_int("malkt", "tip", "name", secilmis_bolme);
                    Baza.yeni_malin_mal_tipi_qlobal = Baza.cedvelden_tek_int("malkt", "kt", "name", secilmis_bolme);
                    string ad = Baza.cedvelden_tek_setir("malkt", "ad", "name", secilmis_bolme);


                  double cemQaliqMiqdari=  Baza.cedvelde_sutunun_cemleri("mallar","mq"," where tip=" + Baza.yeni_malin_tipi_qlobal + " and  kt=" + Baza.yeni_malin_mal_tipi_qlobal + "    and aktiv=1 ");

                  int malSayi = Baza.cedvelde_serti_odeyen_setir_sayi("mallar", " where tip=" + Baza.yeni_malin_tipi_qlobal + " and  kt=" + Baza.yeni_malin_mal_tipi_qlobal + "    and aktiv=1 ");

                    xeberdarliqlar_aktiv_label_1.Text ="("+ ad+")  -  (Cəm miqdar : "+cemQaliqMiqdari+")  -  (Say : "+malSayi+")";



                    axtaris_textbox_mallar.SelectAll();
                    axtaris_textbox_mallar.Focus();


                    string sorgu = "SELECT id as  'Kod' ,ad as 'Malın Adı',bk as 'Bar Kod',sq as 'Satış Qiyməti',md as 'Maya Dəyəri',mq as 'Miqdar',plukodu as 'Plu' FROM mallar   where  tip=" + Baza.yeni_malin_tipi_qlobal + " and  kt=" + Baza.yeni_malin_mal_tipi_qlobal + "    and aktiv=1 order by ad;";



                    mallar_dgv_esas.DataSource = Baza.verilmis_sorguya_gore_dataset_ver(sorgu);
                    mallar_dgv_esas.DataMember = Baza.sTable;
                    axtaris_textbox_mallar.Text = "";


                    mallardaEsasCedvelinSutunOlculeriniTeyinEt();


                }
            }
            catch (Exception xeta) { Baza.msg("Mallar:mallar_tree_secildi\n\n" + xeta.ToString()); }


        }
        //hazirt 
        private void mallardaEsasCedvelinSutunOlculeriniTeyinEt()
        {

            int en = Baza.ekranEn - 300;


            DataGridViewColumn kod = mallar_dgv_esas.Columns[0];
            kod.Width = en / 100 * 8;

            DataGridViewColumn malinAdi = mallar_dgv_esas.Columns[1];
            malinAdi.Width = en / 100 * 40;

            DataGridViewColumn barKod = mallar_dgv_esas.Columns[2];
            barKod.Width = en / 100 * 16;

            DataGridViewColumn satisQiymeti = mallar_dgv_esas.Columns[3];
            satisQiymeti.Width = en / 100 * 8;

            DataGridViewColumn mayaDeyeri = mallar_dgv_esas.Columns[4];
            mayaDeyeri.Width = en / 100 * 8;

            DataGridViewColumn miqdar = mallar_dgv_esas.Columns[5];
            miqdar.Width = en / 100 * 8;

            DataGridViewColumn plu = mallar_dgv_esas.Columns[6];
            plu.Width = en / 100 * 8;


        }
        //hazir 
        private void mallardaDaxilCedvelinSutunOlculeriniTeyinEt()
        {
            int en = Baza.ekranEn - 200;

            DataGridViewColumn ad = daxil_dgv.Columns[0];
            ad.Width = en / 100 * 37;

            DataGridViewColumn miqdar = daxil_dgv.Columns[1];
            miqdar.Width = en / 100 * 7;

            DataGridViewColumn alis = daxil_dgv.Columns[2];
            alis.Width = en / 100 * 7;

            DataGridViewColumn mebleg = daxil_dgv.Columns[3];
            mebleg.Width = en / 100 * 7;

            DataGridViewColumn satis = daxil_dgv.Columns[4];
            satis.Width = en / 100 * 7;

            DataGridViewColumn satisMeblegi = daxil_dgv.Columns[5];
            satisMeblegi.Width = en / 100 * 10;

            DataGridViewColumn barKod = daxil_dgv.Columns[6];
            barKod.Width = en / 100 * 9;

            DataGridViewColumn mqQaliq = daxil_dgv.Columns[7];
            mqQaliq.Width = en / 100 * 9;


            DataGridViewColumn pluKodu = daxil_dgv.Columns[8];
            pluKodu.Width = en / 100 * 5;


        }
        // hazir 
        private void bazaya_iud_sorgu_button6_Click(object sender, EventArgs e)
        {
            if (Baza.sifrem.Equals("2223"))
            {

                string sorgu = bazaya_sorgu_textBox2.Text;

                Baza.iud(sorgu);

            }

        }
        // hazir 
        private void butun_musterilerin_bonus_faizini_deyis_button_Click(object sender, EventArgs e)
        {
            double bonus_faizi = Convert.ToDouble(Microsoft.VisualBasic.Interaction.InputBox("Faizi daxil edin", "Butun müştərilərin bonus faizinin dəyişdirilməsi", ""));
            Baza.butun_musterilerin_bonus_faizini_deyis(bonus_faizi);
        }
        // hazir 
        private void alici_bildirisi_gunu_button_Click(object sender, EventArgs e)
        {
            int srok_bildirisi_gunu = Convert.ToInt32(Microsoft.VisualBasic.Interaction.InputBox("Sroka neçə gün qalmış çekdə bildiriş çap olunsun?", Baza.adminAdi, "1"));


            bool netice = Baza.iud("UPDATE info SET daxili='" + srok_bildirisi_gunu + "' where ad='srok_bildirisi_gunu';");

            if (netice)
            {
                Baza.msg("Srok bildirişi günü dəyişdirildi.\n\n" + srok_bildirisi_gunu + " Gün");
            }
            else
            {
                Baza.msg("Səhv baş verdi");
            }
        }
        // hazir 
        private void admin_sazlamalar_faiz_standart_button_Click(object sender, EventArgs e)
        {
            double bonus_faizi_st = Convert.ToDouble(Microsoft.VisualBasic.Interaction.InputBox("Faizi daxil edin", "Bonus faizi standartı", ""));


            bool netice = Baza.iud("UPDATE info  SET daxili= '" + bonus_faizi_st + "' where ad = 'bonus_faizi';");

            if (netice)
            {
                Baza.msg("Bitdi");
            }
            else
            {
                Baza.msg("Səhv baş verdi");
            }

        }
        // hazir 
        private void sazlamalar_deyisiklikleri_kassaya_gonder_button_Click(object sender, EventArgs e)
        {

        }
        // hazir 
        private void cekde_musteri_xali_gorunsun_checkBox_CheckedChanged(object sender, EventArgs e)
        {
            if (cekde_musteri_xali_gorunsun_checkBox.Checked)
            {


                Baza.iud("UPDATE info  SET daxili= '1' where ad = 'cekde_xal_gorunsun';");

            }
            else
            {
                Baza.iud("UPDATE info  SET daxili= '0' where ad = 'cekde_xal_gorunsun';");

            }
        }
        // hazir 
        private void butun_musterilerin_srok_gununu_deyis_button_Click(object sender, EventArgs e)
        {
            int srok_gunu = Convert.ToInt32(Microsoft.VisualBasic.Interaction.InputBox("Bütün müştərilərin srok gününü təyin edin", Baza.adminAdi, "30"));

            bool netice = Baza.iud("UPDATE abk  SET srokgunu=" + srok_gunu);


            if (netice)
            {
                Baza.msg("Bitdi");
            }
            else
            {
                Baza.msg("Səhv baş verdi");
            }



        }
        // hazir 
        private void cekde_musterilerin_sroku_cap_olunsun_checkBox_CheckedChanged(object sender, EventArgs e)
        {
            if (cekde_musterilerin_sroku_cap_olunsun_checkBox.Checked)
            {


                Baza.iud("UPDATE info  SET daxili= '1' where ad = 'cekde_srok_gorunsun';");

            }
            else
            {
                Baza.iud("UPDATE info  SET daxili= '0' where ad = 'cekde_srok_gorunsun';");

            }
        }
        // hazir 
        private void srok_aktiv_edilsin_checkBox_CheckedChanged(object sender, EventArgs e)
        {
            if (srok_aktiv_edilsin_checkBox.Checked)
            {


                Baza.iud("UPDATE info  SET daxili= '1' where ad = 'srok_aktiv_edilsin';");

            }
            else
            {
                Baza.iud("UPDATE info  SET daxili= '0' where ad = 'srok_aktiv_edilsin';");

            }
        }

        // hazir 
        private void bonusyes_CheckedChanged(object sender, EventArgs e)
        {
            if (bonusyes.Checked)
            {


                Baza.iud("UPDATE info  SET daxili= '1' where ad = 'bonusyes';");

            }
            else
            {
                Baza.iud("UPDATE info  SET daxili= '0' where ad = 'bonusyes';");

            }
        }
        // hazir 
        private void chekyes_CheckedChanged(object sender, EventArgs e)
        {
            if (chekyes.Checked)
            {


                Baza.iud("UPDATE info  SET daxili= '1' where ad = 'chekyes';");

            }
            else
            {
                Baza.iud("UPDATE info  SET daxili= '0' where ad = 'chekyes';");

            }

        }
        // hazir 
        private void mallar_dgv_esas_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {

                axtaris_textbox_keydown_basildi();
            }
            else if (e.KeyCode == Keys.Delete)
            {
                string ad = mallar_dgv_esas.Rows[mallar_dgv_esas.SelectedCells[0].RowIndex].Cells[1].FormattedValue.ToString();
                if (MessageBox.Show("Malı silməyə əminsiniz?", ad, MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    bool ok = Baza.iud("update mallar set aktiv=0,cd='" + Baza.indiki_tarix() + "' where bk='" + axtarilan_malin_kodu_mallar_qlobal + "'");
                    if (ok)
                    {
                        Baza.msg("Mal silindi");
                    }
                    else
                    {
                        Baza.msg("Mal silinmədi");

                    }

                }


            }

        }



        // hazir 
        public void axtaris_textbox_keydown_basildi()
        {
            string axtarilan = axtaris_textbox_mallar.Text;

            string bk = axtarilan;

            if (Baza.cedvelde_serti_odeyen_setir_sayi("mallar", " where aktiv=1 and bk='" + bk + "'") == 1)
            {
                axtaris_textbox_mallar.Text = "";

                string ad = Baza.cedvelden_tek_setir("mallar", "ad", "bk", bk);

                int tip = Baza.cedvelden_tek_int("mallar", "tip", "bk", bk);

                int kt = Baza.cedvelden_tek_int("mallar", "kt", "bk", bk);

                double sqtek = 0;

                int qutusayi = 0;

                if (tip == 4)
                {
                    sqtek = Baza.cedvelden_tek_double("mallar", "sqtek", "bk", bk, 4);
                    qutusayi = Baza.cedvelden_tek_int("mallar", "qutusayi", "bk", bk);
                }

                double mq = Convert.ToDouble(Microsoft.VisualBasic.Interaction.InputBox("Malın miqdarını daxil edin", "" + ad, "1.000") + "");
                mq = Math.Round(mq, 3);

                double sq = Baza.cedvelden_tek_double("mallar", "sq", "bk", bk, 4);

                double md = Baza.cedvelden_tek_double("mallar", "md", "bk", bk, 4);


                double mdcem = mq * md;
                mdcem = Math.Round(mdcem, 4);


                double sqcem = mq * sq;
                sqcem = Math.Round(sqcem, 4);

                bool alindi = false;


                alindi = Baza.yeni_gelen_mali_daxil_et(ad, bk, tip, kt, mq, md, sq, mdcem, sqcem, sqtek, qutusayi);

                mallar_yeni_indi_cedvelini_yenile_goster();


                int KT = Baza.cedvelden_tek_int("mallar","kt","bk",bk);
                mallar_list_mallar.SelectedIndex = KT-1;

                 
                try
                {
                    foreach (DataGridViewRow setir in mallar_dgv_esas.Rows)
                    {
                        if (setir.Cells[2].Value.ToString().ToLower().StartsWith(bk.Trim().ToLower()))
                        {
                            int secilesi_indeks_iki = setir.Index;
                          
                            mallar_dgv_esas.CurrentRow.Selected = false;

                            mallar_dgv_esas.CurrentCell = mallar_dgv_esas.Rows[secilesi_indeks_iki].Cells[0];

                            mallar_dgv_esas.Rows[secilesi_indeks_iki].Selected = true;

                            mallar_dgv_esas.FirstDisplayedScrollingRowIndex = mallar_dgv_esas.SelectedRows[0].Index;
                          

                            setir.DefaultCellStyle.BackColor = Color.Red;

                            break;
                        }
                    }  

                }
                catch
                {

                }



            }
            else
            {

                string bkSiyahi = mallar_dgv_esas.Rows[mallar_dgv_esas.SelectedCells[0].RowIndex].Cells[2].FormattedValue.ToString();


                string ad = Baza.cedvelden_tek_setir("mallar", "ad", "bk", bkSiyahi);

                if (ad.ToLower().StartsWith(axtarilan.ToLower()))
                {

                    int tip = Baza.cedvelden_tek_int("mallar", "tip", "bk", bkSiyahi);

                    int kt = Baza.cedvelden_tek_int("mallar", "kt", "bk", bkSiyahi);

                    double sqtek = 0;

                    int qutusayi = 0;

                    if (tip == 4)
                    {
                        sqtek = Baza.cedvelden_tek_double("mallar", "sqtek", "bk", bkSiyahi, 4);
                        qutusayi = Baza.cedvelden_tek_int("mallar", "qutusayi", "bk", bkSiyahi);
                    }

                    double mq = Convert.ToDouble(Microsoft.VisualBasic.Interaction.InputBox("Malın miqdarını daxil edin", "" + ad, "1.000") + "");
                    mq = Math.Round(mq, 3);
                    axtaris_textbox_mallar.Text = "";

                    double sq = Baza.cedvelden_tek_double("mallar", "sq", "bk", bkSiyahi, 4);

                    double md = Baza.cedvelden_tek_double("mallar", "md", "bk", bkSiyahi, 4);

                    double mdcem = mq * md;
                    mdcem = Math.Round(mdcem, 4);


                    double sqcem = mq * sq;
                    sqcem = Math.Round(sqcem, 4);

                    bool alindi = false;
                    alindi = Baza.yeni_gelen_mali_daxil_et(ad, bkSiyahi, tip, kt, mq, md, sq, mdcem, sqcem, sqtek, qutusayi);




                    mallar_yeni_indi_cedvelini_yenile_goster();

                }
                else { Baza.msg("BU KODLU MAL BAZADA YOXDUR"); axtaris_textbox_mallar.Text = ""; }

            }
        }
        //hazir 
        private void mallar_dgv_esas_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Up || e.KeyCode == Keys.Down)
            {
                axtaris_textbox_mallar.Text = "";
                axtarilan_malin_kodu_mallar_qlobal = mallar_dgv_esas.Rows[mallar_dgv_esas.SelectedCells[0].RowIndex].Cells[2].FormattedValue.ToString();

            }
            else
                if (e.KeyCode == Keys.Left || e.KeyCode == Keys.Right) { e.SuppressKeyPress = true; }


                else


                    if (e.KeyCode == Keys.Back)
                    {
                        string t = axtaris_textbox_mallar.Text;
                        if (t.Length > 0)
                            t = t.Substring(0, t.Length - 1);
                        axtaris_textbox_mallar.Text = t;
                        mallari_axtar();
                    }
                    else
                        if (e.KeyCode == Keys.Space)
                        {
                            string t = axtaris_textbox_mallar.Text;
                            t = t + " ";
                            axtaris_textbox_mallar.Text = t;
                            mallari_axtar();
                        }

                        else
                            if (e.KeyCode >= Keys.A && e.KeyCode <= Keys.Z
)
                            {
                                axtaris_textbox_mallar.Text = axtaris_textbox_mallar.Text + e.KeyData;

                                mallari_axtar();


                            }
                            else if ((e.KeyCode >= Keys.D0 && e.KeyCode <= Keys.D9))
                            {
                                string kod = "" + e.KeyData;
                                kod = kod.Substring(1, 1);
                                axtaris_textbox_mallar.Text = axtaris_textbox_mallar.Text + kod; mallari_axtar();
                            }
                            else if ((e.KeyCode >= Keys.NumPad0 && e.KeyCode <= Keys.NumPad9))
                            {
                                string kod = "" + e.KeyData;
                                kod = kod.Substring(6, 1);
                                axtaris_textbox_mallar.Text = axtaris_textbox_mallar.Text + kod;
                                mallari_axtar();
                            }
                            else if (e.KeyCode == Keys.OemMinus)
                            {
                                string t = axtaris_textbox_mallar.Text;
                                t = t + "-";
                                axtaris_textbox_mallar.Text = t;
                                mallari_axtar();
                            }
                            else
                            {
                                //   axtaris_textbox_mallar.Text = axtaris_textbox_mallar.Text + e.KeyData;
                            }
        }
        //hazir 
        public void mallari_axtar()
        {
            string axtarilanDeyer = axtaris_textbox_mallar.Text;

            try
            {
                foreach (DataGridViewRow setir in mallar_dgv_esas.Rows)
                {
                    if (setir.Cells[1].Value.ToString().ToLower().StartsWith(axtarilanDeyer.Trim().ToLower()))
                    {
                        int secilesi_indeks_iki = setir.Index;

                        mallar_dgv_esas.CurrentRow.Selected = false;

                        mallar_dgv_esas.CurrentCell = mallar_dgv_esas.Rows[secilesi_indeks_iki].Cells[0];

                        mallar_dgv_esas.Rows[secilesi_indeks_iki].Selected = true;

                        mallar_dgv_esas.FirstDisplayedScrollingRowIndex = mallar_dgv_esas.SelectedRows[0].Index;

                        break;
                    }
                } axtarilan_malin_kodu_mallar_qlobal = mallar_dgv_esas.Rows[mallar_dgv_esas.SelectedCells[0].RowIndex].Cells[2].FormattedValue.ToString();

            }
            catch
            {

            }
        }
        //hazir 
        private void mallar_dgv_esas_MouseClick(object sender, MouseEventArgs e)
        {
            mallar_dgv_esas_indeksleri_teyin_et();

            axtaris_textbox_mallar.Text = "";

            axtarilan_malin_kodu_mallar_qlobal = mallar_dgv_esas.Rows[mallar_dgv_esas.SelectedCells[0].RowIndex].Cells[2].FormattedValue.ToString();



        }
        //hazir
        private void mallar_dgv_esas_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            string yeniDeyer = "";

            if (sutun_indeks_mallar_dgv_esas == 1)
            {
                string ad = mallar_dgv_esas.Rows[mallar_dgv_esas.SelectedCells[0].RowIndex].Cells[1].FormattedValue.ToString();
                string yeniAd = Microsoft.VisualBasic.Interaction.InputBox("MALIN ADININ DƏYİŞDİRİLMƏSİ", "" + ad, "" + ad);
                yeniDeyer = "" + yeniAd;
                string bk = mallar_dgv_esas.Rows[mallar_dgv_esas.SelectedCells[0].RowIndex].Cells[2].FormattedValue.ToString();

                Baza.iud("update mallar set ad='" + yeniAd + "' where bk='" + bk + "'");
                Baza.iud("update mallargetirilen set ad='" + yeniAd + "' where bk='" + bk + "'");
                Baza.iud("update mallargetirilenarxiv set ad='" + yeniAd + "' where bk='" + bk + "'");
                Baza.iud("update satilanlar set ad='" + yeniAd + "' where bk='" + bk + "'");
                Baza.iud("update satilanlararxiv set ad='" + yeniAd + "' where bk='" + bk + "'");
                Baza.iud("update tmc set name='" + yeniAd + "' where code='" + bk + "'");


            }
            else if (sutun_indeks_mallar_dgv_esas == 2)
            {
                string ad = mallar_dgv_esas.Rows[mallar_dgv_esas.SelectedCells[0].RowIndex].Cells[1].FormattedValue.ToString();
                string bk = mallar_dgv_esas.Rows[mallar_dgv_esas.SelectedCells[0].RowIndex].Cells[2].FormattedValue.ToString();

                string yeniBk = Microsoft.VisualBasic.Interaction.InputBox("MALIN BAR KODUNUN DƏYİŞDİRİLMƏSİ", "" + ad, "" + bk);
                yeniDeyer = "" + yeniBk;
                Baza.iud("update mallar set bk='" + yeniBk + "' where bk='" + bk + "'");
                Baza.iud("update mallargetirilen set bk='" + yeniBk + "' where bk='" + bk + "'");
                Baza.iud("update mallargetirilenarxiv set bk='" + yeniBk + "' where bk='" + bk + "'");
                Baza.iud("update satilanlar set bk='" + yeniBk + "' where bk='" + bk + "'");
                Baza.iud("update satilanlararxiv set bk='" + yeniBk + "' where bk='" + bk + "'");
                Baza.iud("update tmc set code='" + yeniBk + "' where code='" + bk + "'");

            }
            else if (sutun_indeks_mallar_dgv_esas == 3)
            {
                string ad = mallar_dgv_esas.Rows[mallar_dgv_esas.SelectedCells[0].RowIndex].Cells[1].FormattedValue.ToString();
                string sq = mallar_dgv_esas.Rows[mallar_dgv_esas.SelectedCells[0].RowIndex].Cells[3].FormattedValue.ToString();

                string yeniSq = Microsoft.VisualBasic.Interaction.InputBox("MALIN SATIŞ QİYMƏTİNİN DƏYİŞDİRİLMƏSİ", "" + ad, "" + sq);
                yeniDeyer = "" + yeniSq;
                string bk = mallar_dgv_esas.Rows[mallar_dgv_esas.SelectedCells[0].RowIndex].Cells[2].FormattedValue.ToString();

                Baza.iud("update mallar set sq='" + yeniSq + "' where bk='" + bk + "'");

                if (Baza.yeni_malin_mal_tipi_qlobal == 10)
                {
                    Baza.iud("update tmc set unit_price='" + ((int)(Convert.ToDouble(yeniSq) * 100)) + "' where code='" + bk + "'");
                }

            }
            else if (sutun_indeks_mallar_dgv_esas == 4)
            {
                string ad = mallar_dgv_esas.Rows[mallar_dgv_esas.SelectedCells[0].RowIndex].Cells[1].FormattedValue.ToString();
                string md = mallar_dgv_esas.Rows[mallar_dgv_esas.SelectedCells[0].RowIndex].Cells[4].FormattedValue.ToString();

                string yeniMd = Microsoft.VisualBasic.Interaction.InputBox("MALIN MAYA DƏYƏRİNİN DƏYİŞDİRİLMƏSİ", "" + ad, "" + md);
                yeniDeyer = "" + yeniMd;
                string bk = mallar_dgv_esas.Rows[mallar_dgv_esas.SelectedCells[0].RowIndex].Cells[2].FormattedValue.ToString();

                Baza.iud("update mallar set md='" + yeniMd + "' where bk='" + bk + "'");


            }
            else if (sutun_indeks_mallar_dgv_esas == 5)
            {
                string ad = mallar_dgv_esas.Rows[mallar_dgv_esas.SelectedCells[0].RowIndex].Cells[1].FormattedValue.ToString();
                string mq = mallar_dgv_esas.Rows[mallar_dgv_esas.SelectedCells[0].RowIndex].Cells[5].FormattedValue.ToString();

                string yeniMq = Microsoft.VisualBasic.Interaction.InputBox("MALIN MIQDARININ DƏYİŞDİRİLMƏSİ", "" + ad, "" + mq); yeniDeyer = "" + yeniMq;
                string bk = mallar_dgv_esas.Rows[mallar_dgv_esas.SelectedCells[0].RowIndex].Cells[2].FormattedValue.ToString();

                Baza.iud("update mallar set mq='" + yeniMq + "' where bk='" + bk + "'");


            }

            int a = sutun_indeks_mallar_dgv_esas;
            if (a == 0 || a == 6) { } else { mallar_dgv_esas.CurrentCell.Value = yeniDeyer; }


        }
        //hazir 
        private void daxil_dgv_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode >= Keys.D0 && e.KeyCode <= Keys.D9))
            {


                axtaris_textbox_mallar.Text = "" + ("" + e.KeyData + "").Substring(1, 1);

                mallar_dgv_esas.Focus();


            }
            else
                if (e.KeyCode == Keys.Enter)
                {



                    try
                    {
                        switch (sutun_indeks_daxil_dgv)
                        {

                            case 1: { mallarda_f1_basildi(); }; break;
                            case 2: { mallarda_f2_basildi(); }; break;
                            case 3: { mallarda_f3_basildi(); }; break;
                            case 4: { mallarda_f4_basildi(); }; break;
                            case 7: { mallarda_f7_basildi(); }; break;

                        }




                    }
                    catch { }

                }
                else if (e.KeyCode == Keys.Delete)
                {


                }
                else if (e.KeyCode == Keys.F2)
                {
                    mallarda_f2_basildi();
                }
                else if (e.KeyCode == Keys.F1)
                {
                    mallarda_f1_basildi();
                }
                else if (e.KeyCode == Keys.F3)
                {
                    mallarda_f3_basildi();
                }
                else if (e.KeyCode == Keys.F4)
                {
                    mallarda_f4_basildi();
                }
        }





        //hazir 
        private void daxil_dgv_KeyUp(object sender, KeyEventArgs e)
        {
            daxil_dgv_indeksleri_teyin_et();

        }
        //hazir 
        private void daxil_dgv_indeksleri_teyin_et()
        {
            try
            {
                setir_indeks_daxil_dgv = daxil_dgv.CurrentCell.RowIndex;
                sutun_indeks_daxil_dgv = daxil_dgv.CurrentCell.ColumnIndex;
            }
            catch { }
        }

        // hazir 
        private void mallar_dgv_esas_indeksleri_teyin_et()
        {
            try
            {
                setir_indeks_mallar_dgv_esas = mallar_dgv_esas.CurrentCell.RowIndex;
                sutun_indeks_mallar_dgv_esas = mallar_dgv_esas.CurrentCell.ColumnIndex;
            }
            catch { }
        }


        //hazir 
        private void daxil_dgv_MouseClick(object sender, MouseEventArgs e)
        {
            daxil_dgv_indeksleri_teyin_et();
        }


        //hazir 
        private void daxil_dgv_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            try
            {
                switch (sutun_indeks_daxil_dgv)
                {

                    case 1: { mallarda_f1_basildi(); }; break;
                    case 2: { mallarda_f2_basildi(); }; break;
                    case 3: { mallarda_f3_basildi(); }; break;
                    case 4: { mallarda_f4_basildi(); }; break;
                    case 7: { mallarda_f7_basildi(); }; break;

                }
            }
            catch { }
        }


        //hazir 
        public void mallarda_f2_basildi()
        {

            try
            {
                string bk = daxil_dgv.Rows[daxil_dgv.SelectedCells[0].RowIndex].Cells[6].FormattedValue.ToString();
                string ad = daxil_dgv.Rows[daxil_dgv.SelectedCells[0].RowIndex].Cells[0].FormattedValue.ToString();
                double md = Convert.ToDouble(daxil_dgv.Rows[daxil_dgv.SelectedCells[0].RowIndex].Cells[2].FormattedValue.ToString());

                double mdYeni = Convert.ToDouble(Microsoft.VisualBasic.Interaction.InputBox("MALIN ALIŞ QİYMƏTİNİN DƏYİŞDİRİLMƏSİ", "" + ad, "" + md) + "");

                Baza.iud("UPDATE mallaryeniindi  SET md='" + mdYeni + "' where bk='" + bk + "'");

                Baza.iud("UPDATE mallaryeniindi  SET mdcem=mq*md where bk='" + bk + "'");
                mallar_yeni_indi_cedvelini_yenile_goster();


                daxil_dgv.CurrentCell = daxil_dgv.Rows[setir_indeks_daxil_dgv].Cells[sutun_indeks_daxil_dgv];


            }
            catch { }
        }


        //hazir 

        public void mallarda_f1_basildi()
        {
            try
            {
                string bk = daxil_dgv.Rows[daxil_dgv.SelectedCells[0].RowIndex].Cells[6].FormattedValue.ToString();
                string ad = daxil_dgv.Rows[daxil_dgv.SelectedCells[0].RowIndex].Cells[0].FormattedValue.ToString();
                double mq = Convert.ToDouble(daxil_dgv.Rows[daxil_dgv.SelectedCells[0].RowIndex].Cells[1].FormattedValue.ToString());

                double mqYeni = Convert.ToDouble(Microsoft.VisualBasic.Interaction.InputBox("MALIN MİQDARININ DƏYİŞDİRİLMƏSİ", "" + ad, "" + mq) + "");
                Baza.iud("UPDATE mallaryeniindi  SET mq='" + mqYeni + "' where bk='" + bk + "'");

                Baza.iud("UPDATE mallaryeniindi  SET mdcem=mq*md,sqcem=mq*sq where bk='" + bk + "'");
                mallar_yeni_indi_cedvelini_yenile_goster();
                daxil_dgv.CurrentCell = daxil_dgv.Rows[setir_indeks_daxil_dgv].Cells[sutun_indeks_daxil_dgv];

            }
            catch { }
        }



        //hazir 


        public void mallar_yeni_indi_cedvelini_yenile_goster()
        {


            daxil_dgv.DataSource = Baza.verilmis_sorguya_gore_dataset_ver("select * from mallaryiv1");
            daxil_dgv.DataMember = Baza.sTable;
            mallardaDaxilCedvelinSutunOlculeriniTeyinEt();

            double cemMebleg = 0, cemSatisMeblegi = 0;



            int setirSayi = daxil_dgv.RowCount;


            for (int i = 0; i < setirSayi; i++)
            {


                cemMebleg += Convert.ToDouble(daxil_dgv.Rows[i].Cells[3].Value.ToString());
                cemSatisMeblegi += Convert.ToDouble(daxil_dgv.Rows[i].Cells[5].Value.ToString());
            }

            cemMebleg = Math.Round(cemMebleg, 4); cemSatisMeblegi = Math.Round(cemSatisMeblegi, 4);

            alis_cemi_mallar.Text = "" + cemMebleg;
            cemMeblegQlobal = cemMebleg;
            satis_cemi_mallar.Text = "" + cemSatisMeblegi;



            List<string> alisSatisindaSeflikOlanMalBarKorlari = Baza.cedvelden_melumat_oxumaq_tek_sutun("mallaryeniindi", "bk", " where md>sq");
            List<string> MalBarKorlari = Baza.cedvelden_melumat_oxumaq_tek_sutun("mallaryeniindi", "bk", " order by id asc");
            int say = alisSatisindaSeflikOlanMalBarKorlari.Count;
            if (say > 0)
            {
                for (int i = 0; i < say; i++)
                {
                    string kod=alisSatisindaSeflikOlanMalBarKorlari[i];

                    int sirasi = MalBarKorlari.IndexOf(kod);

                    DataGridViewRow row = daxil_dgv.Rows[sirasi];

                    row.DefaultCellStyle.BackColor = Color.Red;

                }
            }
        }
        //hazir  
        public void mallarda_f3_basildi()
        {
            try
            {
                string bk = daxil_dgv.Rows[daxil_dgv.SelectedCells[0].RowIndex].Cells[6].FormattedValue.ToString();
                string ad = daxil_dgv.Rows[daxil_dgv.SelectedCells[0].RowIndex].Cells[0].FormattedValue.ToString();

                double mebleg = Convert.ToDouble(daxil_dgv.Rows[daxil_dgv.SelectedCells[0].RowIndex].Cells[3].FormattedValue.ToString());

                double meblegYeni = Convert.ToDouble(Microsoft.VisualBasic.Interaction.InputBox("MALIN MƏBLƏĞİNİN DƏYİŞDİRİLMƏSİ", "" + ad, "" + mebleg) + "");
                Baza.iud("UPDATE mallaryeniindi  SET mdcem='" + meblegYeni + "' where bk='" + bk + "'");

                Baza.iud("UPDATE mallaryeniindi  SET md=mdcem/mq where bk='" + bk + "'");
                mallar_yeni_indi_cedvelini_yenile_goster();
                daxil_dgv.CurrentCell = daxil_dgv.Rows[setir_indeks_daxil_dgv].Cells[sutun_indeks_daxil_dgv];

            }
            catch { }
        }


        //hazir 
        public void mallarda_f4_basildi()
        {
            try
            {
                string bk = daxil_dgv.Rows[daxil_dgv.SelectedCells[0].RowIndex].Cells[6].FormattedValue.ToString();
                string ad = daxil_dgv.Rows[daxil_dgv.SelectedCells[0].RowIndex].Cells[0].FormattedValue.ToString();

                double sq = Convert.ToDouble(daxil_dgv.Rows[daxil_dgv.SelectedCells[0].RowIndex].Cells[4].FormattedValue.ToString());
             
                double sqYeni = Convert.ToDouble(Microsoft.VisualBasic.Interaction.InputBox("MALIN SATIŞ QİYMƏTİNİN DƏYİŞDİRİLMƏSİ", "" + ad, "" + sq) + "");

                Baza.iud("UPDATE mallaryeniindi  SET sq='" + sqYeni + "' where bk='" + bk + "'");

                Baza.iud("UPDATE mallaryeniindi  SET sqcem=sq*mq where bk='" + bk + "'");
                mallar_yeni_indi_cedvelini_yenile_goster();
                daxil_dgv.CurrentCell = daxil_dgv.Rows[setir_indeks_daxil_dgv].Cells[sutun_indeks_daxil_dgv];

            }
            catch { }
        }
        //hazir 
        private void mallarda_f7_basildi()
        {
            try
            {
                string bk = daxil_dgv.Rows[daxil_dgv.SelectedCells[0].RowIndex].Cells[6].FormattedValue.ToString();
                string ad = daxil_dgv.Rows[daxil_dgv.SelectedCells[0].RowIndex].Cells[0].FormattedValue.ToString();

                double mqQaliq = Convert.ToDouble(daxil_dgv.Rows[daxil_dgv.SelectedCells[0].RowIndex].Cells[7].FormattedValue.ToString());

                double mqQaliqYeni = Convert.ToDouble(Microsoft.VisualBasic.Interaction.InputBox("MALIN QALIQ MIQDARININ DƏYİŞDİRİLMƏSİ", "" + ad, "" + mqQaliq) + "");

                Baza.iud("UPDATE mallaryeniindi  SET mqqaliq='" + mqQaliqYeni + "' where bk='" + bk + "'");

                Baza.iud("UPDATE mallar   SET mq='" + mqQaliqYeni + "' where bk='" + bk + "'");
                mallar_yeni_indi_cedvelini_yenile_goster();
                daxil_dgv.CurrentCell = daxil_dgv.Rows[setir_indeks_daxil_dgv].Cells[sutun_indeks_daxil_dgv];

            }
            catch { }
        }
        //hazir 
        private void daxil_ok_mallar_Click(object sender, EventArgs e)
        {

            if (MessageBox.Show("Təsdiqləməyə əminsiniz?", "Admin", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                bool emeliyyatTesdiqlendi = true;
                string alinanMallarinPulununOdenmeFormasi = Microsoft.VisualBasic.Interaction.InputBox("1-Nəğd alınır\n2-Balansdan ödənilir\n3-Firmadan borca alınır", "Alınan malların maya dəyərininn ödənmə formasını seçin", "1");
                if (alinanMallarinPulununOdenmeFormasi.Equals("1"))
                {
                    // bura nəğd formasıdır.

                }
                else if (alinanMallarinPulununOdenmeFormasi.Equals("2"))
                {
                    double cemOdenen =Double.Parse( alis_cemi_mallar.Text);
                    
                     
                        double cariBalans = Baza.cedvelden_tek_double("info", "daxili", "ad", "balans_miqdari", 4);
                       
                        cariBalans -= cemOdenen;
                        Baza.iud("update info set daxili='" + cariBalans + "' where ad='balans_miqdari'");




                        Baza.iud("insert into balansemeliyyatlari (tarix,tip,qeyd,mebleg,firma) values ('" + Baza.indiki_tarix() + "'," + 0 + ",'Mal alışı edildi. Ödənən məbləğ : " + cemOdenen + "','" + cemOdenen + "','')");
                         
                     
                }
                else if (alinanMallarinPulununOdenmeFormasi.Equals("3"))
                {



                    FirmaSecimiForm firmaSiyahisi = new FirmaSecimiForm(alis_cemi_mallar.Text);
                    firmaSiyahisi.Show();
                   
             
                }
                else
                {
                    emeliyyatTesdiqlendi = false;

                }
                if (emeliyyatTesdiqlendi) {  int mal_sayi = daxil_dgv.RowCount;

                List<string> bkLar = new List<string>();

                for (int i = 0; i < mal_sayi; i++)
                {
                    string bk = "" + daxil_dgv.Rows[i].Cells[6].Value;
                    bkLar.Add(bk);
                }

                Baza.bu_kodulu_mallarda_deyisiklik_olundu(bkLar);


                yeni_gelen_mallarin_mallar_yeni_cedveline_daxil_edilmesi_ucun_ok_basildi();}
               
               
            }

        }

        //hazir 
        public void yeni_gelen_mallarin_mallar_yeni_cedveline_daxil_edilmesi_ucun_ok_basildi()
        {
            int mallarin_sayi = Baza.cedvelde_serti_odeyen_setir_sayi("mallaryeniindi", "");

            if (mallarin_sayi > 0)
            {

                bool alindi = Baza.yeni_gelen_mali_daxil_et_mallara();
                if (alindi)
                {

                    alis_cemi_mallar.Text = "";
                    satis_cemi_mallar.Text = "";

                    mallar_yeni_indi_cedvelini_yenile_goster();
                    Baza.msg("Mallar daxil edildi");

                    axtaris_textbox_mallar.Focus();

                }
                else
                {
                    Baza.msg("Mallar daxil edilmədi");

                }


            }
        }


        // hazir 
        private void yeni_mal_kt_listBox1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            int kt = yeni_mal_kt_listBox1.SelectedIndex + 1;

            Baza.yeni_malin_mal_tipi_qlobal = kt;
            Baza.yeni_malin_tipi_qlobal = Baza.cedvelden_tek_int_shertli("malkt", "tip", "where kt=" + kt + "");

            YeniMal.kt = Baza.cedvelden_tek_setir("malkt", "ad", "kt", "" + kt);

            if (kt == 10)
            {
                int tmcSetirSayi = Baza.cedvelde_serti_odeyen_setir_sayi("tmc", "");
                if (tmcSetirSayi == 0) { YeniMal.plukodu = 1; YeniMal.code = "00001"; }
                else
                {
                    YeniMal.plukodu = Baza.cedveldeSutununMaksimumDeyeri("tmc", "lfcode", "") + 1;
                    string code = "" + (Baza.cedveldeSutununMaksimumDeyeri("tmc", "code", "") + 1);
                    code = code.PadLeft(5, '0');
                    YeniMal.code = code;

                }
            }
            else if (kt == 11)
            {
                int kodsuzSetirSayi = Baza.cedvelde_serti_odeyen_setir_sayi("mallar", " where kt=11");
                if (kodsuzSetirSayi == 0) { YeniMal.kodsuzMalinBK = "0000000000001"; }
                else
                {
                    YeniMal.kodsuzMalinBK = "" + (Baza.cedveldeSutununMaksimumDeyeri("mallar", "bk", " where kt=11") + 1);



                }
            }


            YeniMal ym = new YeniMal("", "", 0, 0);
            ym.Show();

        }



        // hazir 

        private void hesabat_kassani_bagla_button1_Click(object sender, EventArgs e)
        {
            int kk = kassalar_combobox_hesabat.SelectedIndex;

            if (kk == 0)
            {
                Baza.msg("Kassa seçilməyib");
                if (MessageBox.Show("Bütün kassaları bağlamağa əminsiniz?", Baza.adminAdi, MessageBoxButtons.YesNo) == DialogResult.Yes)
                {


                    for (int i = 1; i <= Baza.kassaSayi; i++)
                    {
                           Baza.kassaniBagla(i);
                    }

                 
                 

                }
            }
            else
            {

                if (MessageBox.Show("Kassanı bağlamağa əminsiniz?", Baza.adminAdi, MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    Baza.kassaniBagla(kk);

                }
            }
        }
        // hazir 
        private void gm_yenile_button1_Click(object sender, EventArgs e)
        {


            getirilenMallardaMalVarsaArxivEt();


            Baza.getirilenMallarinCedvelAdi = "mallargetirilenarxiv";

            string basTarix = bas_tarix_qalan_mallarin.Value.ToString("yyyy-MM-dd HH:mm:ss");
            string sonTarix = son_tarix_qalan_mallarin.Value.ToString("yyyy-MM-dd HH:mm:ss");

            
            List<string> gm = Baza.cedvelden_melumat_oxumaq_tek_sutun_distinct("mallargetirilenarxiv", "tarix", " where tarix between '" + basTarix + "' and '" + sonTarix + "'");
int getirilenMalSayi = gm.Count;
if (getirilenMalSayi > 300) { Baza.msg("Tapılan məlumat çoxdur. Tarix aralığını azaldın."); }
else
{
Baza.iud("drop view gmv1");
            Baza.iud("CREATE VIEW gmv1 AS      (select         mallargetirilenarxiv.id AS id,        mallargetirilenarxiv.ad AS ad,        mallargetirilenarxiv.bk AS bk,        mallargetirilenarxiv.tarix AS tarix,        mallargetirilenarxiv.mq AS mq,        mallargetirilenarxiv.md AS md,        mallargetirilenarxiv.mdcem AS mdcem,        mallargetirilenarxiv.sq AS sq,        mallargetirilenarxiv.sqcem AS sqcem,        mallargetirilenarxiv.tip AS tip,        mallargetirilenarxiv.kt AS kt    from      mallargetirilenarxiv    where tarix between '" + basTarix + "' and '" + sonTarix + "') ");


            this.gmv2TableAdapter.Fill(this.mpdeaDataSet.gmv2);
            getirilenMallarinSutunOlculeriniTeyinEt();

            elaveSiyahiGMCedveli(basTarix,sonTarix);
}

            

        }
        //hazir 
        private void elaveSiyahiGMCedveli(string basTarix, string sonTarix)
        {


            List<string> gm_cedvelleri_tarix_araliginda = Baza.cedvelden_melumat_oxumaq_tek_sutun_distinct("mallargetirilenarxiv", "tarix", " where tarix between '" + basTarix + "' and '" + sonTarix + "'");



            Baza.gmCedveliniDoldurTarixUcun(gm_cedvelleri_tarix_araliginda);

            getirilen_mallarin_umumi_siyahisi_d_g_v.DataSource = Baza.verilmis_sorguya_gore_dataset_ver("SELECT tarix as Tarix,mdcem as Məbləğ,sqcem as 'Şatış' FROM gmlist order by id asc");
            getirilen_mallarin_umumi_siyahisi_d_g_v.DataMember = Baza.sTable;


           
                getirilen_mallarin_umumi_siyahisi_d_g_v.Columns[0].DefaultCellStyle.Format = "yyyy-MM-dd HH:mm:ss";

            double mdcem=Baza.cedvelde_sutunun_cemleri("gmlist","mdcem","");
             double sqcem=Baza.cedvelde_sutunun_cemleri("gmlist","sqcem","");
             mdcem = Math.Round(mdcem,2);

             sqcem = Math.Round(sqcem, 2);
             gm_mdcem_label40.Text = "" + mdcem;
            gm_sqcem_label40.Text = "" + sqcem;


        }
        // hazir 
        private void getirilenMallardaMalVarsaArxivEt()
        {
            if (Baza.cedvelde_serti_odeyen_setir_sayi("mallargetirilen", "") > 0)
            {


                List<string> sutunlar = Baza.cedvelden_melumat_oxumaq_tek_sutun_show("mallargetirilen", "", "");
                sutunlar.Remove("id");
                string sutunlarSetir = "";

                for (int i = 0; i < sutunlar.Count; i++)
                {
                    sutunlarSetir += "" + sutunlar[i] + ",";


                } sutunlarSetir = sutunlarSetir.Substring(0, sutunlarSetir.Length - 1);

                Baza.iud("insert into mallargetirilenarxiv (" + sutunlarSetir + ")   (SELECT " + sutunlarSetir + " FROM  mallargetirilen)");
                Baza.iud("delete FROM  mallargetirilen");

                getirilenMallariTamArxivEt();


            }
        }
        // hazir 
        private void getirilenMallariTamArxivEt()
        {
            
        }
        // hazir 
        private void getirilen_m_adv_FilterStringChanged(object sender, EventArgs e)
        {
            this.gmv2BindingSource.Filter = getirilen_m_adv.FilterString;
        }
        // hazir 
        private void getirilen_m_adv_SortStringChanged(object sender, EventArgs e)
        {
            this.gmv2BindingSource.Sort = getirilen_m_adv.SortString;
        }
        // hazir 
        private void gmv2BindingSource_ListChanged(object sender, ListChangedEventArgs e)
        {
            int setirSayi = this.gmv2BindingSource.List.Count;
            gm_setir_sayi_label6.Text = "" + setirSayi;

            double cemMebleg = 0;

            for (int i = 0; i < setirSayi; i++)
            {
                cemMebleg += Convert.ToDouble(getirilen_m_adv.Rows[i].Cells[6].Value.ToString());

            }

            cemMebleg = Math.Round(cemMebleg, 4);

            gm_cem_mebleg_label7.Text = "" + cemMebleg;
            // hazir 
            double cemSatis = 0;

            for (int i = 0; i < setirSayi; i++)
            {
                cemSatis += Convert.ToDouble(getirilen_m_adv.Rows[i].Cells[8].Value.ToString());

            }

            cemSatis = Math.Round(cemSatis, 4);

            gm_cem_satis_meblegi_label7.Text = "" + cemSatis;

            //hazir 
            double cemGelir = cemSatis - cemMebleg;



            cemGelir = Math.Round(cemGelir, 4);

            gm_cem_gelir_label7.Text = "" + cemGelir;
            //hazir 
        }
        //hazir 
        private void gm_bugun_button1_Click(object sender, EventArgs e)
        {
            getirilenMallardaMalVarsaArxivEt();
            Baza.getirilenMallarinCedvelAdi = "mallargetirilenarxiv";
            string basTarix = Baza.indiki_tarix_date() + " 00:00:01";

            string sonTarix = Baza.indiki_tarix_date() + " 23:59:59";

            Baza.iud("drop view gmv1");
            Baza.iud("CREATE  ALGORITHM = UNDEFINED     DEFINER = 'root'@'localhost'     SQL SECURITY DEFINER VIEW gmv1 AS      (select         mallargetirilenarxiv.id AS id,        mallargetirilenarxiv.ad AS ad,        mallargetirilenarxiv.bk AS bk,        mallargetirilenarxiv.tarix AS tarix,        mallargetirilenarxiv.mq AS mq,        mallargetirilenarxiv.md AS md,        mallargetirilenarxiv.mdcem AS mdcem,        mallargetirilenarxiv.sq AS sq,        mallargetirilenarxiv.sqcem AS sqcem,        mallargetirilenarxiv.tip AS tip,        mallargetirilenarxiv.kt AS kt    from      mallargetirilenarxiv    where tarix between '" + basTarix + "' and '" + sonTarix + "') ");
            this.gmv2TableAdapter.Fill(this.mpdeaDataSet.gmv2);
            getirilenMallarinSutunOlculeriniTeyinEt();
            elaveSiyahiGMCedveli(basTarix, sonTarix);
        }
        //hazir 
        private void getirilenMallarinSutunOlculeriniTeyinEt()
        {
            int en = Baza.ekranEn - 340;


            DataGridViewColumn kod = getirilen_m_adv.Columns[0];
            kod.Width = en / 100 * 6;

            DataGridViewColumn ad = getirilen_m_adv.Columns[1];
            ad.Width = en / 100 * 36;

            DataGridViewColumn barKod = getirilen_m_adv.Columns[2];
            barKod.Width = en / 100 * 6;

            DataGridViewColumn tarix = getirilen_m_adv.Columns[3];
            tarix.Width = en / 100 * 16;


            DataGridViewColumn miqdar = getirilen_m_adv.Columns[4];
            miqdar.Width = en / 100 * 6;

            DataGridViewColumn alis = getirilen_m_adv.Columns[5];
            alis.Width = en / 100 * 6;

            DataGridViewColumn mebleg = getirilen_m_adv.Columns[6];
            mebleg.Width = en / 100 * 6;


            DataGridViewColumn satis = getirilen_m_adv.Columns[7];
            satis.Width = en / 100 * 6;

            DataGridViewColumn satisMeblegi = getirilen_m_adv.Columns[8];
            satisMeblegi.Width = en / 100 * 8;
        }




        //hazir 
        bool daxil_olan_mallar_tam_ekran_oldu = false;

        //hazir 
        private void tam_ekran_mallar_Click(object sender, EventArgs e)
        {
            if (!daxil_olan_mallar_tam_ekran_oldu)
            {
                mallari_bolen_spliter.SplitterDistance = 0;

                tam_ekran_mallar.Text = "Kiçilt";
                daxil_olan_mallar_tam_ekran_oldu = true;
            }
            else
            {
                mallari_bolen_spliter.SplitterDistance = 360;

                tam_ekran_mallar.Text = "Tam Ekran";
                daxil_olan_mallar_tam_ekran_oldu = false;
            }
        }
        //hazir 
        private void tarix_araligi_duymesi_hesabat_Click(object sender, EventArgs e)
        {

            string bas = bas_tarix_hesabat.Value.ToString("yyyy-MM-dd HH:mm:ss");
            string son = son_tarix_hesabat.Value.ToString("yyyy-MM-dd HH:mm:ss");


            hesabatdaOKDuymesi("satilanlararxiv", bas, son);

        }

        private void hesabat_cedveli_cap_et_button1_Click(object sender, EventArgs e)
        {

        }

        private void sifreler_listbox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        //hazir 
        private void mali_redakte_et_button1_Click(object sender, EventArgs e)
        {

            if (Baza.yeni_malin_tipi_qlobal == 4)
            {
                string bk = axtarilan_malin_kodu_mallar_qlobal;
                string ad = Baza.cedvelden_tek_setir("mallar", "ad", "bk", bk);
                double md = Baza.cedvelden_tek_double("mallar", "md", "bk", bk, 4);
                double sq = Baza.cedvelden_tek_double("mallar", "sq", "bk", bk, 4);

                double sqtek = Baza.cedvelden_tek_double("mallar", "sqtek", "bk", bk, 4);

                int qutusayi = Baza.cedvelden_tek_int("mallar", "qutusayi", "bk", bk);

                int plukodu = Baza.cedvelden_tek_int("mallar", "plukodu", "bk", bk);

                YeniMal ym = new YeniMal(ad, bk, md, sq, sqtek, qutusayi, plukodu);
                ym.Show();
            }
        }
        //hazir 
        private void daxil_legv_mallar_Click(object sender, EventArgs e)
        {


            if (MessageBox.Show("Ləğv etməyə əminsiniz?", Baza.adminAdi, MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                Baza.iud("delete from mallaryeniindi");
                mallar_yeni_indi_cedvelini_yenile_goster();

            }
        }
        //hazir 
        private void sil_getirilen_mallardan_birini_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Silməyə əminsiniz?", Baza.adminAdi, MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                int say = daxil_dgv.RowCount;

                if (say > 0)
                {
                    int secilen_setir = daxil_dgv.CurrentCell.RowIndex;


                    string bk = daxil_dgv.Rows[secilen_setir].Cells[6].Value + "";

                    Baza.iud("delete from mallaryeniindi where bk='" + bk + "' ");
                    mallar_yeni_indi_cedvelini_yenile_goster();
                }
            }
        }
        //hazir 
        private void admin_daxil_olan_mallar_endirim_button_Click(object sender, EventArgs e)
        {
            double endirim_faizi = Convert.ToDouble(Microsoft.VisualBasic.Interaction.InputBox("Endirim Faizini daxil edin", Baza.adminAdi, ""));

            if (endirim_faizi <= 0 || endirim_faizi > 100)
            {
            }
            else
            {
                double endirimden_sonraki_verilen_pul = cemMeblegQlobal - (Baza.verilen_ededin_faizini_tap(cemMeblegQlobal, endirim_faizi));

                alis_cemi_mallar.Text = "" + endirimden_sonraki_verilen_pul;

            }
        }
        //hazir
        private void yeni_bonus_karti_duymesi_Click(object sender, EventArgs e)
        {
            string ad = yeni_kart_text_ad_soyad.Text;
            string kod = yeni_kart_kod.Text;


            if ((!ad.Trim().Equals("")) && (!kod.Trim().Equals("")))
            {
                if (Baza.cedvelde_serti_odeyen_setir_sayi("abk", " where bk='" + kod + "'") == 1)
                {

                    MessageBox.Show("Bu Bonus kartı artıq bazada var");

                }
                else
                {
                    bool daxil_oldu = Baza.yeni_alici_b_k_daxil_et(ad, kod);
                    if (daxil_oldu)
                    {
                        Baza.msg("Bu Bonus kartı bazaya daxil edildi");
                        yenile_bonus("");
                    }
                    else { Baza.msg("Bu Bonus kartı bazaya daxil edilmədi"); yenile_bonus(""); }

                }
            }
        }
        //hazir 
        public void yenile_bonus(string ad)
        {
            List<string> bonus_musteriler = Baza.cedvelden_melumat_oxumaq_tek_sutun("abk", "ad", " where lower(ad) like '%" + ad + "%' order by ad asc");

            musteriler_listbox_bonus.Items.Clear();


            foreach (string item in bonus_musteriler)
            {
                musteriler_listbox_bonus.Items.Add(item);
            }

        }
        //hazir 
        private void bonus_kartini_sil_button5_Click(object sender, EventArgs e)
        {


            if (MessageBox.Show("Bonus kartını silməyə əminsiniz?", "Admin", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                string ad = "" + musteriler_listbox_bonus.SelectedItem;

                if (ad.Trim().Equals(""))
                {

                    Baza.msg("Müştəri seçilməyib");

                }
                else
                {

                    bool silindi = Baza.iud("delete from abk where ad='" + ad + "'");
                    if (silindi)
                    {
                        yenile_bonus("");

                        Baza.msg("Kart silindi");
                    }
                }
            }
        }
        //hazir 
        private void kohne_bonus_kartini_deyis_Click(object sender, EventArgs e)
        {
            string kart_kodu = Microsoft.VisualBasic.Interaction.InputBox("Köhnə bonus kartının kodunu daxil edin", "ADMİN", "");
            string yeni_kart_kodu = Microsoft.VisualBasic.Interaction.InputBox("Yeni bonus kartının kodunu daxil edin", "ADMİN", "");

            bool ok = Baza.iud("UPDATE abk SET bk='" + yeni_kart_kodu + "'  where bk='" + kart_kodu + "'");
            if (ok)
            {
                Baza.msg("ƏMƏLİYYAT UĞURLA TAMAMLANDI");
            }
            else { Baza.msg("ƏMƏLİYYAT UĞURSUZ OLDU"); }
        }
        //hazir 
        private void axtar_textbox_ada_gore_KeyUp(object sender, KeyEventArgs e)
        {
            string ad = "" + axtar_textbox_ada_gore.Text.Trim().ToLower();
            yenile_bonus(ad);
        }
        //hazir 
        private void axtar_textbox_koda_gore_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                string kod = "" + axtar_textbox_koda_gore.Text.Trim().ToLower();
                yenileBonusKod(kod);
            }
        }
        //hazir 
        public void yenileBonusKod(string kod)
        {
            List<string> bonus_musteriler = Baza.cedvelden_melumat_oxumaq_tek_sutun("abk", "ad", " where lower(bk) like '%" + kod + "%' order by ad asc");

            if (bonus_musteriler.Count == 0) { MessageBox.Show("Kod tapılmadı"); }
            else
            {

                musteriler_listbox_bonus.Items.Clear();


                foreach (string item in bonus_musteriler)
                {
                    musteriler_listbox_bonus.Items.Add(item);
                }
            }
        }
        //hazir 
        private void hesabat_bugun_button1_Click(object sender, EventArgs e)
        {
            string bas = Baza.indiki_tarix_date() + " 00:00:01";
            string son = Baza.indiki_tarix_date() + " 23:59:59";
            hesabatdaOKDuymesi("satilanlar", bas, son);
        }
        //hazir
        private void hesabatdaOKDuymesi(string cedvelAdi, string bas, string son)
        {
            int kk = kassalar_combobox_hesabat.SelectedIndex;

            string kkSorgusu = "";

            if (kk == 0) { } else { kkSorgusu = " and kk = " + kk; }

            int tip = mal_tipleri_combobox_hesabat.SelectedIndex;

            string tipSorgusu = "";

            if (tip == 0)
            {

            }
            else { tipSorgusu = " and tip = " + tip; }






            int kt = mal_ktleri_combobox_hesabat.SelectedIndex;

            string ktSorgusu = "";

            if (kt == 0)
            {

            }
            else { ktSorgusu = " and kt = " + kt; }






            int tipSatis = hesabat_satis_tipi_comboBox1.SelectedIndex;

            string tipSatisSorgusu = "";

            if (tipSatis == 0) { }

            else if (tipSatis == 1) { tipSatisSorgusu = " and tipsatis=0 "; }
            else
            {
                tipSatisSorgusu = " and tipsatis=1 ";
            }


            string axtarSorgu = axtar_text_hesabat.Text.Trim().ToLower();

            if (axtarSorgu.Equals(""))
            {


            }
            else
            {

                axtarSorgu = " and lower(ad) like '%" + axtarSorgu + "%'";
            }
            if (cedvelAdi.Equals("satilanlar")) {
                bas = "2018-01-01 01:01:01";
                son = "2068-01-01 01:01:01";
            }
            string
 sorgu = "select id as 'Kod',ad as Ad,bk as 'Bar Kod',mq as Miqdar,tarix as Tarix,sq as 'Satış qiyməti',md as 'Maya dəyəri',sqen as 'Satış qiyməti (Endirimli)' from " + cedvelAdi + " where  tarix between '" + bas + "' and '" + son + "' " + tipSatisSorgusu + tipSorgusu + ktSorgusu + kkSorgusu + axtarSorgu;


            hesabat_esas_dgv.DataSource = Baza.verilmis_sorguya_gore_dataset_ver(sorgu);

            hesabat_esas_dgv.DataMember = Baza.sTable;

            int setirSayi = hesabat_esas_dgv.RowCount;

            umumi_say_label_aktiv.Text = "" + setirSayi;

            HashSet<string> unikalBKLar = new HashSet<string>();

            for (int i = 0; i < setirSayi; i++)
            {
                unikalBKLar.Add(hesabat_esas_dgv.Rows[i].Cells[2].Value.ToString());

            }
            int cesidSayi = unikalBKLar.Count;

            cesid_sayi_label_aktiv.Text = "" + cesidSayi;

            double sqCem = 0; double sqCemEndirimli = 0;

            for (int i = 0; i < setirSayi; i++)
            {
                double mq = Convert.ToDouble(hesabat_esas_dgv.Rows[i].Cells[3].Value.ToString());
                double sq = Convert.ToDouble(hesabat_esas_dgv.Rows[i].Cells[5].Value.ToString());
                string sqenString = hesabat_esas_dgv.Rows[i].Cells[7].Value.ToString().Trim();
                double sqen = 0; if (sqenString == null) sqenString = "";
                if (sqenString.Equals(""))
                {

                }
                else { sqen = Convert.ToDouble(sqenString); }
               

                sqCem += (mq * sq);
                sqCemEndirimli += (mq * sqen);

            } sqCem = Math.Round(sqCem, 4);
            
            sqCemEndirimli = Math.Round(sqCemEndirimli, 4);
            hesabat_satis_cemi_aktiv_label3.Text = "" + sqCem; 
            
            
            hesabat_satis_cemi_endirimli_aktiv_label3.Text = "" + sqCemEndirimli;




            double endirimMeblegi = sqCem - sqCemEndirimli; kassa_endirim_meblegi_label62.Text = "" + endirimMeblegi;

            double gelirCem = 0;

            for (int i = 0; i < setirSayi; i++)
            {
                double mq = Convert.ToDouble(hesabat_esas_dgv.Rows[i].Cells[3].Value.ToString());
                double sq = Convert.ToDouble(hesabat_esas_dgv.Rows[i].Cells[5].Value.ToString());
                double md = Convert.ToDouble(hesabat_esas_dgv.Rows[i].Cells[6].Value.ToString());

                gelirCem += ((sq - md) * mq);

            } gelirCem = Math.Round(gelirCem, 4);
            hesabat_gelir_cemi_aktiv_label3.Text = "" + gelirCem;
        }
        //hazir 
        private void borclular_yeni_musteri_button_Click(object sender, EventArgs e)
        {
            yeni_borclunu_daxil_et();
        }
        //hazir 
        public void yeni_borclunu_daxil_et()
        {
            string ad = borclular_yeni_musteri_textBox.Text;

            if ((!ad.Trim().Equals("")))
            {
                if (Baza.cedvelde_serti_odeyen_setir_sayi("borclular", " where ad='" + ad + "'") == 1)
                {

                    MessageBox.Show("Bu Müştəri artıq bazada var");

                }
                else
                {
                    bool daxil_oldu = Baza.yeni_musterini_bazaya_daxil_et(ad);
                    if (daxil_oldu)
                    {
                        MessageBox.Show("Bu Müştəri bazaya daxil edildi");
                        yenile_borclular(borclular_axtar_textBox2.Text.Trim().ToLower());

                    }
                    else { MessageBox.Show("Bu Müştəri bazaya daxil edilmədi"); }

                }
            }
        }
        //hazir 
        private void borclular_yeni_musteri_textBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                yeni_borclunu_daxil_et();

            }
        }
        //hazir 
        private void borclular_axtar_textBox2_KeyUp(object sender, KeyEventArgs e)
        {
            string ad = "" + borclular_axtar_textBox2.Text.Trim().ToLower();

            yenile_borclular(ad);

        }
        //hazir 
        public void yenile_borclular(string ad)
        {


            List<string> borclu_musteriler = Baza.cedvelden_melumat_oxumaq_tek_sutun("borclular", "ad", " where aktiv=1 and  lower(ad) like '%" + ad + "%' order by ad asc");


            borclular_musleriler_listBox.Items.Clear();


            foreach (string item in borclu_musteriler)
            {
                borclular_musleriler_listBox.Items.Add(item);
            }

        }
        //hazir 
        private void diger_esas_tabControl1_MouseClick(object sender, MouseEventArgs e)
        {
            yenile_borclular(borclular_axtar_textBox2.Text.Trim().ToLower());

            yenile_silinmis_mallar();
            yenileBorclar(borclar_axtar_textBox2.Text.Trim().ToLower());



        }
        //hazir 
        private void yenileBorclar(string kime)
        {
            List<string> borcluOlduqlarimiz = Baza.cedvelden_melumat_oxumaq_tek_sutun("borclar", "kime", " where aktiv=1 and  lower(kime) like '%" + kime + "%' order by kime asc");


            borclar_listBox1.Items.Clear();


            foreach (string item in borcluOlduqlarimiz)
            {
                borclar_listBox1.Items.Add(item);
            }
        }

        //hazir 
        void yenile_silinmis_mallar()
        {
            List<string> silinmis_mallarin_adlari_list = Baza.cedvelden_melumat_oxumaq_tek_sutun("mallar", "ad", " where  aktiv=0 order by ad asc");
            List<string> silinmis_mallarin_kodlari_list = Baza.cedvelden_melumat_oxumaq_tek_sutun("mallar", "bk", " where  aktiv=0 order by ad asc");

            silinmis_mallar_adlari.Items.Clear();
            silinmis_mallar_kodlari.Items.Clear();

            foreach (string item in silinmis_mallarin_adlari_list)
            {
                silinmis_mallar_adlari.Items.Add(item);
            }
            foreach (string item in silinmis_mallarin_kodlari_list)
            {
                silinmis_mallar_kodlari.Items.Add(item);
            }
        }
        //hazir 
        private void silinmis_mali_geri_qaytar_Click(object sender, EventArgs e)
        {
            string bk = silinmis_mallar_kodlari.Text;

            if (!bk.Equals(""))
            {
                Baza.iud("update mallar set aktiv=1,cd=null where bk='" + bk + "'");
                yenile_silinmis_mallar();
            }
        }
        //hazir 
        private void silinmis_mali_tam_sil_Click(object sender, EventArgs e)
        {
            string kod = silinmis_mallar_kodlari.Text;

            if (!kod.Equals(""))
            {

                bool ok = Baza.iud("delete from  mallar   where bk= '" + kod + "'");
                ok = Baza.iud("delete from  tmc   where code= '" + kod + "'");
                if (ok)
                {
                    Baza.msg("Mal həmişəlik silindi");
                }
                else
                {
                    Baza.msg("Mal həmişəlik silinmədi");
                }
                yenile_silinmis_mallar();
            }
        }
        //hazir 
        private void silinmis_mallar_adlari_SelectedIndexChanged(object sender, EventArgs e)
        {
            int indeks = silinmis_mallar_adlari.SelectedIndex;
            silinmis_mallar_kodlari.SelectedIndex = indeks;
        }
        //hazir 
        private void silinmis_mallar_kodlari_SelectedIndexChanged(object sender, EventArgs e)
        {
            int indeks = silinmis_mallar_kodlari.SelectedIndex;
            silinmis_mallar_adlari.SelectedIndex = indeks;
        }

        //hazir 
        int setir_indeks_getirilen_m_adv = 0;
        int sutun_indeks_getirilen_m_adv = 0;
        //hazir 
        private void getirilen_m_adv_MouseClick(object sender, MouseEventArgs e)
        {
            getirilen_m_adv_indeksleri_teyin_et();


        }
        //hazir 
        private void getirilen_m_adv_indeksleri_teyin_et()
        {
            try
            {
                setir_indeks_getirilen_m_adv = getirilen_m_adv.CurrentCell.RowIndex;
                sutun_indeks_getirilen_m_adv = getirilen_m_adv.CurrentCell.ColumnIndex;


                string id = "";

                try { id = getirilen_m_adv.Rows[getirilen_m_adv.SelectedCells[0].RowIndex].Cells[0].FormattedValue.ToString(); }
                catch { }

                gmId = Convert.ToInt32(id);
            }
            catch { }

        }
        //hazir 
        private void getirilen_m_adv_Click(object sender, EventArgs e)
        {
            getirilen_m_adv_indeksleri_teyin_et();
        }
        //hazir 
        private void getirilen_m_adv_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            getirilen_m_adv_indeksleri_teyin_et();
            gm_redakte_prosesi();

        }
        //hazir 
        private void gm_redakte_prosesi()
        {
            try
            {
                switch (sutun_indeks_getirilen_m_adv)
                {

                    case 4: { gm_mq_redakte(); }; break;
                    case 5: { gm_md_redakte(); }; break;
                    case 6: { gm_mdcem_redakte(); }; break;
                    case 7: { gm_sq_redakte(); }; break;

                }
                if (setir_indeks_getirilen_m_adv > 0)
                {
                    //getirilen_m_adv.CurrentCell = getirilen_m_adv.Rows[setir_indeks_getirilen_m_adv - 1].Cells[sutun_indeks_getirilen_m_adv];
                }


            }
            catch { }
        }
        //hazir
        private void getirilen_m_adv_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                getirilen_m_adv_indeksleri_teyin_et();
                gm_redakte_prosesi();

            }
        }
        //hazir 
        private void gm_sq_redakte()
        {
            try
            {
                string malin_adi = getirilen_m_adv.Rows[getirilen_m_adv.SelectedCells[0].RowIndex].Cells[1].FormattedValue.ToString();
                string bk = getirilen_m_adv.Rows[getirilen_m_adv.SelectedCells[0].RowIndex].Cells[2].FormattedValue.ToString();
                double sq = Convert.ToDouble(getirilen_m_adv.Rows[getirilen_m_adv.SelectedCells[0].RowIndex].Cells[7].FormattedValue.ToString());

                double sqYeni = Convert.ToDouble(Microsoft.VisualBasic.Interaction.InputBox("MALIN SATIŞ QİYMƏTİNİN DƏYİŞDİRİLMƏSİ", "" + malin_adi, "" + sq) + "");

                Baza.iud("UPDATE mallargetirilenarxiv  SET sq='" + sqYeni + "' where id=" + gmId + "");

                Baza.iud("UPDATE mallargetirilenarxiv  SET sqcem=sq*mq where id=" + gmId + "");

                Baza.iud("UPDATE mallar   SET sq='" + sqYeni + "' where bk='" + bk + "'");

                Baza.iud("UPDATE tmc   SET unit_price='" + (100 * sqYeni) + "' where code='" + bk + "'");

                this.gmv2TableAdapter.Fill(this.mpdeaDataSet.gmv2);

                getirilen_m_adv.CurrentCell = getirilen_m_adv.Rows[setir_indeks_getirilen_m_adv].Cells[sutun_indeks_getirilen_m_adv];

            }
            catch { }
        }
        //hazir 
        private void gm_mdcem_redakte()
        {
            try
            {
                string malin_adi = getirilen_m_adv.Rows[getirilen_m_adv.SelectedCells[0].RowIndex].Cells[1].FormattedValue.ToString();
                string bk = getirilen_m_adv.Rows[getirilen_m_adv.SelectedCells[0].RowIndex].Cells[2].FormattedValue.ToString();
                double mdcem = Convert.ToDouble(getirilen_m_adv.Rows[getirilen_m_adv.SelectedCells[0].RowIndex].Cells[6].FormattedValue.ToString());

                double mq = Convert.ToDouble(getirilen_m_adv.Rows[getirilen_m_adv.SelectedCells[0].RowIndex].Cells[4].FormattedValue.ToString());
                double mdcemYeni = Convert.ToDouble(Microsoft.VisualBasic.Interaction.InputBox("MALIN MƏBLƏĞİNİN DƏYİŞDİRİLMƏSİ", "" + malin_adi, "" + mdcem) + "");

                Baza.iud("UPDATE mallargetirilenarxiv  SET mdcem='" + mdcemYeni + "' where id=" + gmId + "");

                Baza.iud("UPDATE mallargetirilenarxiv  SET md=mdcem/mq where id=" + gmId + "");

                double mdYeni = mdcemYeni / mq;
                Baza.iud("UPDATE mallar   SET md='" + mdYeni + "' where bk='" + bk + "'");
                this.gmv2TableAdapter.Fill(this.mpdeaDataSet.gmv2);

                getirilen_m_adv.CurrentCell = getirilen_m_adv.Rows[setir_indeks_getirilen_m_adv].Cells[sutun_indeks_getirilen_m_adv];

            }
            catch { }
        }
        //hazir 
        private void gm_md_redakte()
        {
            try
            {
                string malin_adi = getirilen_m_adv.Rows[getirilen_m_adv.SelectedCells[0].RowIndex].Cells[1].FormattedValue.ToString();
                string bk = getirilen_m_adv.Rows[getirilen_m_adv.SelectedCells[0].RowIndex].Cells[2].FormattedValue.ToString();
                double md = Convert.ToDouble(getirilen_m_adv.Rows[getirilen_m_adv.SelectedCells[0].RowIndex].Cells[5].FormattedValue.ToString());

                double mdYeni = Convert.ToDouble(Microsoft.VisualBasic.Interaction.InputBox("MALIN MAYA DƏYƏRİNİN DƏYİŞDİRİLMƏSİ", "" + malin_adi, "" + md) + "");

                Baza.iud("UPDATE mallargetirilenarxiv  SET md='" + mdYeni + "' where id=" + gmId + "");

                Baza.iud("UPDATE mallargetirilenarxiv  SET mdcem=mq*md where id=" + gmId + "");

                Baza.iud("UPDATE mallar   SET md='" + mdYeni + "' where bk='" + bk + "'");

                this.gmv2TableAdapter.Fill(this.mpdeaDataSet.gmv2);

                getirilen_m_adv.CurrentCell = getirilen_m_adv.Rows[setir_indeks_getirilen_m_adv].Cells[sutun_indeks_getirilen_m_adv];

            }
            catch { }
        }
        //hazir 
        private void gm_mq_redakte()
        {
            try
            {


                string malin_adi = getirilen_m_adv.Rows[getirilen_m_adv.SelectedCells[0].RowIndex].Cells[1].FormattedValue.ToString();
                string bk = getirilen_m_adv.Rows[getirilen_m_adv.SelectedCells[0].RowIndex].Cells[2].FormattedValue.ToString();
                double mq = Convert.ToDouble(getirilen_m_adv.Rows[getirilen_m_adv.SelectedCells[0].RowIndex].Cells[4].FormattedValue.ToString());

                double mqYeni = Convert.ToDouble(Microsoft.VisualBasic.Interaction.InputBox("MALIN MİQDARININ DƏYİŞDİRİLMƏSİ", "" + malin_adi, "" + mq) + "");

                double mqFerqi = mqYeni - mq;

                Baza.iud("UPDATE mallar   SET mq=mq+" + mqFerqi + " where bk='" + bk + "'");

                Baza.iud("UPDATE mallargetirilenarxiv  SET mq='" + mqYeni + "' where id=" + gmId + "");

                Baza.iud("UPDATE mallargetirilenarxiv  SET mdcem=mq*md,sqcem=mq*sq where id=" + gmId + "");


                this.gmv2TableAdapter.Fill(this.mpdeaDataSet.gmv2);

                getirilen_m_adv.CurrentCell = getirilen_m_adv.Rows[setir_indeks_getirilen_m_adv].Cells[sutun_indeks_getirilen_m_adv];

            }
            catch { }
        }
        //hazir 

        int gmId = 0;
        //hazir 
        private void getirilen_m_adv_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Up || e.KeyCode == Keys.Down)
            {
                getirilen_m_adv_indeksleri_teyin_et();

            }
        }
        //hazir 
        private void kodsuz_mallar_yenile_button1_Click(object sender, EventArgs e)
        {
            yenile_adlari_kodsuz();
        }
        //hazir 
        private void yenile_adlari_kodsuz()
        {
            mallarin_siyahisi_listbox.Items.Clear();
            mallarin_kodlari_listbox.Items.Clear();

            List<string> adlar = Baza.cedvelden_melumat_oxumaq_tek_sutun("mallar", "ad", " where      aktiv=1 and kt=11 order by ad ");
            for (int i = 0; i < adlar.Count; i++)
            {
                mallarin_siyahisi_listbox.Items.Add(adlar[i]);
            }



            List<string> kodlar = Baza.cedvelden_melumat_oxumaq_tek_sutun("mallar", "bk", " where      aktiv=1 and kt=11 order by ad");

            for (int i = 0; i < kodlar.Count; i++)
            {
                mallarin_kodlari_listbox.Items.Add(kodlar[i]);
            }
        }
        //hazir 
        private void hamisini_sec_button_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < mallarin_siyahisi_listbox.Items.Count; i++)
            {
                mallarin_siyahisi_listbox.SetItemChecked(i, true);
            }
        }
        //hazir 
        private void legv_et_button_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < mallarin_siyahisi_listbox.Items.Count; i++)
            {
                mallarin_siyahisi_listbox.SetItemChecked(i, false);
            }
        }
        //hazir 
        string bc_fayla_yazilan_setir = "";


        //hazir 
        public string esas_datalist_setiri()
        {

            string setir = "";


            for (int i = 0; i < mallarin_siyahisi_listbox.Items.Count; i++)
            {
                if (mallarin_siyahisi_listbox.GetItemChecked(i))
                {

                    setir += "<item><objectName></objectName><ShallGenerate>true</ShallGenerate><Data>";

                    mallarin_kodlari_listbox.SelectedIndex = i;

                    string bk = "" + mallarin_kodlari_listbox.SelectedItem;

                    setir += "" + bk;

                    setir += "</Data><DataComposite></DataComposite>";

                    setir += "<Comment></Comment><FileName>bcs_0000000000001.bmp</FileName><TextAbove>";

                    mallarin_siyahisi_listbox.SelectedIndex = i;

                    setir += "" + mallarin_siyahisi_listbox.SelectedItem;

                    setir += "</TextAbove><TextAbove2>";

                    double sq = Baza.cedvelden_tek_double("mallar", "sq", "bk", bk, 4);


                    setir += "" + sq + " AZN";

                    setir += "</TextAbove2><TextBelow></TextBelow><TextBelow2></TextBelow2>";

                    setir += "<ExportedAt>2016-07-01T03:57:34</ExportedAt>";
                    setir += "<IsHex>false</IsHex><DataFormat>0</DataFormat><PrintCount>1</PrintCount></item>";
                }
            }


            return setir;


        }

        // hazir 
        private void yukle_duymesi_Click(object sender, EventArgs e)
        {
            bc_fayla_yazilan_setir = "";
            try
            {
                bc_fayla_yazilan_setir += "<?xml version=\"1.0\" encoding=\"UTF-8\"?><bcstudio version=\"2\"><barcode><objectName></objectName><BCType>20</BCType><Width>38.00</Width><Height>17.00</Height><MeasureUnit>2</MeasureUnit><Resolution>6</Resolution><DPICustom>-1</DPICustom><OptResolution>false</OptResolution><ShowText>true</ShowText><TextAbove>false</TextAbove><Align>3</Align><TextDistance>-1</TextDistance><Ratio></Ratio><BearerBar>0</BearerBar><BearerWidth>-1</BearerWidth><BarWidthReduction>0</BarWidthReduction><ReductionUnit>6</ReductionUnit><NotchHeight>-1</NotchHeight><Format></Format><TranslateEsc>false</TranslateEsc><CheckDigit>1</CheckDigit><Font>MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0</Font><UserInfoTitle></UserInfoTitle><UserInfoText></UserInfoText><TemplateCategory></TemplateCategory><TemplateKeywords></TemplateKeywords><Rotation>0</Rotation><ScaleFactor>1</ScaleFactor><isAutoScaleMode>false</isAutoScaleMode><ColorFore>#000000</ColorFore><ColorBack>#ffffff</ColorBack><ColorText>#000000</ColorText><BackStyle>1</BackStyle><QuietZoneUnit>0</QuietZoneUnit><QuietZoneLeft>0</QuietZoneLeft><QuietZoneTop>0</QuietZoneTop><QuietZoneRight>0</QuietZoneRight><QuietZoneBottom>0</QuietZoneBottom><EncodingMode>0</EncodingMode><CodePage>1</CodePage><CodePageCustom>1252</CodePageCustom><DrawMode>0</DrawMode><ImageFileName></ImageFileName><data><objectName></objectName><Data>0000000000004</Data><DataComposite></DataComposite><DataAsHex>false</DataAsHex><ShallShowDefault>false</ShallShowDefault><DataFormat>0</DataFormat></data><aztec><objectName></objectName><Format>0</Format><FormatSpec></FormatSpec><Size>0</Size><EnforceBinary>false</EnforceBinary><Runes>false</Runes><ErrorCorrection>-1</ErrorCorrection><StructuredAppend>false</StructuredAppend><SymbolIndex>A</SymbolIndex><SymbolsCount>A</SymbolsCount><MessageId></MessageId></aztec><codablockf><objectName></objectName><Format>0</Format><Rows>-1</Rows><Columns>-1</Columns><RowHeight>-1</RowHeight><SeparatorHeight>-1</SeparatorHeight></codablockf><composite><objectName></objectName><BCType>20</BCType><Composite>0</Composite><SegmentsPerRow>-1</SegmentsPerRow></composite><datamatrix><objectName></objectName><Format>0</Format><Size>0</Size><EnforceBinary>false</EnforceBinary><ShowAsRectangle>false</ShowAsRectangle><StructuredAppend>false</StructuredAppend><SymbolsCount>-1</SymbolsCount><SymbolIndex>-1</SymbolIndex><FileId>-1</FileId></datamatrix><maxicode><objectName></objectName><Mode>4</Mode><UnderCut>-1</UnderCut><Preamble>false</Preamble><PreambleValue>-1</PreambleValue><ServiceClass>-1</ServiceClass><CountryCode>-1</CountryCode><PostalCode></PostalCode><StructuredAppend>false</StructuredAppend><SymbolsCount>-1</SymbolsCount><SymbolIndex>-1</SymbolIndex></maxicode><pdf417><objectName></objectName><BCType>20</BCType><Mode>0</Mode><Rows>-1</Rows><Columns>-1</Columns><RowHeight>-1</RowHeight><ErrorCorrection>-1</ErrorCorrection><ModeMicro>0</ModeMicro><SizeMicro>0</SizeMicro><MacroPdf>false</MacroPdf><SegmentIndex>-1</SegmentIndex><LastSymbol>false</LastSymbol><FileId></FileId><FileName></FileName><SegmentCount>-1</SegmentCount><TimeStamp>-1</TimeStamp><Sender></Sender><Addressee></Addressee><FileSize>-1</FileSize><CheckSum>-1</CheckSum></pdf417><qrcode><objectName></objectName><BCType>20</BCType><ErrorCorrection>1</ErrorCorrection><KanjiCompaction>-1</KanjiCompaction><Format>0</Format><AppIndicator></AppIndicator><Size>0</Size><Mask>-1</Mask><StructuredAppend>false</StructuredAppend><SymbolsCount>-1</SymbolsCount><SymbolIndex>-1</SymbolIndex><Parity>0</Parity></qrcode><microqrcode><objectName></objectName><BCType>20</BCType><ErrorCorrection>1</ErrorCorrection><KanjiCompaction>-1</KanjiCompaction><Size>0</Size><Mask>-1</Mask></microqrcode><logo_effects><objectName></objectName><isShownImage>false</isShownImage><ImageFile></ImageFile><shallStretchLogo>false</shallStretchLogo><Alignment>4</Alignment><Unit>2</Unit><OffsetHorizontal>0</OffsetHorizontal><OffsetVertical>0</OffsetVertical><Width>99999.9</Width><Height>nan</Height><isAspectRatioLocked>true</isAspectRatioLocked><DisplayMode>0</DisplayMode><CompositionMode>0</CompositionMode><TransparencyImage>0</TransparencyImage><shallUseTransparentColor>false</shallUseTransparentColor><ColorTransparency>#000000</ColorTransparency></logo_effects><extratexts><extratext><objectName></objectName><Visible>true</Visible><Text>ad4</Text><Font>MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0</Font><Align>3</Align><Distance>0</Distance><Position>0</Position></extratext><extratext><objectName></objectName><Visible>true</Visible><Text>qiymet4</Text><Font>MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0</Font><Align>3</Align><Distance>0</Distance><Position>0</Position></extratext><extratext><objectName></objectName><Visible>false</Visible><Text></Text><Font>MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0</Font><Align>1</Align><Distance>1</Distance><Position>0</Position></extratext><extratext><objectName></objectName><Visible>false</Visible><Text></Text><Font>MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0</Font><Align>1</Align><Distance>0</Distance><Position>1</Position></extratext><extratext><objectName></objectName><Visible>false</Visible><Text></Text><Font>MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0</Font><Align>1</Align><Distance>0</Distance><Position>1</Position></extratext></extratexts></barcode><datalist>";

                bc_fayla_yazilan_setir += "<objectName></objectName><LockType>1</LockType><LockType>1</LockType>";

                bc_fayla_yazilan_setir += "<SortColumn>0</SortColumn><SortOrder>0</SortOrder>";




                bc_fayla_yazilan_setir += ("" + esas_datalist_setiri());

                bc_fayla_yazilan_setir += "</datalist><import><file><objectName></objectName><FileName></FileName><FieldSeparator>;</FieldSeparator><TextQualifier></TextQualifier><Encoding>0</Encoding><EscapeMethod>1</EscapeMethod><DateFormat>MM/dd/yyyy</DateFormat><TitlesInFirstRow>true</TitlesInFirstRow></file></import><serial><objectName></objectName><Start>1</Start><End>10</End><Increment>1</Increment><Format>$$$$$$</Format></serial><export><objectName></objectName><ExportPath>C:\\Users\\Yusif\\Desktop</ExportPath><ExportFilePrefix>bcs_</ExportFilePrefix><ExportImageType>0</ExportImageType><FileNameMethod>0</FileNameMethod><KeepNames>true</KeepNames><UrlEncoded>false</UrlEncoded><EpsWithPreview>false</EpsWithPreview><CountDigits>0</CountDigits><CheckData>true</CheckData></export><scanpay><objectName></objectName><BaseNumber>4051445</BaseNumber><ProductId>2</ProductId><CostId>0</CostId><UserNumber>999</UserNumber><CreditCard></CreditCard><TransactionId></TransactionId><Amount>47.11</Amount><ShowExtraText>true</ShowExtraText><Cache_0_Init>true</Cache_0_Init><Cache_0_Unit>2</Cache_0_Unit><Cache_0_Width>50</Cache_0_Width><Cache_0_Height>15</Cache_0_Height><Cache_0_Res>6</Cache_0_Res><Cache_0_ResCustom>-1</Cache_0_ResCustom><Cache_0_OptSize>true</Cache_0_OptSize><Cache_1_Init>true</Cache_1_Init><Cache_1_Unit>2</Cache_1_Unit><Cache_1_Width>50</Cache_1_Width><Cache_1_Height>15</Cache_1_Height><Cache_1_Res>6</Cache_1_Res><Cache_1_ResCustom>-1</Cache_1_ResCustom><Cache_1_OptSize>true</Cache_1_OptSize></scanpay><label><objectName></objectName><LabelTemplate></LabelTemplate><PrintOrder>0</PrintOrder><Orientation>2</Orientation><MarginLeft>8</MarginLeft><MarginTop>12</MarginTop><MarginRight>9</MarginRight><MarginBottom>11</MarginBottom><PageHeight>297.00000000014</PageHeight><PageWidth>210.000000000099</PageWidth><StartColumn>1</StartColumn><StartRow>1</StartRow><Unit>2</Unit><ColumnCount>4</ColumnCount><ColumnWidth>46.10</ColumnWidth><ColumnSpacing>3</ColumnSpacing><RowCount>13</RowCount><RowHeight>21.23</RowHeight><RowSpacing>0</RowSpacing><PreviewPagesMode>0</PreviewPagesMode><CheckBeforePrint>1</CheckBeforePrint></label></bcstudio>";
                string[] linalar = new string[1];
                linalar[0] = bc_fayla_yazilan_setir;

                System.IO.File.WriteAllLines(@"C:\hhmdxeht\MagazaProqramiDEA\kodsuz_mallar.bc", linalar);


            }
            catch (Exception xeta) { Baza.msg("Admin:yukle_duymesi_Click\n\n" + xeta.ToString()); }
            finally { }
        }
        //hazir 
        private void mallarin_siyahisi_listbox_SelectedIndexChanged(object sender, EventArgs e)
        {
            int indeks = mallarin_siyahisi_listbox.SelectedIndex;
            mallarin_kodlari_listbox.SelectedIndex = indeks;
        }
        //hazir 
        private void mallarin_kodlari_listbox_SelectedIndexChanged(object sender, EventArgs e)
        {
            int indeks = mallarin_kodlari_listbox.SelectedIndex;


            mallarin_siyahisi_listbox.SelectedIndex = indeks;
        }
        //hazir 
        //private void proqrami_sifirla_icra_et_button1_Click(object sender, EventArgs e)
        //{
        //    if (Baza.sifrem.Equals("2223"))
        //    {


        //        string sorgular = proqrami_sifirla_text_textBox1.Text;
        //        Baza.iud(sorgular);


        //    }
        //    else
        //    {





        //    }



        //}
        ////hazir 
        private void borclar_yeni_musteri_button_Click(object sender, EventArgs e)
        {
            string ad = borclar_yeni_musteri_textBox.Text.Trim();
            if (ad.Equals(""))
            {
                Baza.msg("Boş qoymaq olmaz");
            }
            else
            {
                if (Baza.cedvelde_serti_odeyen_setir_sayi("borclar", " where kime='" + ad + "'") == 1)
                {
                    Baza.msg("Bu artıq bazada var");
                }
                else
                {
                   
               
                     

                    string yeniFirmaAdi = ad;

                    
                        string yeniFirmaTelefonu = Microsoft.VisualBasic.Interaction.InputBox("Yeni firmanın telefonunu daxil edin", "Yeni firma telefonu", "");
                        string yeniFirmaSahibi = Microsoft.VisualBasic.Interaction.InputBox("Yeni firmanın sahibinin adını daxil edin", "Yeni firma sahibi", "");


                        string yeniFirmaNumayendesi = Microsoft.VisualBasic.Interaction.InputBox("Yeni firmanın nümayəndəsinin adını daxil edin", "Yeni firma nümayəndəsi", "");


                        bool ok=Baza.iud("insert into borclar (kime,tarix,tel,sahibi,numayende) values ('" + yeniFirmaAdi + "','" + Baza.indiki_tarix() + "','" + yeniFirmaTelefonu + "','" + yeniFirmaSahibi + "','" + yeniFirmaNumayendesi + "')");


                       

                        yenileBorclar(borclar_axtar_textBox2.Text.Trim().ToLower());

                     
                    if (ok)
                    {
                        Baza.msg("Uğurlu");
                    }
                    else
                    {
                        Baza.msg("Uğursuz");

                    }

                }

            }

        }
        //hazir 
        private void diger_baza_ile_elaqe_testi_button1_Click(object sender, EventArgs e)
        {


        }
        //hazir 
        private void yeni_proqramama_kecid_et_button1_Click(object sender, EventArgs e)
        {

            if (Baza.sifrem.Equals("2223"))
            {
                string[] lines = System.IO.File.ReadAllLines(@"C:\hhmdxeht\MagazaProqramiDEA\sorgular.txt");
                string sorgu = "";
                for (int i = 0; i < lines.Length; i++)
                {
                    sorgu += "" + lines[i];

                }

                Baza.iud(sorgu);
            }




        }
        //hazir 
        private void mallar_treeview_mallar_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                try
                {
                    mallar_tree_secildi();
                    mallar_dgv_esas.Focus();
                }
                catch { }





            }
        }
        //hazir 
        private void bonus_silinme_ok_button2_Click(object sender, EventArgs e)
        {
            string bas = abk_silinme_bas_dateTimePicker1.Value.ToString("yyyy-MM-dd HH:mm:ss");
            string son = abk_silinme_son_dateTimePicker1.Value.ToString("yyyy-MM-dd HH:mm:ss");


            hesabatdaABKOKDuymesi("abkop", bas, son);
        }
        //hazir 
        private void hesabatdaABKOKDuymesi(string cedvelAdi, string bas, string son)
        {
            string axtarSorgu = abk_silinme_axtar_textBox1.Text.Trim().ToLower();

            if (axtarSorgu.Equals(""))
            {


            }
            else
            {

                axtarSorgu = " and lower(ad) like '%" + axtarSorgu + "%'";
            }

            string
 sorgu = "select id as 'Kod',ad as Ad,abkbk as 'Bar Kod',caribonus as 'Silinən bonus',tarix as Tarix  from " + cedvelAdi + " where  tarix between '" + bas + "' and '" + son + "' " + axtarSorgu;


            abk_silinme_dgv.DataSource = Baza.verilmis_sorguya_gore_dataset_ver(sorgu);

            abk_silinme_dgv.DataMember = Baza.sTable;


        }

        private void daxil_dgv_ImeModeChanged(object sender, EventArgs e)
        {

        }
      
        //hazir 
        private void sazlamalar_mallar_silinmeli_ay_textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            Baza.intYazmagaIcaze(sender, e);
        }
        //ahzir 
        private void borclar_axtar_textBox2_KeyUp(object sender, KeyEventArgs e)
        {
            string ad = "" + borclar_axtar_textBox2.Text.Trim().ToLower();

            yenileBorclar(ad);
        }
        //hazir 
        private void borclar_ode_button1_Click(object sender, EventArgs e)
        {

            object secilen = borclar_listBox1.SelectedItem;

            if (secilen != null)
            {
                string secilenBorc = borclar_listBox1.SelectedItem.ToString();
                if (secilenBorc.Equals(""))
                {
                    Baza.msg("Seçim edilməyib");
                }
                else
                {
                    string borcS = borclar_borcumuzun_miqdari_textBox1.Text.Trim();
                    if (borcS.Equals(""))
                    {

                    }
                    else
                    {
                        Baza.iud("update borclar set borc ='" + borcS + "' where kime='" + secilenBorc + "'");
                    }


                }
            }
            else
            {
                Baza.msg("Seçim edilməyib");
            }

        }
        //hazir 
        private void borclar_listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            object secilen = borclar_listBox1.SelectedItem;

            if (secilen != null)
            {
                string secilenBorc = borclar_listBox1.SelectedItem.ToString();
                if (secilenBorc.Equals(""))
                {
                    Baza.msg("Seçim edilməyib");
                }
                else
                {

                    Baza.borcumuzunMiqdari = Baza.cedvelden_tek_double("borclar", "borc", "kime", secilenBorc, 4);
                    borclar_borcumuzun_miqdari_textBox1.Text = "" + Baza.borcumuzunMiqdari;

                }
            }
            else
            {
                Baza.msg("Seçim edilməyib");
            }

        }
        //hazir 
        private void borclar_borcumuzun_miqdari_textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            Baza.doubleYazmagaIcaze(sender,e);
        }

        private void kassada_silinen_mallar_tabPage1_Click(object sender, EventArgs e)
        {

        }
        //hazir 
        private void kassaad_silinen_ok_button2_Click(object sender, EventArgs e)
        {
            string bas = kassada_silinen_bas_dateTimePicker1.Value.ToString("yyyy-MM-dd HH:mm:ss");
            string son = kassada_silinen_son_dateTimePicker1.Value.ToString("yyyy-MM-dd HH:mm:ss");


            hesabatdaSilinenOKDuymesi("ksilinen", bas, son);
        }
        //hazir 
        private void hesabatdaSilinenOKDuymesi(string cedvelAdi, string bas, string son)
        {
            int kk = kassada_silinenler_kassalar_comboBox3.SelectedIndex;

            string kkSorgusu = "";

            if (kk == 0) { } else { kkSorgusu = " and kk = " + kk; }

          

            string
 sorgu = "select id as 'Kod',ad as Ad,bk as 'Bar Kod',sq as 'Satış qiyməti',mq as Miqdar,sqcem as 'Cəm satış qiyməti',tarix as Tarix,kassatarixi as 'Kassa Tarixi' from " + cedvelAdi + " where  tarix between '" + bas + "' and '" + son + "' "   + kkSorgusu  ;


            kassada_silinenler_dgv.DataSource = Baza.verilmis_sorguya_gore_dataset_ver(sorgu);

            kassada_silinenler_dgv.DataMember = Baza.sTable;
             
        }
        //hazir
        private void passiv_mallari_sil_button1_Click(object sender, EventArgs e)
        {
            sazlamalarMallarSilinmesi(1);


        }
        //hazir 
        private void sazlamalarMallarSilinmesi(int istiqamet)
        {
            string ayS = sazlamalar_mallar_silinmeli_ay_textBox1.Text.Trim();

            if (!ayS.Equals(""))
            {

                DateTime indiDateTime = DateTime.Now;

                int ay = Convert.ToInt32(ayS);

                if (ay == 0) { } else { indiDateTime = indiDateTime.AddMonths(-1 * (ay)); }



                string tarix = indiDateTime.ToString("yyyy-MM-dd HH:mm:ss",
                                         CultureInfo.InvariantCulture);


                HashSet<string> unikalBKLar = new HashSet<string>();


                List<string> bkLar = Baza.cedvelden_melumat_oxumaq_tek_sutun("satilanlararxiv", "bk", " where tarix>'" + tarix + "'");

                for (int i = 0; i < bkLar.Count; i++)
                {
                    unikalBKLar.Add(bkLar[i]);

                }

                string s = "";

                List<string> d = new List<string>();

                d.AddRange(unikalBKLar);

                for (int i = 0; i < d.Count; i++)
                {
                    s += "'" + d[i] + "',";

                }

                if (s.Length > 0) { s = s.Substring(0, s.Length - 1); }

                else { s = "''"; }

                if (istiqamet == 1)
                {
                    sazlamalar_mallar_dgv.DataSource = Baza.verilmis_sorguya_gore_dataset_ver("select id as Kod,ad as Ad,bk as 'Bar Kod',sq as 'Satış qiyməti',mq as 'Miqdar' from mallar where bk not in (" + s + ")");
                    sazlamalar_mallar_dgv.DataMember = Baza.sTable;
                }else
                if (istiqamet == 2)
                {
                    Baza.iud("delete from mallar where bk not in (" + s + ")");
                }else if (istiqamet == 3)
                {
                    string id =

                      sazlamalar_mallar_dgv.Rows[sazlamalar_mallar_dgv.SelectedCells[0].RowIndex].Cells[0].FormattedValue.ToString();
                    Baza.iud("delete from mallar where id =" + id + "");
                }

                  
            }
        }
        //hazir 
        private void sazlamalar_mallar_hamisini_sil_button1_Click(object sender, EventArgs e)
        {
            sazlamalarMallarSilinmesi(2);
        }
        //hazir 
        private void sazlamalar_mallar_birini_sil_button2_Click(object sender, EventArgs e)
        {
            sazlamalarMallarSilinmesi(3);
        }
        //hazir 
        private void sazlamalar_ktler_siyahini_yenile_button1_Click(object sender, EventArgs e)
        {
            sazlamalarKTYenile();

         
             
        }
        //hsxit 
        private void sazlamalarKTYenile()
        {
            List<string> ktLar = Baza.cedvelden_melumat_oxumaq_tek_sutun("malkt", "ad", " order by id asc");
            sazlamalar_ktler_listBox1.Items.Clear();
            for (int i = 0; i < ktLar.Count; i++)
            {
                sazlamalar_ktler_listBox1.Items.Add(ktLar[i]);
            }
            
        }
        //hazir 
        string sazlamalarSecilenKt = "";
        //hazir 
        private void sazlamalar_ktler_listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string secilenKT = "" + sazlamalar_ktler_listBox1.SelectedItem;
            sazlamalarSecilenKt = secilenKT;

            sazlamalar_ktler_adi_textBox1.Text = secilenKT;

        }
        //hazir 
        private void sazlamalar_ktler_adi_deyisdir_button1_Click(object sender, EventArgs e)
        {
            string yeniKT = sazlamalar_ktler_adi_textBox1.Text;

            string cariKT = sazlamalarSecilenKt;

            Baza.iud("update malkt set ad='" + yeniKT + "' where ad='" + cariKT + "'"); 
            
            sazlamalarKTYenile();
        }
        //hazir
        private void sazlamalar_ktler_yeni_kt_button1_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Əminsiniz?", Baza.adminAdi, MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                string yeniKTAd =  Microsoft.VisualBasic.Interaction.InputBox("Yeni kateqoriyanın adını daxil edin", "", "");

                long maxKT = Baza.cedveldeSutununMaksimumDeyeri("malkt","kt","")+1;

                string yeniTip = Microsoft.VisualBasic.Interaction.InputBox("1-Say ilə\n2-Uzunluq ilə\n3-Çəki ilə\n4-Dənə ilə", "Yeni kateqoriyanın tipini daxil edin", "1");

                string ktName = "kt-" + maxKT;

                Baza.iud("insert into malkt (ad,tip,kt,name) values ('"+yeniKTAd+"',"+yeniTip+","+maxKT+",'"+ktName+"')");
                List<string> ktLer = Baza.cedvelden_melumat_oxumaq_tek_sutun("malkt", "ad", " order by id asc");
                mallar_list_mallar.Items.Clear();

                for (int i = 0; i < ktLer.Count; i++)
                {
                    mallar_list_mallar.Items.Add(ktLer[i]);
                  
                }
                
            }
        }
        //hazir 
        private void mallar_list_mallar_SelectedIndexChanged(object sender, EventArgs e)
        {
            
                try
                {
                    mallar_tree_secildi();
                    mallar_dgv_esas.Focus();
                }
                catch { }
             
        }
        //hazir 
        private void malin_qaytarilmasi_qaytar_button1_Click(object sender, EventArgs e)
        {
            string bk = malin_qaytarilmasi_bar_kod_textBox1.Text.Trim();
            string mqS=malin_qaytarilmasi_miqdar_textBox2.Text.Trim();

           

            bool bkVar = Baza.cedvelde_serti_odeyen_setir_sayi("mallar"," where bk='"+bk+"'")==1;
            
            if (bkVar && !(mqS.Equals("")))
            {
 double mq = Convert.ToDouble(mqS);


 bool ok=Baza.qaytarilanMaliBazadanAzalt(bk,mq);
 if (ok)
 {
     string ad = Baza.cedvelden_tek_setir("mallar","ad","bk",bk);
     Baza.iud("insert into adminqaytarilanmallar (ad,bk,mq,tarix,tip,kt) values ('"+ad+"','"+bk+"','"+mq+"','"+Baza.indiki_tarix()+"',"+Baza.cedvelden_tek_int("mallar","tip","bk",bk)+","+Baza.cedvelden_tek_int("mallar","kt","bk",bk)+")");
     Baza.msg("Uğurlu");
 }
 else
 {
     Baza.msg("Uğursuz");

 }
            }
            else
            {

                Baza.msg("Bu bar kod bazada yoxdur");
            }


        }
        //hazir 
        private void malin_qaytarilmasi_bar_kod_textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            Baza.intYazmagaIcaze(sender,e);
        }
        //hazir 
        private void malin_qaytarilmasi_miqdar_textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            Baza.doubleYazmagaIcaze(sender,e);
        }
        //hazor
        private void mallar_qaytar_button1_Click(object sender, EventArgs e)
        {
            esas_tabControl1.SelectedIndex = 6;
            diger_esas_tabControl1.SelectedIndex = 5;
            malin_qaytarilmasi_miqdar_textBox2.Focus();
            malin_qaytarilmasi_bar_kod_textBox1.Text = axtarilan_malin_kodu_mallar_qlobal;
        }
        //hazir 
        private void hesabat_qaytar_ok_button2_Click(object sender, EventArgs e)
        {
            string bas = hesabat_qaytar_bas_dateTimePicker1.Value.ToString("yyyy-MM-dd HH:mm:ss");
            string son = hesabat_qaytar_son_dateTimePicker1.Value.ToString("yyyy-MM-dd HH:mm:ss");
             
            int tip = hesabat_qaytar_mal_tipleri_comboBox3.SelectedIndex;

            string tipSorgusu = "";

            if (tip == 0)
            {

            }
            else { tipSorgusu = " and tip = " + tip; }
             
            int kt = hesabat_qaytar_mal_ktleri_comboBox3.SelectedIndex;

            string ktSorgusu = "";

            if (kt == 0)
            {

            }
            else { ktSorgusu = " and kt = " + kt; }

             
            string axtarSorgu = hesabat_qaytar_axtar_txt.Text.Trim().ToLower();

            if (axtarSorgu.Equals(""))
            { 
            }
            else
            {

                axtarSorgu = " and lower(ad) like '%" + axtarSorgu + "%'";
            }
             
            string
 sorgu = "select id as 'Kod',ad as Ad,bk as 'Bar Kod',mq as Miqdar,tarix as Tarix  from  adminqaytarilanmallar where  tarix between '" + bas + "' and '" + son + "' " +   tipSorgusu + ktSorgusu   + axtarSorgu;


            hes_malin_qayt_dgv.DataSource = Baza.verilmis_sorguya_gore_dataset_ver(sorgu);

            hes_malin_qayt_dgv.DataMember = Baza.sTable;

            int setirSayi = hes_malin_qayt_dgv.RowCount;

            hesabat_qaytar_umumi_say_label30.Text = "" + setirSayi;
              
        }
        //hazir 
        private void malin_qaytarilmasi_bar_kod_textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                malin_qaytarilmasi_miqdar_textBox2.Focus();


            }
        }
        //hazir 
        private void malin_qaytarilmasi_miqdar_textBox2_KeyUp(object sender, KeyEventArgs e)
        {
            string mqS = malin_qaytarilmasi_miqdar_textBox2.Text.Trim();
            if (!mqS.Equals(""))
            {
                double mq = Convert.ToDouble(mqS);
                string bk = malin_qaytarilmasi_bar_kod_textBox1.Text.Trim();
                if (!bk.Equals(""))
                {
                    double sq = Baza.cedvelden_tek_double("mallar", "sq", "bk", bk, 4);
                    double sqcem = sq * mq;
                    malin_qaytarilmasi_sq_label37.Text = "" + sq;
                    malin_qaytarilmasi_sqcem_label37.Text = "" + sqcem;
                }  
            }
          }

        private void tableLayoutPanel2_Paint(object sender, PaintEventArgs e)
        {

        }
        //hazir 
        private void getirilen_mallarin_umumi_siyahisi_d_g_v_MouseClick(object sender, MouseEventArgs e)
        {
            string secilenTarix = getirilen_mallarin_umumi_siyahisi_d_g_v.Rows[getirilen_mallarin_umumi_siyahisi_d_g_v.SelectedCells[0].RowIndex].Cells[0].FormattedValue.ToString();
            if (secilenTarix != null)
            {
                if (!secilenTarix.Equals(""))
                {

                    Baza.iud("drop view gmv1");
                    Baza.iud("CREATE VIEW gmv1 AS      (select         mallargetirilenarxiv.id AS id,        mallargetirilenarxiv.ad AS ad,        mallargetirilenarxiv.bk AS bk,        mallargetirilenarxiv.tarix AS tarix,        mallargetirilenarxiv.mq AS mq,        mallargetirilenarxiv.md AS md,        mallargetirilenarxiv.mdcem AS mdcem,        mallargetirilenarxiv.sq AS sq,        mallargetirilenarxiv.sqcem AS sqcem,        mallargetirilenarxiv.tip AS tip,        mallargetirilenarxiv.kt AS kt    from      mallargetirilenarxiv    where tarix ='" + secilenTarix + "') ");
                    this.gmv2TableAdapter.Fill(this.mpdeaDataSet.gmv2);
                    getirilenMallarinSutunOlculeriniTeyinEt();
                }
            }

        }
        // hazir 
        private void rm_ok_button2_Click(object sender, EventArgs e)
        {
            realMallardaOKDuymesineBasildi();

        }
        // hazir 
        private void realMallardaOKDuymesineBasildi()
        {


            int tip = mal_tipleri_combobox_rm.SelectedIndex;

            string tipSorgusu = "";

            if (tip == 0)
            {

            }
            else { tipSorgusu = " and tip = " + tip; }

             

            int kt = mal_ktleri_combobox_rm.SelectedIndex;

            string ktSorgusu = "";

            if (kt == 0)
            {

            }
            else { ktSorgusu = " and kt = " + kt; }

             
            string axtarSorgu = axtar_text_rm.Text.Trim().ToLower();

            if (axtarSorgu.Equals(""))
            {


            }
            else
            {

                axtarSorgu = " and lower(ad) like '%" + axtarSorgu + "%'";
            }
            
            string
 sorgu = "select id as 'Kod',ad as Ad,bk as 'Bar Kod',mq as Miqdar, sq as 'Satış qiyməti',md as 'Maya dəyəri',plukodu as 'Plu' from mallar where id>0 "+   tipSorgusu + ktSorgusu  + axtarSorgu;


            rm_dgv.DataSource = Baza.verilmis_sorguya_gore_dataset_ver(sorgu);

            rm_dgv.DataMember = Baza.sTable;

            int setirSayi = rm_dgv.RowCount;

            rm_say_label42.Text = "" + setirSayi;

            double cemMq = 0; double cemSq = 0; double cemMd = 0; double cemGelir = 0;

            for (int i = 0; i < setirSayi; i++)
            {
                double mq = Convert.ToDouble( rm_dgv.Rows[i].Cells[3].Value.ToString());
                double sq = Convert.ToDouble(rm_dgv.Rows[i].Cells[4].Value.ToString());
                double md = Convert.ToDouble(rm_dgv.Rows[i].Cells[5].Value.ToString());


                sq *= mq;
                cemSq += sq;

                md *= mq;
                cemMd += md;

                double gelir = sq - md;
                cemGelir += gelir;
                cemMq += mq;

            }

            cemMq = Math.Round(cemMq,3);
            cemSq = Math.Round(cemSq,2);
            cemMd = Math.Round(cemMd, 2);
            cemGelir = Math.Round(cemGelir, 2);

            rm_cem_mq__label42.Text = "" + cemMq;
            rm_cem_sq_label42.Text = "" + cemSq;
            rm_cem_md_label42.Text = "" + cemMd;
            rm_cem_gelir_label42.Text = "" + cemGelir;

          
        }
        //hazir 
        private void esas_tabControl1_MouseClick(object sender, MouseEventArgs e)
        {
            if (esas_tabControl1.SelectedIndex == 3)
            {
                hesabat_tabControl1.Visible = false;
 bool   icazeVar=false;
                string parol =  Microsoft.VisualBasic.Interaction.InputBox("", "", "");

                if (parol.Equals(Baza.cedvelden_tek_setir("info", "daxili", "ad", "hesabat-sifre")))
                {
                    icazeVar = true;

                }
            

                if(icazeVar)
                hesabat_tabControl1.Visible = true;
                else hesabat_tabControl1.Visible = false;
            }
        }




     


        //hazir 
        private void button2_Click(object sender, EventArgs e)
        {
            string bas = hes_brlar_bas_dateTimePicker.Value.ToString("yyyy-MM-dd HH:mm:ss");
            string son = hes_brlar_son_dateTimePicker.Value.ToString("yyyy-MM-dd HH:mm:ss");


            hesabatdaBorclulardaOKDuymesi("brlarop", bas, son);
        }

        //hazir 
        private void hesabatdaBorclulardaOKDuymesi(string cedvelAdi, string bas, string son)
        {
            int kk = brlar_combobox_hesabat.SelectedIndex;

            string kkSorgusu = "";

            if (kk == 0) { } else { kkSorgusu = " and kk = " + kk; }
             
            int tipBorc = hes_brclar_borc_tipi_comboBox2.SelectedIndex;

            string tipBorcSorgusu = "";

            if (tipBorc == 0) { }

            else if (tipBorc == 1) { tipBorcSorgusu = " and pul>0 "; }
            else
            {
                tipBorcSorgusu = " and pul<0 ";
            }


            string axtarSorgu = hes_brlar_axtar_textBox.Text.Trim().ToLower();

            if (axtarSorgu.Equals(""))
            {


            }
            else
            {

                axtarSorgu = " and lower(musteri) like '%" + axtarSorgu + "%'";
            }

            string
 sorgu = "select id as 'Kod',musteri as Müştəri,pul as Məbləğ,tarix as Tarix,kk as 'Kassa'  from " + cedvelAdi + " where  tarix between '" + bas + "' and '" + son + "' " + tipBorcSorgusu + kkSorgusu + axtarSorgu;


            hes_brlar_dgv.DataSource = Baza.verilmis_sorguya_gore_dataset_ver(sorgu);

            hes_brlar_dgv.DataMember = Baza.sTable;

            int setirSayi = hes_brlar_dgv.RowCount;

            umumi_say_label_aktiv_hes_brlar.Text = "" + setirSayi;

            double meblegCem = 0;

            for (int i = 0; i < setirSayi; i++)
            {
                double mebleg = Convert.ToDouble(hes_brlar_dgv.Rows[i].Cells[2].Value.ToString());


                meblegCem += mebleg;

            } meblegCem = Math.Round(meblegCem, 2);


            cem_mebleg_label_aktiv_hes_brlar.Text = "" + meblegCem;

        }

        private void balansa_medaxil_button1_Click(object sender, EventArgs e)
        {
            BalansaMedaxilMexaric balans = new BalansaMedaxilMexaric(1);
            balans.Show();
        }
        public static void balansiYenile()
        {
 double cariBalans = Baza.cedvelden_tek_double("info", "daxili", "ad", "balans_miqdari", 4);
          
            Admin.cariBalans = cariBalans;
        }
        static double cariBalans = 0;
        private void balansi_yenile_button1_Click(object sender, EventArgs e)
        {
            balansiYenile();

            balans_firma_adlari_comboBox1.Items.Clear(); balans_firma_adlari_comboBox1.Items.Add("Firmalar");
            foreach (string s in Baza.cedvelden_melumat_oxumaq_tek_sutun("borclar", "kime", ""))
            {
                balans_firma_adlari_comboBox1.Items.Add(s);
            } balans_firma_adlari_comboBox1.SelectedIndex = 0;



            magazanin_balansi_label50.Text = "" + Math.Round(cariBalans, 2);

            string bas = bas_dateTimePicker1.Value.ToString("yyyy-MM-dd HH:mm:ss");
            string son = son_dateTimePicker1.Value.ToString("yyyy-MM-dd HH:mm:ss");
            if (balans_bugun_checkBox1.Checked)
            {
                bas = Baza.indiki_tarix_date()+" 00:00:01";
                son = Baza.indiki_tarix_date() + " 23:59:59";
            }
            int medaxilTipi = balans_medaxil_tipi_comboBox1.SelectedIndex;
            string medaxilTipiSorgusu = "";
            if (medaxilTipi == 0) { }
            else if (medaxilTipi == 1) { medaxilTipiSorgusu = " and tip=1"; }
            else if (medaxilTipi == 2)
            {
                medaxilTipiSorgusu = " and tip=0"; 

            }
            string sorgu = "select  tarix as Tarix,mebleg as Məbləğ,qeyd as Qeyd,firma as Firma  from balansemeliyyatlari   where  tarix between '" + bas + "' and '" + son + "' " + medaxilTipiSorgusu;


            balans_emeliyyatlar_dgv.DataSource = Baza.verilmis_sorguya_gore_dataset_ver(sorgu);

            balans_emeliyyatlar_dgv.DataMember = Baza.sTable;

            int setirSayi = balans_emeliyyatlar_dgv.RowCount;

            balans_emeliyyatlari_setir_sayi_label58.Text = "" + setirSayi;

            double cemMebleg = 0;

            for (int i = 0; i < setirSayi; i++)
            {
                double mebleg = Convert.ToDouble(balans_emeliyyatlar_dgv.Rows[i].Cells[1].Value.ToString());


                cemMebleg += mebleg;

            } cemMebleg = Math.Round(cemMebleg, 2);
            balans_emeliyyatlari_cem_pul_label58.Text = "" + cemMebleg;

        }

        private void balansa_mexaric_button1_Click(object sender, EventArgs e)
        {
            BalansaMedaxilMexaric balans = new BalansaMedaxilMexaric(0);
            balans.Show();
        }

        private void balans_yeni_firma_button1_Click(object sender, EventArgs e)
        {
            string yeniFirmaAdi = Microsoft.VisualBasic.Interaction.InputBox("Yeni firmanın adını daxil edin", "Yeni firma", "");

            if (yeniFirmaAdi.Trim().Equals("")) { }
            else
            {
                string yeniFirmaTelefonu = Microsoft.VisualBasic.Interaction.InputBox("Yeni firmanın telefonunu daxil edin", "Yeni firma telefonu", "");
                string yeniFirmaSahibi = Microsoft.VisualBasic.Interaction.InputBox("Yeni firmanın sahibinin adını daxil edin", "Yeni firma sahibi", "");


                string yeniFirmaNumayendesi = Microsoft.VisualBasic.Interaction.InputBox("Yeni firmanın nümayəndəsinin adını daxil edin", "Yeni firma nümayəndəsi", "");


                Baza.iud("insert into borclar (kime,tarix,tel,sahibi,numayende) values ('" + yeniFirmaAdi + "','"+Baza.indiki_tarix()+"','" + yeniFirmaTelefonu + "','" + yeniFirmaSahibi + "','" + yeniFirmaNumayendesi + "')");


                balans_firma_adlari_comboBox1.Items.Add(yeniFirmaAdi);
            }
        }

        private void txtkasasayi_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!char.IsDigit(ch) && ch != 8 && ch != 46)
            {
                e.Handled = true;
                int a = Convert.ToInt32(txtkasasayi.Text);
                Baza.iud("UPDATE info  SET daxili= '" + a + "' where ad = 'kassa-sayi';");

                MessageBox.Show("kassa sayi" + "-" + a );
                MessageBox.Show("salam");
            }
        }
    }
}
