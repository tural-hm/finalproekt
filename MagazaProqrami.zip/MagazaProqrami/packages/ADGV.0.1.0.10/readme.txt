﻿Advanced DataGridView
A .NET WinForm DataGridView with Excel-Like auto-filter context menu.

Web:     http://adgv.codeplex.com
NuGet:	 ADGV (PM> Install-Package ADGV)
License: Microsoft Public License

Copyright (c), 2013 Zuby <zuby@me.com>


