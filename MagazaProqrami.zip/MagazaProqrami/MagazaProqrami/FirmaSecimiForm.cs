﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MagazaProqramiDEA
{
    public partial class FirmaSecimiForm : Form
    {
        string mallarinUmumiMayasi;
        public FirmaSecimiForm()
        {
            InitializeComponent();
        }
        public FirmaSecimiForm(string mallarinUmumiMayasi)
        {
            InitializeComponent();
            this.mallarinUmumiMayasi = mallarinUmumiMayasi;
        }

        private void FirmaSecimiForm_Load(object sender, EventArgs e)
        {
            List<string> firmalar = Baza.cedvelden_melumat_oxumaq_tek_sutun("borclar", "kime", " where aktiv=1   order by kime asc");


            firmalarin_siyahisi_listBox1.Items.Clear();


            foreach (string item in firmalar)
            {
                firmalarin_siyahisi_listBox1.Items.Add(item);
            } firmalarin_siyahisi_listBox1.SelectedIndex = 0;
        }public static string secilenFirmaAdiQlobal="";

        private void daxilEtDuymesiBasildi()
        {
            string firma = "" + firmalarin_siyahisi_listBox1.SelectedItem;
            secilenFirmaAdiQlobal = firma;
            Baza.iud("update borclar set borc=borc+" + mallarinUmumiMayasi + " where kime ='" + secilenFirmaAdiQlobal + "' ");
            this.Close();
        }

        private void firmalarin_siyahisi_listBox1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            daxilEtDuymesiBasildi();
        }

        private void firmalarin_siyahisi_listBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                daxilEtDuymesiBasildi();
            }
        }

        private void daxil_et_button1_Click(object sender, EventArgs e)
        {
           
                daxilEtDuymesiBasildi();
            
        }
    }
}
