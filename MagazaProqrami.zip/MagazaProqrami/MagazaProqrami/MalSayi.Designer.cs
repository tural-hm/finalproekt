﻿namespace MagazaProqramiDEA
{
    partial class MalSayi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MalSayi));
            this.malin_sayi_textBox1 = new System.Windows.Forms.TextBox();
            this.malin_qiymeti_textBox1 = new System.Windows.Forms.TextBox();
            this.ms_psv_label2 = new System.Windows.Forms.Label();
            this.mq_psv_label2 = new System.Windows.Forms.Label();
            this.tam_deneli_groupBox1 = new System.Windows.Forms.GroupBox();
            this.deneli_radioButton2 = new System.Windows.Forms.RadioButton();
            this.tam_radioButton1 = new System.Windows.Forms.RadioButton();
            this.basliq_label1 = new System.Windows.Forms.Label();
            this.esas_tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.esas_say_tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.saylar_tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.malSayi_endirim_faizi_label2 = new System.Windows.Forms.Label();
            this.malin_adi_aktiv_label1 = new System.Windows.Forms.Label();
            this.malin_qaliq_miqdari_label1 = new System.Windows.Forms.Label();
            this.tam_deneli_groupBox1.SuspendLayout();
            this.esas_tableLayoutPanel1.SuspendLayout();
            this.esas_say_tableLayoutPanel2.SuspendLayout();
            this.saylar_tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // malin_sayi_textBox1
            // 
            this.malin_sayi_textBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.malin_sayi_textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.malin_sayi_textBox1.Location = new System.Drawing.Point(357, 6);
            this.malin_sayi_textBox1.Margin = new System.Windows.Forms.Padding(6);
            this.malin_sayi_textBox1.Name = "malin_sayi_textBox1";
            this.malin_sayi_textBox1.Size = new System.Drawing.Size(340, 29);
            this.malin_sayi_textBox1.TabIndex = 7;
            this.malin_sayi_textBox1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.malin_sayi_textBox1_KeyDown);
            this.malin_sayi_textBox1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.malin_sayi_textBox1_KeyPress);
            this.malin_sayi_textBox1.KeyUp += new System.Windows.Forms.KeyEventHandler(this.malin_sayi_textBox1_KeyUp);
            // 
            // malin_qiymeti_textBox1
            // 
            this.malin_qiymeti_textBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.malin_qiymeti_textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.malin_qiymeti_textBox1.Location = new System.Drawing.Point(357, 53);
            this.malin_qiymeti_textBox1.Margin = new System.Windows.Forms.Padding(6);
            this.malin_qiymeti_textBox1.Name = "malin_qiymeti_textBox1";
            this.malin_qiymeti_textBox1.Size = new System.Drawing.Size(340, 29);
            this.malin_qiymeti_textBox1.TabIndex = 6;
            this.malin_qiymeti_textBox1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.malin_qiymeti_textBox1_KeyDown);
            this.malin_qiymeti_textBox1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.malin_qiymeti_textBox1_KeyPress);
            // 
            // ms_psv_label2
            // 
            this.ms_psv_label2.AutoSize = true;
            this.ms_psv_label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ms_psv_label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ms_psv_label2.Location = new System.Drawing.Point(3, 0);
            this.ms_psv_label2.Name = "ms_psv_label2";
            this.ms_psv_label2.Size = new System.Drawing.Size(345, 47);
            this.ms_psv_label2.TabIndex = 5;
            this.ms_psv_label2.Text = "Malın sayı:";
            this.ms_psv_label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // mq_psv_label2
            // 
            this.mq_psv_label2.AutoSize = true;
            this.mq_psv_label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mq_psv_label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mq_psv_label2.Location = new System.Drawing.Point(3, 47);
            this.mq_psv_label2.Name = "mq_psv_label2";
            this.mq_psv_label2.Size = new System.Drawing.Size(345, 47);
            this.mq_psv_label2.TabIndex = 4;
            this.mq_psv_label2.Text = "Malın qiyməti:";
            this.mq_psv_label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tam_deneli_groupBox1
            // 
            this.tam_deneli_groupBox1.Controls.Add(this.deneli_radioButton2);
            this.tam_deneli_groupBox1.Controls.Add(this.tam_radioButton1);
            this.tam_deneli_groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tam_deneli_groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tam_deneli_groupBox1.Location = new System.Drawing.Point(3, 153);
            this.tam_deneli_groupBox1.Name = "tam_deneli_groupBox1";
            this.tam_deneli_groupBox1.Size = new System.Drawing.Size(703, 69);
            this.tam_deneli_groupBox1.TabIndex = 8;
            this.tam_deneli_groupBox1.TabStop = false;
            this.tam_deneli_groupBox1.Text = "Dənəli malın satış tipi";
            // 
            // deneli_radioButton2
            // 
            this.deneli_radioButton2.AutoSize = true;
            this.deneli_radioButton2.Location = new System.Drawing.Point(212, 30);
            this.deneli_radioButton2.Name = "deneli_radioButton2";
            this.deneli_radioButton2.Size = new System.Drawing.Size(78, 24);
            this.deneli_radioButton2.TabIndex = 1;
            this.deneli_radioButton2.TabStop = true;
            this.deneli_radioButton2.Text = "Dənəli";
            this.deneli_radioButton2.UseVisualStyleBackColor = true;
            this.deneli_radioButton2.CheckedChanged += new System.EventHandler(this.deneli_radioButton2_CheckedChanged);
            // 
            // tam_radioButton1
            // 
            this.tam_radioButton1.AutoSize = true;
            this.tam_radioButton1.Location = new System.Drawing.Point(73, 30);
            this.tam_radioButton1.Name = "tam_radioButton1";
            this.tam_radioButton1.Size = new System.Drawing.Size(61, 24);
            this.tam_radioButton1.TabIndex = 0;
            this.tam_radioButton1.TabStop = true;
            this.tam_radioButton1.Text = "Tam";
            this.tam_radioButton1.UseVisualStyleBackColor = true;
            this.tam_radioButton1.CheckedChanged += new System.EventHandler(this.tam_radioButton1_CheckedChanged);
            // 
            // basliq_label1
            // 
            this.basliq_label1.AutoSize = true;
            this.basliq_label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.basliq_label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.basliq_label1.ForeColor = System.Drawing.Color.Red;
            this.basliq_label1.Location = new System.Drawing.Point(3, 100);
            this.basliq_label1.Name = "basliq_label1";
            this.basliq_label1.Size = new System.Drawing.Size(709, 50);
            this.basliq_label1.TabIndex = 9;
            this.basliq_label1.Text = "Say ilə olan malın satışı";
            this.basliq_label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // esas_tableLayoutPanel1
            // 
            this.esas_tableLayoutPanel1.ColumnCount = 1;
            this.esas_tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.esas_tableLayoutPanel1.Controls.Add(this.basliq_label1, 0, 2);
            this.esas_tableLayoutPanel1.Controls.Add(this.esas_say_tableLayoutPanel2, 0, 3);
            this.esas_tableLayoutPanel1.Controls.Add(this.malin_adi_aktiv_label1, 0, 1);
            this.esas_tableLayoutPanel1.Controls.Add(this.malin_qaliq_miqdari_label1, 0, 0);
            this.esas_tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.esas_tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.esas_tableLayoutPanel1.Name = "esas_tableLayoutPanel1";
            this.esas_tableLayoutPanel1.RowCount = 4;
            this.esas_tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.esas_tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.esas_tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.esas_tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.esas_tableLayoutPanel1.Size = new System.Drawing.Size(715, 381);
            this.esas_tableLayoutPanel1.TabIndex = 10;
            // 
            // esas_say_tableLayoutPanel2
            // 
            this.esas_say_tableLayoutPanel2.ColumnCount = 1;
            this.esas_say_tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.esas_say_tableLayoutPanel2.Controls.Add(this.saylar_tableLayoutPanel3, 0, 0);
            this.esas_say_tableLayoutPanel2.Controls.Add(this.tam_deneli_groupBox1, 0, 2);
            this.esas_say_tableLayoutPanel2.Controls.Add(this.tableLayoutPanel1, 0, 1);
            this.esas_say_tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.esas_say_tableLayoutPanel2.Location = new System.Drawing.Point(3, 153);
            this.esas_say_tableLayoutPanel2.Name = "esas_say_tableLayoutPanel2";
            this.esas_say_tableLayoutPanel2.RowCount = 3;
            this.esas_say_tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.esas_say_tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.esas_say_tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.esas_say_tableLayoutPanel2.Size = new System.Drawing.Size(709, 225);
            this.esas_say_tableLayoutPanel2.TabIndex = 10;
            // 
            // saylar_tableLayoutPanel3
            // 
            this.saylar_tableLayoutPanel3.ColumnCount = 2;
            this.saylar_tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.saylar_tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.saylar_tableLayoutPanel3.Controls.Add(this.ms_psv_label2, 0, 0);
            this.saylar_tableLayoutPanel3.Controls.Add(this.mq_psv_label2, 0, 1);
            this.saylar_tableLayoutPanel3.Controls.Add(this.malin_qiymeti_textBox1, 1, 1);
            this.saylar_tableLayoutPanel3.Controls.Add(this.malin_sayi_textBox1, 1, 0);
            this.saylar_tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.saylar_tableLayoutPanel3.Location = new System.Drawing.Point(3, 3);
            this.saylar_tableLayoutPanel3.Name = "saylar_tableLayoutPanel3";
            this.saylar_tableLayoutPanel3.RowCount = 2;
            this.saylar_tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.saylar_tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.saylar_tableLayoutPanel3.Size = new System.Drawing.Size(703, 94);
            this.saylar_tableLayoutPanel3.TabIndex = 0;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.malSayi_endirim_faizi_label2, 1, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(3, 103);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 44F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(703, 44);
            this.tableLayoutPanel1.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(345, 44);
            this.label1.TabIndex = 0;
            this.label1.Text = "Endirim faizi:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label1.Visible = false;
            // 
            // malSayi_endirim_faizi_label2
            // 
            this.malSayi_endirim_faizi_label2.AutoSize = true;
            this.malSayi_endirim_faizi_label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.malSayi_endirim_faizi_label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.malSayi_endirim_faizi_label2.ForeColor = System.Drawing.Color.Red;
            this.malSayi_endirim_faizi_label2.Location = new System.Drawing.Point(354, 0);
            this.malSayi_endirim_faizi_label2.Name = "malSayi_endirim_faizi_label2";
            this.malSayi_endirim_faizi_label2.Size = new System.Drawing.Size(346, 44);
            this.malSayi_endirim_faizi_label2.TabIndex = 1;
            this.malSayi_endirim_faizi_label2.Text = ":::";
            this.malSayi_endirim_faizi_label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.malSayi_endirim_faizi_label2.Visible = false;
            // 
            // malin_adi_aktiv_label1
            // 
            this.malin_adi_aktiv_label1.AutoSize = true;
            this.malin_adi_aktiv_label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.malin_adi_aktiv_label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.malin_adi_aktiv_label1.ForeColor = System.Drawing.Color.Blue;
            this.malin_adi_aktiv_label1.Location = new System.Drawing.Point(3, 50);
            this.malin_adi_aktiv_label1.Name = "malin_adi_aktiv_label1";
            this.malin_adi_aktiv_label1.Size = new System.Drawing.Size(709, 50);
            this.malin_adi_aktiv_label1.TabIndex = 11;
            this.malin_adi_aktiv_label1.Text = "Malın adı : ";
            this.malin_adi_aktiv_label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // malin_qaliq_miqdari_label1
            // 
            this.malin_qaliq_miqdari_label1.AutoSize = true;
            this.malin_qaliq_miqdari_label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.malin_qaliq_miqdari_label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.malin_qaliq_miqdari_label1.Location = new System.Drawing.Point(3, 0);
            this.malin_qaliq_miqdari_label1.Name = "malin_qaliq_miqdari_label1";
            this.malin_qaliq_miqdari_label1.Size = new System.Drawing.Size(709, 50);
            this.malin_qaliq_miqdari_label1.TabIndex = 12;
            this.malin_qaliq_miqdari_label1.Text = "Malın qalıq miqdarı : ";
            this.malin_qaliq_miqdari_label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // MalSayi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(715, 381);
            this.Controls.Add(this.esas_tableLayoutPanel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MalSayi";
            this.Text = "MalSayi";
            this.Load += new System.EventHandler(this.MalSayi_Load);
            this.tam_deneli_groupBox1.ResumeLayout(false);
            this.tam_deneli_groupBox1.PerformLayout();
            this.esas_tableLayoutPanel1.ResumeLayout(false);
            this.esas_tableLayoutPanel1.PerformLayout();
            this.esas_say_tableLayoutPanel2.ResumeLayout(false);
            this.saylar_tableLayoutPanel3.ResumeLayout(false);
            this.saylar_tableLayoutPanel3.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox malin_sayi_textBox1;
        private System.Windows.Forms.TextBox malin_qiymeti_textBox1;
        private System.Windows.Forms.Label ms_psv_label2;
        private System.Windows.Forms.Label mq_psv_label2;
        private System.Windows.Forms.GroupBox tam_deneli_groupBox1;
        private System.Windows.Forms.RadioButton deneli_radioButton2;
        private System.Windows.Forms.RadioButton tam_radioButton1;
        private System.Windows.Forms.Label basliq_label1;
        private System.Windows.Forms.TableLayoutPanel esas_tableLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel esas_say_tableLayoutPanel2;
        private System.Windows.Forms.TableLayoutPanel saylar_tableLayoutPanel3;
        private System.Windows.Forms.Label malin_adi_aktiv_label1;
        private System.Windows.Forms.Label malin_qaliq_miqdari_label1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label malSayi_endirim_faizi_label2;
    }
}