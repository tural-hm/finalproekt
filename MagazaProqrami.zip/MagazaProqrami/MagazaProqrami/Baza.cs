﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MagazaProqramiDEA
{
    class Baza
    {
        // hazirdir dyisenler 
        // bu deyisen proqramda mysql bazaya qosulmaq ucun setirdir
        public static string constr;
        // bu komputerde olan baza ucun parametrleri ozunde saxlayan txt faylin unvanini gosterir
        public static string udc_unvani = @"C:\hhmdxeht\MagazaProqramiDEA\udc.txt";
        //hazir
        public static string duzlerSifreUcun = "qwertyuiopasdfghjklzxcvbnm00una56789";
        public static string seflerSifreUcun = "vk6c5exqy9jizt7w1p8g4rs23ml0unabhodf";
        // // // // 
        public static int kassaSayi = 0;
        public static bool kassayaDaxilOlunub = false;
        public static string adminAdi = "";
        public static string sifrem = "";
        public static string magazaAdi = "";
        public static string magazaUnvani = "";

        public static string adminSifresi = "";
        public static string[] kassaSifreleri;
        public static int yeni_malin_tipi_qlobal, yeni_malin_mal_tipi_qlobal;
        public static string veb = "";
        public static string email = "";
        public static string mobil = "";
        public static string huquq = "";
        public static string bk_qlobal = "";
        public static int tipSatis = 0;
        public static int ekranEn, ekranHun;
        public static string sTable = "Portfolio";
        public static string srokTarixi;
        public static string indi, indiDate;
        public static double kassaCem = 0; public static double kassaCemEndirimli = 0;
        public static string getirilenMallarinCedvelAdi;
        public static string cariQovluqUnvani;
        private static string userNameQlobal;
        public static double borcumuzunMiqdari;

        //hazir 
        public static string indiki_tarix()
        {
            DateTime indi_tarix = DateTime.Now;
            string indi = indi_tarix.ToString("yyyy-MM-dd HH:mm:ss",
                                CultureInfo.InvariantCulture); return indi;
        }
        //hazir 
        public static void tarixleriYenile()
        {
            indi = indiki_tarix();
            indiDate = indiki_tarix_date();
        }
        //hazir 
        public static string indiki_tarix_date()
        {
            DateTime indi_tarix = DateTime.Now;
            string indi = indi_tarix.ToString("yyyy-MM-dd",
                              CultureInfo.InvariantCulture);
            return indi;
        }
        //hazir 
        public static bool cedvele_melumat_yazmaq(string cedvel_adi, string sutunlar, string yazilar)
        {
            bool ugurlu = false;
            try
            {
                iud("insert into " + cedvel_adi + " (" + sutunlar + ") values (" + yazilar + ");");
                ugurlu = true;
            }
            catch (Exception xeta)
            {
                ugurlu = false;
                Baza.msg("Baza:cedvele_melumat_yazmaq\n\n" + xeta.ToString());
            }
            return ugurlu;
        }

        //hazir 
        internal static bool yeni_mali_qeydiyyat_et(string ad, string bk, double md, double sq, double sqtek, int qutusayi, int tip, int kt, int plukodu)
        {
            bool ugurlu = false;
            try
            {
                string od = indiki_tarix();
                string ud = od;
                cedvele_melumat_yazmaq("mallar", "ad,bk,md,sq,od,ud,sqtek,plukodu,tip,kt,qutusayi", "'" + ad + "','" + bk + "','" + md + "','" + sq + "','" + od + "','" + ud + "','" + sqtek + "'," + plukodu + "," + tip + "," + kt + "," + qutusayi + "");
                if (kt == 10)
                {

                    cedvele_melumat_yazmaq("tmc", "name,hotkey,lfcode,code,barcode_type,unit_price,weight_unit,pcs_type,nomre,deptment,c10,c11,c12,c13,c14,c15,c16,c17,c18,c19,c20,c21", "'" +
                        ad + "',0," + plukodu +
                        ",'" + bk + "','07','" + (sq * 100) + "','4',22," + plukodu + ",0,'000','15','0','0','000','0','1','0','0','0','0','4'");
                }
                ugurlu = true;

            }
            catch (Exception xeta)
            {
                ugurlu = false;

                Baza.msg("Baza:yeni_mali_qeydiyyat_et\n\n" + xeta.ToString());
            }


            return ugurlu;

        }
        static string qlobalServerIP = "";
        //hazir
        public static void bazaniHazirla()
        {

            string[] lines = null;
            int sazlamaIstiqameti = 0;

            try
            {
                lines = System.IO.File.ReadAllLines(udc_unvani);
                sazlamaIstiqameti = Convert.ToInt32(lines[5]);

            }
            catch (Exception xeta) { msg("Baza:bazaniHazirla\n\n" + xeta.ToString()); }

            if (sazlamaIstiqameti == 0)
            {

                try
                {


                    string server = "localhost"; //string server = lines[0];
                    qlobalServerIP = server;
                    string port = lines[1];
                    string username = "root";
                    string sifre = lines[3];
                    string baza = lines[4];

                    sifre = "1234";// sifre = verilmisSozuQaytar(sifre);
                    string user = Environment.UserName.ToLower() + "";

                    Baza.userNameQlobal = user;

                    if (user.Equals("yusif") || user.Equals("dea")) { } else { sifre = "1234"; }

                    constr = "SERVER=" + server + ";" + "DATABASE=" +
                baza + ";" + "UID=" + username + ";" + "PASSWORD=" + sifre + ";";

                }
                catch (Exception xeta)
                {
                    msg("Baza:bazaniHazirla\n\n" + xeta.ToString());
                }


                Baza.cariQovluqUnvani = System.Windows.Forms.Application.StartupPath;

                if (userNameQlobal.Equals("yusif") || userNameQlobal.Equals("dea"))
                {
                    string server = "127.0.0.1";
                    string userId = "root";
                    string password = "1234";
                    string database = "mpdea";

                    bazaUcunKonfiqurasiyaFayliniYarat(server, userId, password, database);

                }
                else
                {

                    string server = qlobalServerIP
      ;
                    string userId = "root";
                    string password = "1234";
                    string database = "mpdea";

                    bazaUcunKonfiqurasiyaFayliniYarat(server, userId, password, database);


                }


                kassaSayi = Convert.ToInt32(cedvelden_tek_setir("info", "daxili", "ad", "kassa-sayi"));
                adminAdi = cedvelden_tek_setir("info", "daxili", "ad", "admin-adi");
                sifrem = cedvelden_tek_setir("info", "daxili", "ad", "sifrem");

                magazaAdi = cedvelden_tek_setir("info", "daxili", "ad", "magaza-adi");

                magazaUnvani = cedvelden_tek_setir("info", "daxili", "ad", "magaza-unvani");



                adminSifresi = cedvelden_tek_setir("info", "daxili", "ad", "admin-sifre");


                string kassaSifreleriString = cedvelden_tek_setir("info", "daxili", "ad", "kassa-sifre");

                kassaSifreleri = kassaSifreleriString.Split(',');



                veb = cedvelden_tek_setir("infocomp", "daxili", "ad", "veb");
                email = cedvelden_tek_setir("infocomp", "daxili", "ad", "email");

                mobil = cedvelden_tek_setir("infocomp", "daxili", "ad", "mobil");
                huquq = cedvelden_tek_setir("infocomp", "daxili", "ad", "huquq");


                System.Drawing.Rectangle olcu =
            Screen.PrimaryScreen.WorkingArea;
                ekranEn = olcu.Width;
                ekranHun = olcu.Height;
            }
            else
            {
                try
                {


                    string server = lines[6];
                    string port = lines[7];
                    string username = lines[8];
                    string sifre = lines[9];
                    string baza = lines[10];


                    string user = Environment.UserName.ToLower() + "";

                    Baza.userNameQlobal = user;


                    constr = "SERVER=" + server + ";" + "DATABASE=" +
                baza + ";" + "UID=" + username + ";" + "PASSWORD=" + sifre + ";";

                }
                catch (Exception xeta)
                {
                    msg("Baza:bazaniHazirla\n\n" + xeta.ToString());
                }


                Baza.cariQovluqUnvani = System.Windows.Forms.Application.StartupPath;

                bazaUcunKonfiqurasiyaFayliniYarat("127.0.0.1", "root", "0una", "mpdea");




                kassaSayi = Convert.ToInt32(cedvelden_tek_setir("info", "daxili", "ad", "kassa-sayi"));
                adminAdi = cedvelden_tek_setir("info", "daxili", "ad", "admin-adi");
                sifrem = cedvelden_tek_setir("info", "daxili", "ad", "sifrem");

                magazaAdi = cedvelden_tek_setir("info", "daxili", "ad", "magaza-adi");

                magazaUnvani = cedvelden_tek_setir("info", "daxili", "ad", "magaza-unvani");



                adminSifresi = cedvelden_tek_setir("info", "daxili", "ad", "admin-sifre");


                string kassaSifreleriString = cedvelden_tek_setir("info", "daxili", "ad", "kassa-sifre");

                kassaSifreleri = kassaSifreleriString.Split(',');



                veb = cedvelden_tek_setir("infocomp", "daxili", "ad", "veb");
                email = cedvelden_tek_setir("infocomp", "daxili", "ad", "email");

                mobil = cedvelden_tek_setir("infocomp", "daxili", "ad", "mobil");
                huquq = cedvelden_tek_setir("infocomp", "daxili", "ad", "huquq");


                System.Drawing.Rectangle olcu =
            Screen.PrimaryScreen.WorkingArea;
                ekranEn = olcu.Width;
                ekranHun = olcu.Height;
            }



        }
        //hazir
        private static void bazaUcunKonfiqurasiyaFayliniYarat(string server, string userId, string password, string database)
        {

            FileStream yazan1 = new FileStream(cariQovluqUnvani + "\\MagazaProqramiDEA.exe.config", FileMode.OpenOrCreate, FileAccess.Write);

            StreamWriter yazici1 = new StreamWriter(yazan1);
            yazici1.WriteLine("<?xml version=\"1.0\" encoding=\"utf-8\"?>");
            yazici1.WriteLine("<configuration>");
            yazici1.WriteLine("    <configSections>");
            yazici1.WriteLine("    </configSections>");
            yazici1.WriteLine("    <connectionStrings>");
            yazici1.WriteLine("        <add name=\"MagazaProqramiDEA.Properties.Settings.mpdeaconstr\"");
            yazici1.WriteLine("            connectionString=\"server=" + server + ";user id=" + userId + ";password=" + password + ";persistsecurityinfo=True;database=" + database + "\"");
            yazici1.WriteLine("            providerName=\"MySql.Data.MySqlClient\" />");
            yazici1.WriteLine("    </connectionStrings>");
            yazici1.WriteLine("    <startup> ");
            yazici1.WriteLine("        <supportedRuntime version=\"v4.0\" sku=\".NETFramework,Version=v4.0\"/>");
            yazici1.WriteLine("    </startup>");
            yazici1.WriteLine("</configuration>");

            yazici1.Close();

            FileStream yazan2 = new FileStream(cariQovluqUnvani + "\\MagazaProqramiDEA.vshost.exe.config", FileMode.OpenOrCreate, FileAccess.Write);

            StreamWriter yazici2 = new StreamWriter(yazan2);
            yazici2.WriteLine("<?xml version=\"1.0\" encoding=\"utf-8\"?>");
            yazici2.WriteLine("<configuration>");
            yazici2.WriteLine("    <configSections>");
            yazici2.WriteLine("    </configSections>");
            yazici2.WriteLine("    <connectionStrings>");
            yazici2.WriteLine("        <add name=\"MagazaProqramiDEA.Properties.Settings.mpdeaconstr\"");
            yazici2.WriteLine("            connectionString=\"server=" + server + ";user id=" + userId + ";password=" + password + ";persistsecurityinfo=True;database=" + database + "\"");
            yazici2.WriteLine("            providerName=\"MySql.Data.MySqlClient\" />");
            yazici2.WriteLine("    </connectionStrings>");
            yazici2.WriteLine("    <startup> ");
            yazici2.WriteLine("        <supportedRuntime version=\"v4.0\" sku=\".NETFramework,Version=v4.0\"/>");
            yazici2.WriteLine("    </startup>");
            yazici2.WriteLine("</configuration>");


            yazici2.Close();

        }
        //hazir
        public static void msg(string gelenMesaj)
        {
            MessageBox.Show(gelenMesaj);

        }
        //hazir
        public static void msg(string gelenMesaj, string basliq)
        {
            MessageBox.Show(gelenMesaj, basliq);

        }
        //hazir
        public static string verilmisSozuCevir(string duz)
        {
            string cevrilmis = "";

            for (int i = 0; i < duz.Length; i++)
            {
                string herf = duz.Substring(i, 1);
                int indeksi = duzlerSifreUcun.IndexOf(herf);
                string sefHerf = seflerSifreUcun.Substring(indeksi, 1);
                cevrilmis += "" + sefHerf;
            }

            return cevrilmis;

        }
        //hazir
        public static string verilmisSozuQaytar(string cevrilmis)
        {
            string duz = "";

            for (int i = 0; i < cevrilmis.Length; i++)
            {
                string sefHerf = cevrilmis.Substring(i, 1);
                int indeksi = seflerSifreUcun.IndexOf(sefHerf);
                string herf = duzlerSifreUcun.Substring(indeksi, 1);
                duz += "" + herf;
            }

            return duz;

        }
        //hazirdir
        public static string cedvelden_tek_setir(string cedvel_adi, string sutun_adi, string sert_sutunu, string sert_sutun_yazisi)
        {
            string netice = "";
            MySqlConnection qosulma = null;
            string sorgu = "select " + sutun_adi + " from " + cedvel_adi + " where " + sert_sutunu + "='" + sert_sutun_yazisi + "'";
            try
            {
                qosulma = new MySqlConnection(constr);
                qosulma.Open();
                MySqlCommand cmd = new MySqlCommand(sorgu, qosulma);

                MySqlDataReader dataReader = cmd.ExecuteReader();
                dataReader.Read();

                netice = "" + dataReader["" + sutun_adi + ""];

                dataReader.Close();

            }
            catch (Exception xeta)
            {

                Baza.msg("Baza:cedvelden_tek_setir\n\n" + xeta.ToString());
            }
            finally
            {
                qosulma.Close();

            }
            return netice;
        }

        //hazirdir
        public static int cedvelden_tek_int(string cedvel_adi, string sutun_adi, string sert_sutunu, string sert_sutun_yazisi)
        {
            int netice = 0;

            MySqlConnection qosulma = null;

            string sorgu = "select " + sutun_adi + " from " + cedvel_adi + " where " + sert_sutunu + "='" + sert_sutun_yazisi + "'";

            try
            {
                qosulma = new MySqlConnection(constr);
                qosulma.Open();
                MySqlCommand cmd = new MySqlCommand(sorgu, qosulma);

                MySqlDataReader dataReader = cmd.ExecuteReader();
                dataReader.Read();

                netice = Convert.ToInt32("" + dataReader["" + sutun_adi + ""]);

                dataReader.Close();

            }
            catch (Exception xeta)
            {

                Baza.msg("Baza:cedvelden_tek_int\n\n" + xeta.ToString());
            }
            finally
            {
                qosulma.Close();

            }
            return netice;
        }


        //hazirdir
        public static int cedvelden_tek_int_shertli(string cedvel_adi, string sutun_adi, string sert)
        {
            int netice = 0;
            MySqlConnection qosulma = null;
            string sorgu = "select " + sutun_adi + " from " + cedvel_adi + "  " + sert;

            try
            {
                qosulma = new MySqlConnection(constr);
                qosulma.Open();
                MySqlCommand cmd = new MySqlCommand(sorgu, qosulma);

                MySqlDataReader dataReader = cmd.ExecuteReader();
                dataReader.Read();

                netice = Convert.ToInt32("" + dataReader["" + sutun_adi + ""]);

                dataReader.Close();
            }
            catch (Exception xeta)
            {
                Baza.msg("Baza:cedvelden_tek_int_shertli\n\n" + xeta.ToString());
            }
            finally
            {
                qosulma.Close();

            }
            return netice;
        }


        //hazirdir
        public static double cedvelden_tek_double(string cedvel_adi, string sutun_adi, string sert_sutunu, string sert_sutun_yazisi, int dp)
        {
            double netice = 0;

            MySqlConnection qosulma = null;

            string sorgu = "select " + sutun_adi + " from " + cedvel_adi + " where " + sert_sutunu + "='" + sert_sutun_yazisi + "'";

            try
            {
                qosulma = new MySqlConnection(constr);
                qosulma.Open();
                MySqlCommand cmd = new MySqlCommand(sorgu, qosulma);

                MySqlDataReader dataReader = cmd.ExecuteReader();
                dataReader.Read();

                netice = Convert.ToDouble("" + dataReader["" + sutun_adi + ""]);

                dataReader.Close();

            }
            catch (Exception xeta)
            {

                Baza.msg("Baza:cedvelden_tek_double\n\n" + xeta.ToString());
            }
            finally
            {
                qosulma.Close();

            }
            return Math.Round(netice, dp);
        }
        //hazir 
        public static int cedvelde_serti_odeyen_setir_sayi(string cedvel_adi, string sert)
        {
            int say = -1;
            string sorgu = "select count(*) from " + cedvel_adi + " " + sert + " ";
            MySqlConnection qosulma = null;
            try
            {
                qosulma = new MySqlConnection(constr);
                qosulma.Open();

                MySqlCommand cmd = new MySqlCommand(sorgu, qosulma);
                say = int.Parse(cmd.ExecuteScalar() + "");

            }
            catch (Exception xeta)
            {
                say = -1;

                Baza.msg("Baza:cedvelde_serti_odeyen_setir_sayi\n\n" + xeta.ToString());
            }
            finally
            {
                qosulma.Close();

            }
            return say;
        }


        //hazir 
        public static List<string> cedvelden_melumat_oxumaq_tek_sutun(string cedvel_adi, string sutun_adi, string sert)
        {
            string sorgu = "select " + sutun_adi + " from " + cedvel_adi + "   " + sert + "";
            MySqlConnection qosulma = null;
            List<string> yazilar = new List<string>();
            try
            {
                qosulma = new MySqlConnection(constr);
                qosulma.Open();

                MySqlCommand cmd = new MySqlCommand(sorgu, qosulma);

                MySqlDataReader dataReader = cmd.ExecuteReader();
                while (dataReader.Read())
                {
                    yazilar.Add(dataReader["" + sutun_adi + ""] + "");

                }
                dataReader.Close();
            }
            catch (Exception xeta)
            {

                Baza.msg("Baza:cedvelden_melumat_oxumaq_tek_sutun\n\n" + xeta.ToString());
            }
            finally
            {
                qosulma.Close();

            }
            return yazilar;
        }



        //hazir 
        public static List<string> cedvelden_melumat_oxumaq_tek_sutun_distinct(string cedvel_adi, string sutun_adi, string sert)
        {
            string sorgu = "select distinct " + sutun_adi + " from " + cedvel_adi + "   " + sert + "";
            MySqlConnection qosulma = null;
            List<string> yazilar = new List<string>();
            try
            {
                qosulma = new MySqlConnection(constr);
                qosulma.Open();

                MySqlCommand cmd = new MySqlCommand(sorgu, qosulma);

                MySqlDataReader dataReader = cmd.ExecuteReader();
                while (dataReader.Read())
                {
                    yazilar.Add(dataReader["" + sutun_adi + ""] + "");

                }
                dataReader.Close();
            }
            catch (Exception xeta)
            {

                Baza.msg("Baza:cedvelden_melumat_oxumaq_tek_sutun_distinct\n\n" + xeta.ToString());
            }
            finally
            {
                qosulma.Close();

            }
            return yazilar;
        }


        //hazir 
        public static List<string>[] cedvelden_melumat_oxumaq_cox_sutun(string cedvel_adi, string[] sutun_adlari, string sert)
        {
            string sutunlar = "";

            for (int i = 0; i < sutun_adlari.Length; i++)
            {
                sutunlar += sutun_adlari[i] + ",";

            }

            sutunlar = sutunlar.Substring(0, sutunlar.Length - 1);

            string sorgu = "select " + sutunlar + " from " + cedvel_adi + "   " + sert + "";


            MySqlConnection qosulma = null;

            List<string>[] yazilar = new List<string>[sutun_adlari.Length];

            for (int i = 0; i < sutun_adlari.Length; i++)
            {
                yazilar[i] = new List<string>();
            }
            try
            {
                qosulma = new MySqlConnection(constr);
                qosulma.Open();

                MySqlCommand cmd = new MySqlCommand(sorgu, qosulma);

                MySqlDataReader dataReader = cmd.ExecuteReader();



                while (dataReader.Read())
                {
                    for (int i = 0; i < sutun_adlari.Length; i++)
                    {
                        yazilar[i].Add(dataReader["" + sutun_adlari[i] + ""] + "");
                    }

                }
                dataReader.Close();
            }
            catch (Exception xeta)
            {
                Baza.msg("Baza:cedvelden_melumat_oxumaq_cox_sutun\n\n" + xeta.ToString());
            }
            finally
            {
                qosulma.Close();

            }
            return yazilar;
        }

        // hazir 
        public static List<string> bonus_musterilerin_butun_kodlari()
        {
            return cedvelden_melumat_oxumaq_tek_sutun("abk", "bk", "");
        }

        // hazir 
        internal static void bu_alicinin_bonusunu_sifirla_ve_tarixini_yenile_iki(string abk_bk)
        {


            Baza.msg("" + abk_bar_koduna_gore_adi(abk_bk) + "\n\n\n Xal : " + abk_bonus_xali(abk_bk));




            double caribonus = cedvelden_tek_double("abk", "bonus", "bk", abk_bk, 4);
            string ad = cedvelden_tek_setir("abk", "ad", "bk", abk_bk);
            iud("insert into abkop (ad,abkbk,caribonus,tarix) values ('" + ad + "','" + abk_bk + "','" + caribonus + "','" + indiki_tarix() + "')");



            iud("UPDATE abk  SET bonus=0,ud='" + indiki_tarix() + "' where bk='" + abk_bk + "'");

            Baza.msg("Bu bonus kartının vaxtı keçib.\n\n\nMüştərinin bonusu sıfırlandı.\n\nHazırki bonus müştərinin hesabına əlavə olundu");

        }



        // hazir 
        internal static void mallar_update()
        {
            iud("UPDATE mallar SET deyisdi=0  where deyisdi=1;");

        }

        // hazir 
        internal static void vaxti_kecen_bonuslari_sifirla_ve_tarixini_yenile()
        {
            List<string> kodlari = bonus_musterilerin_butun_kodlari();

            foreach (string bk in kodlari)
            {
                if (bu_bonus_kartinin_sroku_kecib(bk))
                {
                    bu_alicinin_bonusunu_sifirla_ve_tarixini_yenile_iki(bk);

                }
            }
        }

        // hazir 
        public static bool bu_kod_ceki_malin_kodudur(string bk)
        {
            return (cedvelde_serti_odeyen_setir_sayi("tmc", "where code='" + bk + "'") == 1);

        }

        //hazir
        public static DataSet verilmis_sorguya_gore_dataset_ver(string sorgu)
        {
            DataSet netice = null;
            MySqlConnection qosulma = null;
            try
            {
                qosulma = new MySqlConnection(constr);
                qosulma.Open();
                MySqlDataAdapter da = new MySqlDataAdapter(sorgu, qosulma);
                netice = new DataSet();
                da.Fill(netice, sTable);

            }
            catch (MySql.Data.MySqlClient.MySqlException xeta)
            {
                msg("Baza:verilmis_sorguya_gore_dataset_ver\n\n" + xeta.ToString());

            }
            finally
            {
                qosulma.Close();
            }
            return netice;
        }

        //hazirdi 
        internal static void bu_kodulu_mallarda_deyisiklik_olundu(List<string> bklar)
        {
            foreach (string bk in bklar)
            {
                iud("update mallar set deyisdi=1 where bk='" + bk + "'");
            }
        }

        //hazir
        public static bool yeni_gelen_mali_daxil_et(string ad, string bk, int tip, int kt, double mq, double md, double sq, double mdcem, double sqcem, double sqtek, int qutusayi)
        {
            bool bu_daxil_edilen_artiq_var = Baza.cedvelde_serti_odeyen_setir_sayi("mallaryeniindi", " where  bk='" + bk + "'") == 1;

            bool alindi = false;
            try
            {
                if (bu_daxil_edilen_artiq_var)
                {
                    iud("update   mallaryeniindi  set mq=mq+" + mq + " where bk='" + bk + "'"); iud("update mallaryeniindi set mdcem=mq*md,sqcem=sq*mq  where bk='" + bk + "'");
                }
                else
                {
                    double mqqaliq = Baza.cedvelden_tek_double("mallar", "mq", "bk", bk, 3);
                    iud("insert into mallaryeniindi (ad,bk,tip,kt,mq,md,sq,mdcem,sqcem,sqtek,qutusayi,mqqaliq) values ('" +
                           ad + "','" + bk + "'," + tip + "," + kt + ",'" + mq + "','" + md + "','" + sq + "','" + mdcem + "','" + sqcem + "','" + sqtek + "'," + qutusayi + ",'" + mqqaliq + "')");
                }


                alindi = true;

            }
            catch (Exception xeta) { alindi = false; msg("Baza:yeni_gelen_mali_daxil_et\n\n" + xeta.ToString()); }
            finally { }
            return alindi;

        }
        //hazir
        public static void butun_musterilerin_bonus_faizini_deyis(double bonus_faizi)
        {

            iud("UPDATE abk SET faiz='" + bonus_faizi + "';");

            msg("Bütün müştərilərin bonus faizi dəyişdirildi\n\n" + bonus_faizi + " %");
        }
        //hazir
        public static bool iud(string sorgu)
        {

            bool ugurlu = false;

            MySqlConnection qosulma = null;

            try
            {
                qosulma = new MySqlConnection(constr);
                qosulma.Open();

                MySqlCommand cmd = new MySqlCommand(sorgu, qosulma);

                cmd.ExecuteNonQuery();

                ugurlu = true;
            }
            catch (Exception xeta)
            {
                ugurlu = false;
                Baza.msg("Baza:iud\n\n" + xeta.ToString());
            }
            finally
            {
                qosulma.Close();

            }

            return ugurlu;
        }

        // hazir
        internal static bool bu_bonus_kartinin_sroku_kecib(string abk_bk)
        {
            bool kecib = false;


            string ud = cedvelden_tek_setir("abk", "ud", "bk", abk_bk);
            int srokgunu = cedvelden_tek_int("abk", "srokgunu", "bk", abk_bk);

            DateTime indiDateTime = DateTime.Now;
            DateTime ud_date = Convert.ToDateTime(ud);

            if (ud_date.AddDays(srokgunu) <= indiDateTime)
            {
                kecib = true;

            }
            return kecib;
        }



        //hazirdir
        internal static bool alicinin_sroku_limite_catib_yoxsa_yox(string abk_bk)
        {
            bool catib = false;

            string ud = cedvelden_tek_setir("abk", "ud", "bk", abk_bk);

            int srokgunu = cedvelden_tek_int("abk", "srokgunu", "bk", abk_bk);

            int srok_bildirisi_gunu = cedvelden_tek_int("info", "daxili", "ad", "srok_bildirisi_gunu");

            DateTime indiDateTime = DateTime.Now;
            DateTime udDate = Convert.ToDateTime(ud);

            if (udDate.AddDays(srokgunu) <= indiDateTime.AddDays(srok_bildirisi_gunu))
            {



                DateTime srokTarixiDate = udDate.AddDays(srokgunu);
                srokTarixi = srokTarixiDate.ToString("yyyy-MM-dd HH:mm:ss",
                                    CultureInfo.InvariantCulture);


                catib = true;

            }
            return catib;
        }

        //hazir
        internal static void bu_alicinin_bonusunu_sifirla_ve_tarixini_yenile(string abk_bk)
        {

            double caribonus = cedvelden_tek_double("abk", "bonus", "bk", abk_bk, 4);
            string ad = cedvelden_tek_setir("abk", "ad", "bk", abk_bk);
            iud("insert into abkop (ad,abkbk,caribonus,tarix) values ('" + ad + "','" + abk_bk + "','" + caribonus + "','" + indiki_tarix() + "')");


            iud("UPDATE abk  SET bonus=0,ud='" + indiki_tarix() + "' where bk='" + abk_bk + "'");

        }


        // hazir metod
        public static double alicinin_bar_koduna_gore_bonus_faizi(string bk)
        {
            return cedvelden_tek_double("abk", "faiz", "bk", bk, 4);

        }
        // hazir 

        public static string abk_bar_koduna_gore_adi(string bk)
        {
            return cedvelden_tek_setir("abk", "ad", "bk", bk);

        }
        // hazir
        public static double abk_bonus_xali(string abk_bk)
        {
            return cedvelden_tek_double("abk", "bonus", "bk", abk_bk, 4);

        }

        //hazir
        public static bool cekde_alicinin_umumi_xali_gorunur_yoxsa_yox()
        {
            return cedvelden_tek_setir("info", "daxili", "ad", "cekde_xal_gorunsun").Equals("1");


        }
        //hazir
        internal static bool cekde_srok_cap_olunsun_yoxsa_yox()
        {
            return cedvelden_tek_setir("info", "daxili", "ad", "cekde_srok_gorunsun").Equals("1");

        }
        // hazirdir 
        public static double cedvelde_sutunun_cemleri(string cedvel_adi, string sutun_adi, string sert)
        {
            double cem = 0;

            string sorgu = "select sum(" + sutun_adi + ") from " + cedvel_adi + " " + sert + " ";
            MySqlConnection qosulma = null;
            try
            {
                qosulma = new MySqlConnection(constr);
                qosulma.Open();
                MySqlCommand cmd = new MySqlCommand(sorgu, qosulma);
                cem = double.Parse(cmd.ExecuteScalar() + "");
            }
            catch (Exception)
            {
                cem = 0;

                //Baza.msg("Baza:cedvelde_sutunun_cemleri\n\n" + xeta.ToString());
            }
            finally
            {
                qosulma.Close();

            }
            return cem;
        }
        //hazir 
        internal static void satilan_mallari_bazadan_azalt_baza_sinifi(int kk)
        {
            string sorgu1 = "select bk,mq,tip,tipsatis,tipdene from satilanindi where kk=" + kk;

            MySqlConnection qosh = null;
            try
            {
                qosh = new MySqlConnection(constr);
                qosh.Open();
                MySqlCommand cmd1 = new MySqlCommand(sorgu1, qosh);
                MySqlDataReader reader = cmd1.ExecuteReader();

                while (reader.Read())
                {
                    double mq = double.Parse(reader["mq"] + "");

                    string bk = reader["bk"] + "";

                    int tip = int.Parse(reader["tip"] + "");

                    int tipsatis = int.Parse(reader["tipsatis"] + "");
                    int tipdene = int.Parse(reader["tipdene"] + "");

                    satilan_mallari_bazadan_azalt_baza_sinifi(mq, bk, tip, tipsatis, tipdene);

                }
                reader.Close();
            }
            catch (Exception xeta) { msg("Baza:satilan_mallari_bazadan_azalt_baza_sinifi\n\n" + xeta.ToString()); }

            finally { qosh.Close(); }
        }

        //hazir 
        private static void satilan_mallari_bazadan_azalt_baza_sinifi(double mq, string bk, int tip, int tipsatis, int tipdene)
        {

            if (tipdene == 0)
            {
                if (tipsatis == 0)
                {

                    iud("update mallar set mq=mq-" + mq + " where bk= '" + bk + "' ");
                }
                else
                {

                    iud("update mallar set mq=mq+" + mq + " where bk= '" + bk + "' ");
                }

            }
            else if (tipdene == 1)
            {
                if (tipsatis == 0)
                {

                    int qutusayi = cedvelden_tek_int("mallar", "qutusayi", "bk", bk);
                    int mqtek = cedvelden_tek_int("mallar", "mqtek", "bk", bk);
                    if (mq > mqtek)
                    {
                        mqtek += qutusayi;
                        mqtek -= (int)mq;
                        iud("update mallar set mq=mq-1 where bk= '" + bk + "' ");
                    }
                    else
                    {

                        mqtek -= (int)mq;

                    }
                    iud("update mallar set mqtek= " + mqtek + " where bk= '" + bk + "' ");


                }
            }


        }


        //hazir 
        internal static bool yeni_gelen_mali_daxil_et_mallara()
        {
            bool netice = false;
            try
            {
                iud("insert into  mallargetirilen (ad,bk,tarix,mq,md,mdcem,sq,sqcem,tip,kt)     (select ad,bk,'2000-01-01 01:01:01',mq,md,mdcem,sq,sqcem,tip,kt  from  mallaryeniindi)");
                iud("update    mallargetirilen set tarix='" + indiki_tarix() + "' where tarix='2000-01-01 01:01:01'");

                gm_sq_md_mq_yenile();
                iud(" delete from  mallaryeniindi");
                netice = true;
            }
            catch (Exception xeta)
            {
                netice = false; msg("Baza:yeni_gelen_mali_daxil_et_mallara\n\n" + xeta.ToString());
            }

            return netice;

        }
        //hazir 
        internal static void adYazmagaIcaze(object sender, KeyPressEventArgs e)
        {
            e.Handled = !(char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Back || e.KeyChar == (char)Keys.Space || char.IsDigit(e.KeyChar) || e.KeyChar == '.' || e.KeyChar == '%');
        }
        //hazir 
        internal static void doubleYazmagaIcaze(object sender, KeyPressEventArgs e)
        {
            e.Handled = !(e.KeyChar == (char)Keys.Back || char.IsDigit(e.KeyChar) || e.KeyChar == '.');
        }
        //hazir 
        internal static void intYazmagaIcaze(object sender, KeyPressEventArgs e)
        {
            e.Handled = !(e.KeyChar == (char)Keys.Back || char.IsDigit(e.KeyChar));
        }
        //hazir 

        public static bool aliciya_hediyye_ver(int hediyyeBali, string bk)
        {
            bool verildi = false;

            try
            {
                iud("UPDATE abk  SET bonus=bonus-'" + hediyyeBali + "' where bk = '" + bk + "'");
                verildi = true;
            }
            catch (Exception xeta) { verildi = false; msg("Baza:aliciya_hediyye_ver\n\n" + xeta.ToString()); }


            return verildi;
        }
        //hazir 
        public static void gm_sq_md_mq_yenile()
        {
            MySqlConnection qosucu = null;
            string sorgu = "select bk,mq,md,sq from mallaryeniindi";

            try
            {
                qosucu = new MySqlConnection(constr);
                qosucu.Open();
                MySqlCommand komanda = new MySqlCommand(sorgu, qosucu);
                MySqlDataReader oxuyucu = komanda.ExecuteReader();

                List<string> bkLar = new List<string>();
                List<string> mqLer = new List<string>();
                List<string> mdLer = new List<string>();
                List<string> sqLer = new List<string>();

                while (oxuyucu.Read())
                {

                    bkLar.Add(oxuyucu["bk"] + "");
                    sqLer.Add(oxuyucu["sq"] + "");
                    mdLer.Add(oxuyucu["md"] + "");
                    mqLer.Add(oxuyucu["mq"] + "");
                }

                oxuyucu.Close();

                for (int i = 0; i < bkLar.Count; i++)
                {
                    sorgu = "update mallar set sq='" + sqLer[i] + "',md='" + mdLer[i] + "',mq=mq+'" + mqLer[i] + "' where bk='" + bkLar[i] + "'";
                    komanda = new MySqlCommand(sorgu, qosucu);
                    komanda.ExecuteNonQuery();

                    sorgu = "update tmc set unit_price='" + (double.Parse(sqLer[i]) * 100) + "' where code='" + bkLar[i] + "'";
                    komanda = new MySqlCommand(sorgu, qosucu);
                    komanda.ExecuteNonQuery();

                }
            }
            catch (Exception xeta) { msg("Baza:gm_sq_md_mq_yenile\n\n" + xeta.ToString()); }
            finally { qosucu.Close(); }

        }

        //hazir
        public static double verilen_ededin_faizini_tap(double eded, double faiz)
        {
            double e = 0;
            e = (eded / 100.0) * faiz;
            return e;
        }
        //hazir
        public static long cedveldeSutununMaksimumDeyeri(string cedvel, string sutun, string sert)
        {
            long maksimumSutunDeyeri = -1;
            string sorgu = "select max(" + sutun + ") from " + cedvel + " " + sert + " ";
            MySqlConnection qosulma = null;
            try
            {
                qosulma = new MySqlConnection(constr);
                qosulma.Open();
                MySqlCommand cmd = new MySqlCommand(sorgu, qosulma);
                maksimumSutunDeyeri = long.Parse(cmd.ExecuteScalar() + "");
            }
            catch (Exception xeta)
            {
                maksimumSutunDeyeri = -1;

                Baza.msg("Baza:cedveldeSutununMaksimumDeyeri\n\n" + xeta.ToString());
            }
            finally
            {
                qosulma.Close();
            }

            return maksimumSutunDeyeri;
        }

        //hazir 
        public static bool yeni_alici_b_k_daxil_et(string ad, string bk)
        {
            bool ok = false;
            try
            {
                tarixleriYenile();
                int srokgunu = Convert.ToInt32(Microsoft.VisualBasic.Interaction.InputBox("Bu bonus kartı üçün Srok gününü daxil edin", "", "30") + "");

                ok = iud("insert into abk (ad,bk,bonus,faiz,od,srokgunu,ud) values('" + ad + "','" + bk + "','0','" + cedvelden_tek_double("info", "daxili", "ad", "bonus_faizi", 4) + "','" + indi + "'," + srokgunu + ",'" + indi + "')");


            }
            catch (Exception xeta)
            {
                ok = false;
                Baza.msg("Baza:yeni_alici_b_k_daxil_et\n\n" + xeta.ToString());
            }


            return ok;

        }
        //hazir 
        public static List<string> cedvelden_melumat_oxumaq_tek_sutun_show(string cedvel_adi, string sutun_adi, string sert)
        {
            sutun_adi = "Field";
            string sorgu = " SHOW COLUMNS FROM " + cedvel_adi;

            MySqlConnection qosulma = null;
            List<string> yazilar = new List<string>();
            try
            {
                qosulma = new MySqlConnection(constr);
                qosulma.Open();

                MySqlCommand cmd = new MySqlCommand(sorgu, qosulma);

                MySqlDataReader dataReader = cmd.ExecuteReader();
                while (dataReader.Read())
                {
                    yazilar.Add(dataReader["" + sutun_adi + ""] + "");

                }
                dataReader.Close();
            }
            catch (Exception xeta)
            {

                msg("Baza:cedvelden_melumat_oxumaq_tek_sutun_show\n\n" + xeta.ToString());
            }
            finally
            {
                qosulma.Close();

            }
            return yazilar;
        }
        //hazir 
        internal static void kassaniBagla(int kk)
        {

            List<string> sutunlar = Baza.cedvelden_melumat_oxumaq_tek_sutun_show("satilanlar", "", "");
            sutunlar.Remove("id");
            string sutunlarSetir = "";

            for (int i = 0; i < sutunlar.Count; i++)
            {
                sutunlarSetir += "" + sutunlar[i] + ",";

            }
            sutunlarSetir = sutunlarSetir.Substring(0, sutunlarSetir.Length - 1);

            Baza.iud("insert into satilanlararxiv (" + sutunlarSetir + ")   (SELECT " + sutunlarSetir + " FROM  satilanlar where kk=" + kk + ")");

            iud("delete FROM  satilanlar where kk=" + kk + "");

        }
        //hazir 
        public static bool yeni_musterini_bazaya_daxil_et(string ad)
        {
            bool ok = false;
            try
            {
                ok = iud("insert into borclular (ad,od,borc) values('" + ad + "','" + indiki_tarix() + "','0' )");

            }
            catch (Exception xeta)
            {
                ok = false;

                Baza.msg("Baza:yeni_musterini_bazaya_daxil_et\n\n" + xeta.ToString());


            }

            return ok;

        }
        //hazir 
        public static void kassada_f7_ile_silinen_mali_bazaya_yaz(string ad, double sq, double mq, double sqcem, string bk, int kk, string kassaTarixi)
        {
            iud("insert into ksilinen (ad,sq,mq,sqcem,bk,kk,tarix,kassatarixi) values('" + ad + "','" + sq + "','" + mq + "','" + sqcem + "','" + bk + "'," + kk + ",'" + indiki_tarix() + "','" + kassaTarixi + "')");
        }



        //hazir 
        internal static void kohnelenBonusKartlariniSilTamam()
        {
            DateTime indiDateTime = DateTime.Now;

            indiDateTime = indiDateTime.AddMonths(-1 * cedvelden_tek_int("info", "daxili", "ad", "nece_aydan_sonra_bk_silinsin"));

            string tarix = indiDateTime.ToString("yyyy-MM-dd HH:mm:ss",
                                CultureInfo.InvariantCulture);

            iud("delete from abk where ud <'" + tarix + "'");
        }
        //hazir 
        internal static bool qaytarilanMaliBazadanAzalt(string bk, double mq)
        {

            return iud("update mallar set mq=mq-" + mq + " where bk='" + bk + "'");
        }
        //hazir 
        internal static void gmCedveliniDoldurTarixUcun(List<string> gm_cedvelleri_tarix_araliginda)
        {
            iud("truncate table gmlist");
            for (int i = 0; i < gm_cedvelleri_tarix_araliginda.Count; i++)
            {
                string tarix = gm_cedvelleri_tarix_araliginda[i];

                double mdcem = Baza.cedvelde_sutunun_cemleri("mallargetirilenarxiv", "mdcem", " where tarix='" + tarix + "'");
                double sqcem = Baza.cedvelde_sutunun_cemleri("mallargetirilenarxiv", "sqcem", " where tarix='" + tarix + "'");

                iud("insert into gmlist (tarix,mdcem,sqcem) values ('" + tarix + "','" + mdcem + "','" + sqcem + "')");

            }

        }
    }
}
