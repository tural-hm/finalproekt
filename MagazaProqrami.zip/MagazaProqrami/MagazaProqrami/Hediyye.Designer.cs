﻿namespace MagazaProqramiDEA
{
    partial class Hediyye
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Hediyye));
            this.hediyye_al_button = new System.Windows.Forms.Button();
            this.balans_label = new System.Windows.Forms.Label();
            this.ad_soyad_label = new System.Windows.Forms.Label();
            this.hediyye_bali_text = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.ad_s_label = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // hediyye_al_button
            // 
            this.hediyye_al_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hediyye_al_button.ForeColor = System.Drawing.Color.Brown;
            this.hediyye_al_button.Location = new System.Drawing.Point(36, 204);
            this.hediyye_al_button.Name = "hediyye_al_button";
            this.hediyye_al_button.Size = new System.Drawing.Size(189, 47);
            this.hediyye_al_button.TabIndex = 15;
            this.hediyye_al_button.Text = "Hədiyyə Al";
            this.hediyye_al_button.UseVisualStyleBackColor = true;
            this.hediyye_al_button.Click += new System.EventHandler(this.hediyye_al_button_Click);
            // 
            // balans_label
            // 
            this.balans_label.AutoSize = true;
            this.balans_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.balans_label.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.balans_label.Location = new System.Drawing.Point(226, 82);
            this.balans_label.Name = "balans_label";
            this.balans_label.Size = new System.Drawing.Size(20, 29);
            this.balans_label.TabIndex = 14;
            this.balans_label.Text = ":";
            // 
            // ad_soyad_label
            // 
            this.ad_soyad_label.AutoSize = true;
            this.ad_soyad_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ad_soyad_label.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.ad_soyad_label.Location = new System.Drawing.Point(226, 21);
            this.ad_soyad_label.Name = "ad_soyad_label";
            this.ad_soyad_label.Size = new System.Drawing.Size(20, 29);
            this.ad_soyad_label.TabIndex = 13;
            this.ad_soyad_label.Text = ":";
            // 
            // hediyye_bali_text
            // 
            this.hediyye_bali_text.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hediyye_bali_text.Location = new System.Drawing.Point(212, 143);
            this.hediyye_bali_text.Name = "hediyye_bali_text";
            this.hediyye_bali_text.Size = new System.Drawing.Size(123, 35);
            this.hediyye_bali_text.TabIndex = 12;
            this.hediyye_bali_text.KeyDown += new System.Windows.Forms.KeyEventHandler(this.hediyye_bali_text_KeyDown_1);
            this.hediyye_bali_text.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.hediyye_bali_text_KeyPress);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label3.Location = new System.Drawing.Point(31, 147);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(157, 29);
            this.label3.TabIndex = 11;
            this.label3.Text = "Hədiyyə balı";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label2.Location = new System.Drawing.Point(31, 84);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(92, 29);
            this.label2.TabIndex = 10;
            this.label2.Text = "Balans";
            // 
            // ad_s_label
            // 
            this.ad_s_label.AutoSize = true;
            this.ad_s_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ad_s_label.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.ad_s_label.Location = new System.Drawing.Point(31, 21);
            this.ad_s_label.Name = "ad_s_label";
            this.ad_s_label.Size = new System.Drawing.Size(125, 29);
            this.ad_s_label.TabIndex = 9;
            this.ad_s_label.Text = "Ad/Soyad";
            // 
            // Hediyye
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(719, 335);
            this.Controls.Add(this.hediyye_al_button);
            this.Controls.Add(this.balans_label);
            this.Controls.Add(this.ad_soyad_label);
            this.Controls.Add(this.hediyye_bali_text);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.ad_s_label);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Hediyye";
            this.Text = "Hədiyyə";
            this.Load += new System.EventHandler(this.Hediyye_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button hediyye_al_button;
        private System.Windows.Forms.Label balans_label;
        private System.Windows.Forms.Label ad_soyad_label;
        private System.Windows.Forms.TextBox hediyye_bali_text;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label ad_s_label;
    }
}