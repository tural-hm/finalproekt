﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MagazaProqramiDEA
{
    public partial class Basliq : Form
    {



        Kassa kassa = null;
        Admin admin = null;


        public Basliq()
        {
            InitializeComponent();
        }
        //hazir 
        private void Basliq_Load(object sender, EventArgs e)
        {
            kassalariSiyahiyaElaveEt();

            veb_label1.Text = Baza.veb;
            mail_label2.Text = Baza.email;
            mobil_label3.Text = Baza.mobil;
            huquq_label1.Text = Baza.huquq;
            istifadeciler_listBox1.SelectedIndex = 0;
            istifadeciler_listBox1.Focus();
            loqo_pictureBox1.Image = Image.FromFile("C:\\hhmdxeht\\MagazaProqramiDEA\\loqo.png");
            bool loqoGorunsun = Baza.cedvelden_tek_setir("info", "daxili", "ad", "loqo-gorunsun").Equals("1");
            if (loqoGorunsun)
            {
                loqo_pictureBox1.Visible = true;
            }
            else
            {
                loqo_pictureBox1.Visible = false;
            }

        }
        //hazir 
        private void kassalariSiyahiyaElaveEt()
        {
            for (int i = 0; i < Baza.kassaSayi; i++)
            {
                istifadeciler_listBox1.Items.Add("Kassa-" + (i + 1));
            }

        }
        //hazir 
        private void Basliq_FormClosing(object sender, FormClosingEventArgs e)
        {


            if (e.CloseReason == CloseReason.UserClosing)
            {
                e.Cancel = true;

                if (MessageBox.Show("Proqramı bağlamağa əminsiniz?", Baza.adminAdi, MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    System.Windows.Forms.Application.Exit();
                }
                else
                {

                }
            }
        }

        //hazir 

        private void btnlogin_Click(object sender, EventArgs e)
        {

            int secilenIndeks = istifadeciler_listBox1.SelectedIndex;
            if (secilenIndeks == 0)
            {
                if (txtpas.Text.Equals(Baza.adminSifresi))
                {
                    if (admin == null)
                    {
                        admin = new Admin();
                        admin.Show();

                    }
                    else
                    {
                        admin.Show();
                    }
                }
                else { Baza.msg("Admin şifrəsi yalnış daxil edildi", Baza.adminAdi); }
            }
            else
            {
                if (txtpas.Text.Equals(Baza.kassaSifreleri[secilenIndeks - 1]))
                {
                    if (Baza.kassayaDaxilOlunub == false)
                    {
                        kassa = new Kassa(secilenIndeks);
                        kassa.Show();
                        kassa.axtaris_ucun_mallari_yukle();
                        Baza.kassayaDaxilOlunub = true;
                    }
                }
                else { Baza.msg("Kassa şifrəsi yalnış daxil edildi", Baza.adminAdi); }

            }



        }

        //hazir 
        private void istifadeciler_listBox1_MouseClick(object sender, MouseEventArgs e)
        {
            panel1.Visible = true;
        }
        //hazir 
        private void esas_tableLayoutPanel1_MouseClick(object sender, MouseEventArgs e)
        {
            panel1.Visible = false;
        }
    }
}
