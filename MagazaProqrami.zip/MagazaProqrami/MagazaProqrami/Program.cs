﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MagazaProqramiDEA
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Baza.bazaniHazirla();

            System.Globalization.CultureInfo customCulture = (System.Globalization.CultureInfo)System.Threading.Thread.CurrentThread.CurrentCulture.Clone();
            customCulture.NumberFormat.NumberDecimalSeparator = ".";

            System.Threading.Thread.CurrentThread.CurrentCulture = customCulture;


            //Baza.msg(Baza.cariQovluqUnvani);
            //Console.WriteLine("Salam");
            //Console.WriteLine(Baza.verilmisSozuCevir("salam"));
            //Console.WriteLine("Mağazanın adı - " + Baza.cedvelden_tek_setir("info", "daxili", "ad", "magaza-adi"));


            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            int istiqamet = 0;

            switch (istiqamet)
            {
                case 0: { Application.Run(new Basliq()); }; break;
                case 1: { Application.Run(new Hesabatlar()); }; break;
                case 2: { Application.Run(new Admin()); }; break;
              
                default: { }; break;
            }

        }
    }
}
