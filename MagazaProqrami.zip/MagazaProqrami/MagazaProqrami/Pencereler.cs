﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MagazaProqramiDEA
{
    public partial class Pencereler : Form
    {
        public Pencereler()
        {
            InitializeComponent();
        }

        private void Pencereler_Load(object sender, EventArgs e)
        {

        }
    }
}
