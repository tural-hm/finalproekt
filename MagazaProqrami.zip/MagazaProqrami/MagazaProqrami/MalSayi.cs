﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MagazaProqramiDEA
{
    public partial class MalSayi : Form
    {

        //hazir 
        Kassa kassa;
        private bool aktiv;
        private string ad;
        private string bk;
        private double md;
        private double sq;
        private double mq;
        private double sqtek;
        private int mqtek;
        private int plukodu;
        private int tip;
        private int kt;
        private int qutusayi;

        int tipDene = 0;

        static bool yenidenSatish = false;

        static string say = "";

        //hazir 
        public MalSayi()
        {
            InitializeComponent();
        }
        //hazir 
        public MalSayi(string ad, string bk, double md, double sq, double mq, bool aktiv, double sqtek, int mqtek, int plukodu, int tip, int kt, int qutusayi, Kassa kassa)
        {
            InitializeComponent();
            this.ad = ad;
            this.bk = bk;
            this.md = md;
            this.sq = sq;
            this.mq = mq;
            this.aktiv = aktiv;
            this.sqtek = sqtek;
            this.mqtek = mqtek;
            this.plukodu = plukodu;
            this.tip = tip;
            this.kt = kt;
            this.qutusayi = qutusayi;
            this.kassa = kassa;
        }


        //hazir 
        private void malin_sayi_textBox1_KeyDown(object sender, KeyEventArgs e)
        {





            if (e.KeyCode == Keys.F1 || e.KeyCode == Keys.D)
            {

                malin_qiymeti_textBox1.Enabled = true;
                malin_qiymeti_textBox1.SelectAll();
                malin_qiymeti_textBox1.Focus();

            }

            else
                if (e.KeyCode == Keys.Enter)
                {

                    string say = malin_sayi_textBox1.Text;

                    MalSayi.say = say;

                    if (say.Length > 4)
                    {
                        yenidenSatish = true;
                        malin_miqdari_tesdiqlenir(Convert.ToDouble("1"));
                    }
                    else
                    {
                        yenidenSatish = false;
                        malin_miqdari_tesdiqlenir(Convert.ToDouble(say));
                    }
                    malinSatishiUcunTetbiqOlunanFaiz = 0;
                }
                else
                    if (e.KeyCode == Keys.F2 || e.KeyCode == Keys.T)
                    {
                        if (tipDene == 1)
                        {
                            tam_radioButton1.Checked = true;

                        }
                        else if (tipDene == 0)
                        {
                            deneli_radioButton2.Checked = true;
                        }


                    }
                    else
                        if (e.KeyCode == Keys.F3)
                        {
                        }
        }public static double malinSatishiUcunTetbiqOlunanFaiz = 0;
        public double sqEndirimli;
        //hazir
        private void malin_miqdari_tesdiqlenir(double mq)
        {

            if (tipDene == 0)
            {
                bool malQalibmi = mq > this.mq;
                malQalibmi = false;
                if (malQalibmi)
                {
                    Baza.msg("Bazada daxil etdiyinizdən daha az mal qalıb", Baza.adminAdi);

                }
                else
                {



                    this.sq = Convert.ToDouble(malin_qiymeti_textBox1.Text);
                    this.sqEndirimli = (sq / 100.0) * (100 - Double.Parse(malSayi_endirim_faizi_label2.Text));
                    
              
                   
                    bool buArtiqVar = Kassa.bkList.Contains(bk);

                    if (buArtiqVar)
                    {
                        int indeks = Kassa.bkList.IndexOf(bk);
                        if (Kassa.tipdeneList[indeks] == 1)
                        {
                            Kassa.tipdeneList[indeks] = 0;
                        }
                        Kassa.mqList[indeks] = Kassa.mqList[indeks] + mq;
                        Kassa.sqList[indeks] = sq; Kassa.sqEndirimliList[indeks] = sqEndirimli;
                        double sqcem = sqEndirimli * Kassa.mqList[indeks];
                        sqcem = Math.Round(sqcem, 4);

                        Kassa.sqcemList[indeks] = sqcem;

                    }
                    else
                    {

                        Kassa.adList.Add("" + ad);

                        Kassa.sqList.Add(sq); Kassa.sqEndirimliList.Add(sqEndirimli);

                        Kassa.mqList.Add(mq);

                        double sqcem = sqEndirimli * mq;
                        sqcem = Math.Round(sqcem, 4);

                        Kassa.sqcemList.Add(sqcem);

                        Kassa.bkList.Add(bk);

                        Kassa.tipList.Add(tip);

                        Kassa.tipsatisList.Add(Baza.tipSatis);
                        Kassa.tipdeneList.Add(tipDene);
                        kassa.kassaCedvelineYeniSetirElaveEt();

                    }

                    kassa.malin_melumatlarini_cedvele_yaz();

                    if (yenidenSatish)
                    {
                        kassa.satisa_basla(say);
                    }
                    this.Dispose();


                }
            }
            else
            {



                this.sq = Convert.ToDouble(malin_qiymeti_textBox1.Text);

                bool buArtiqVar = Kassa.bkList.Contains(bk);

                if (buArtiqVar)
                {
                    int indeks = Kassa.bkList.IndexOf(bk);

                    if (Kassa.tipdeneList[indeks] == 0)
                    {
                        Kassa.tipdeneList[indeks] = 1;
                    }


                    Kassa.mqList[indeks] = Kassa.mqList[indeks] + mq;
                    Kassa.sqList[indeks] = sq;
                    double sqcem = sq * Kassa.mqList[indeks];
                    sqcem = Math.Round(sqcem, 4);

                    Kassa.sqcemList[indeks] = sqcem;
                    kassa.malin_melumatlarini_cedvele_yaz();
                    if (yenidenSatish)
                    {
                        kassa.satisa_basla(say);
                    }
                    this.Dispose();

                }
                else
                {

                    Kassa.adList.Add("" + ad);



                    Kassa.sqList.Add(sq);

                    Kassa.mqList.Add(mq);

                    double sqcem = sq * mq;
                    sqcem = Math.Round(sqcem, 4);

                    Kassa.sqcemList.Add(sqcem);

                    Kassa.bkList.Add(bk);

                    Kassa.tipList.Add(tip);

                    Kassa.tipsatisList.Add(Baza.tipSatis);
                    Kassa.tipdeneList.Add(tipDene);
                    kassa.kassaCedvelineYeniSetirElaveEt();
                    kassa.malin_melumatlarini_cedvele_yaz();
                    if (yenidenSatish)
                    {
                        kassa.satisa_basla(say);
                    }
                    this.Dispose();
                }




            }


        }
        //hazir 
        private void MalSayi_Load(object sender, EventArgs e)
        {
            malin_qiymeti_textBox1.Text = "" + sq;
            malin_qiymeti_textBox1.Enabled = false;

            malin_sayi_textBox1.Text = "1";

            this.Text = "Malın adı : (" + ad + ")";
            malin_qaliq_miqdari_label1.Text = "Malın qalıq miqdarı : " + mq;
            malin_adi_aktiv_label1.Text = "Malın adı : " + ad;


            malin_sayi_textBox1.Focus();
            tam_deneli_groupBox1.Visible = false;

            if (tip == 1)
            {
                basliq_label1.Text = "Say ilə olan malın satışı";

            }
            else if (tip == 2)
            {
                basliq_label1.Text = "Uzunluq ilə olan malın satışı";

            }
            else if (tip == 3)
            {
                basliq_label1.Text = "Çəki ilə olan malın satışı";

            }
            else
                if (tip == 4)
                {
                    basliq_label1.Text = "Dənə ilə olan malın satışı";
                    tam_deneli_groupBox1.Visible = true;

                    tam_radioButton1.Checked = true;
                }
            malSayi_endirim_faizi_label2.Text = "0";
        }
        // hazir 
        private void tam_radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            tipDene = 0;
            malin_qiymeti_textBox1.Text = "" + Baza.cedvelden_tek_double("mallar", "sq", "bk", bk, 4);

        }
        //hazir 
        private void deneli_radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            tipDene = 1;
            malin_qiymeti_textBox1.Text = "" + Baza.cedvelden_tek_double("mallar", "sqtek", "bk", bk, 4);
        }
        // hazir
        private void malin_qiymeti_textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F1 || e.KeyCode == Keys.D)
            {
                e.SuppressKeyPress = true;
                malin_sayi_textBox1.Enabled = true;

                malin_sayi_textBox1.Focus();
                malin_sayi_textBox1.SelectAll();

            }


            if (e.KeyCode == Keys.Enter)
            {
                malin_miqdari_tesdiqlenir(Convert.ToDouble(malin_sayi_textBox1.Text));


            }
            else
                if (e.KeyCode == Keys.F2 || e.KeyCode == Keys.T)
                {
                    if (tipDene == 1)
                    {
                        tam_radioButton1.Checked = true;

                    }
                    else if (tipDene == 0)
                    {
                        deneli_radioButton2.Checked = true;
                    }


                }
        }
        //hazir 
        private void malin_sayi_textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (tip == 1 || tip == 4) { Baza.intYazmagaIcaze(sender, e); } else { Baza.doubleYazmagaIcaze(sender, e); }


        }
        //hazir 
        private void malin_qiymeti_textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            Baza.doubleYazmagaIcaze(sender, e);
        }
        //hazir 
        private void malin_sayi_textBox1_KeyUp(object sender, KeyEventArgs e)
        {




        }
    }
}
