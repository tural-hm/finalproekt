﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MagazaProqramiDEA
{
    public partial class Hesabatlar : Form
    {

        public static int hesabatTipi = 0;




        public Hesabatlar()
        {
            InitializeComponent();
        }

        private void Hesabatlar_Load(object sender, EventArgs e)
        {
            satilanlar_radioButton1.Checked = true;
        }

        private void satilanlar_radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            hesabatTipi = 0;
            
        }

        private void qaytarilanlar_radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            hesabatTipi = 1;
            
        }
    }
}
