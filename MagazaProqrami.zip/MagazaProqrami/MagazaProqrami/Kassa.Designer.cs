﻿namespace MagazaProqramiDEA
{
    partial class Kassa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Kassa));
            this.satici_kassasi_esas_main_tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.kassa_tabControl = new System.Windows.Forms.TabControl();
            this.satici_kassasi_tabPage = new System.Windows.Forms.TabPage();
            this.SATİCİ_KASSASİ_KASSA_tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.kassa_dgv = new System.Windows.Forms.DataGridView();
            this.malin_adi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.s_q = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.miqdar = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.c_s_q = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bar_kod = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cem_tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.cem_passiv_label4 = new System.Windows.Forms.Label();
            this.cem_mebleg_aktiv_label = new System.Windows.Forms.Label();
            this.skaner_tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.skaner_textbox = new System.Windows.Forms.TextBox();
            this.qaliq_label_passiv_label1 = new System.Windows.Forms.Label();
            this.qaliq_pul_aktiv_label = new System.Windows.Forms.Label();
            this.borca_yaz_alishi_button1 = new System.Windows.Forms.Button();
            this.borc_yazilan_musteri_label1 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.kassa_endirim_faizi_label2 = new System.Windows.Forms.Label();
            this.mallar_axtarisi_tabPage = new System.Windows.Forms.TabPage();
            this.SATİCİ_KASSASİ_MALLAR_tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.mallar_dgv_kassa = new System.Windows.Forms.DataGridView();
            this.malSiyahisiText = new System.Windows.Forms.TextBox();
            this.kassa_borclular_tabPage = new System.Windows.Forms.TabPage();
            this.SATİCİ_KASSASİ_BORCLULAR_tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.borclular_dgv_kassa = new System.Windows.Forms.DataGridView();
            this.borclular_axtar_tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.kassa_borclular_axtar_textBox = new System.Windows.Forms.TextBox();
            this.kassa_borclular_umumi_borc_aktiv_label4 = new System.Windows.Forms.Label();
            this.borc_passiv_label2 = new System.Windows.Forms.Label();
            this.basliq_tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.kassa_label = new System.Windows.Forms.Label();
            this.marketin_adi_label = new System.Windows.Forms.Label();
            this.kassa_alis_satis_rejimi_label4 = new System.Windows.Forms.Label();
            this.kassa_printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.satici_kassasi_esas_main_tableLayoutPanel1.SuspendLayout();
            this.kassa_tabControl.SuspendLayout();
            this.satici_kassasi_tabPage.SuspendLayout();
            this.SATİCİ_KASSASİ_KASSA_tableLayoutPanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kassa_dgv)).BeginInit();
            this.cem_tableLayoutPanel5.SuspendLayout();
            this.skaner_tableLayoutPanel6.SuspendLayout();
            this.mallar_axtarisi_tabPage.SuspendLayout();
            this.SATİCİ_KASSASİ_MALLAR_tableLayoutPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.mallar_dgv_kassa)).BeginInit();
            this.kassa_borclular_tabPage.SuspendLayout();
            this.SATİCİ_KASSASİ_BORCLULAR_tableLayoutPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.borclular_dgv_kassa)).BeginInit();
            this.borclular_axtar_tableLayoutPanel4.SuspendLayout();
            this.basliq_tableLayoutPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // satici_kassasi_esas_main_tableLayoutPanel1
            // 
            this.satici_kassasi_esas_main_tableLayoutPanel1.ColumnCount = 1;
            this.satici_kassasi_esas_main_tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.satici_kassasi_esas_main_tableLayoutPanel1.Controls.Add(this.kassa_tabControl, 0, 1);
            this.satici_kassasi_esas_main_tableLayoutPanel1.Controls.Add(this.basliq_tableLayoutPanel2, 0, 0);
            this.satici_kassasi_esas_main_tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.satici_kassasi_esas_main_tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.satici_kassasi_esas_main_tableLayoutPanel1.Name = "satici_kassasi_esas_main_tableLayoutPanel1";
            this.satici_kassasi_esas_main_tableLayoutPanel1.RowCount = 2;
            this.satici_kassasi_esas_main_tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 70F));
            this.satici_kassasi_esas_main_tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.satici_kassasi_esas_main_tableLayoutPanel1.Size = new System.Drawing.Size(1206, 643);
            this.satici_kassasi_esas_main_tableLayoutPanel1.TabIndex = 21;
            // 
            // kassa_tabControl
            // 
            this.kassa_tabControl.Controls.Add(this.satici_kassasi_tabPage);
            this.kassa_tabControl.Controls.Add(this.mallar_axtarisi_tabPage);
            this.kassa_tabControl.Controls.Add(this.kassa_borclular_tabPage);
            this.kassa_tabControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.kassa_tabControl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kassa_tabControl.Location = new System.Drawing.Point(3, 73);
            this.kassa_tabControl.Name = "kassa_tabControl";
            this.kassa_tabControl.SelectedIndex = 0;
            this.kassa_tabControl.Size = new System.Drawing.Size(1200, 567);
            this.kassa_tabControl.TabIndex = 19;
            // 
            // satici_kassasi_tabPage
            // 
            this.satici_kassasi_tabPage.Controls.Add(this.SATİCİ_KASSASİ_KASSA_tableLayoutPanel4);
            this.satici_kassasi_tabPage.Location = new System.Drawing.Point(4, 29);
            this.satici_kassasi_tabPage.Name = "satici_kassasi_tabPage";
            this.satici_kassasi_tabPage.Padding = new System.Windows.Forms.Padding(3);
            this.satici_kassasi_tabPage.Size = new System.Drawing.Size(1192, 534);
            this.satici_kassasi_tabPage.TabIndex = 0;
            this.satici_kassasi_tabPage.Text = "Kassa";
            this.satici_kassasi_tabPage.UseVisualStyleBackColor = true;
            // 
            // SATİCİ_KASSASİ_KASSA_tableLayoutPanel4
            // 
            this.SATİCİ_KASSASİ_KASSA_tableLayoutPanel4.ColumnCount = 1;
            this.SATİCİ_KASSASİ_KASSA_tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.SATİCİ_KASSASİ_KASSA_tableLayoutPanel4.Controls.Add(this.kassa_dgv, 0, 0);
            this.SATİCİ_KASSASİ_KASSA_tableLayoutPanel4.Controls.Add(this.cem_tableLayoutPanel5, 0, 1);
            this.SATİCİ_KASSASİ_KASSA_tableLayoutPanel4.Controls.Add(this.skaner_tableLayoutPanel6, 0, 2);
            this.SATİCİ_KASSASİ_KASSA_tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.SATİCİ_KASSASİ_KASSA_tableLayoutPanel4.Location = new System.Drawing.Point(3, 3);
            this.SATİCİ_KASSASİ_KASSA_tableLayoutPanel4.Name = "SATİCİ_KASSASİ_KASSA_tableLayoutPanel4";
            this.SATİCİ_KASSASİ_KASSA_tableLayoutPanel4.RowCount = 3;
            this.SATİCİ_KASSASİ_KASSA_tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.SATİCİ_KASSASİ_KASSA_tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.SATİCİ_KASSASİ_KASSA_tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.SATİCİ_KASSASİ_KASSA_tableLayoutPanel4.Size = new System.Drawing.Size(1186, 528);
            this.SATİCİ_KASSASİ_KASSA_tableLayoutPanel4.TabIndex = 28;
            // 
            // kassa_dgv
            // 
            this.kassa_dgv.AllowUserToAddRows = false;
            this.kassa_dgv.AllowUserToDeleteRows = false;
            this.kassa_dgv.AllowUserToOrderColumns = true;
            this.kassa_dgv.AllowUserToResizeRows = false;
            this.kassa_dgv.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.kassa_dgv.BackgroundColor = System.Drawing.Color.LightSteelBlue;
            this.kassa_dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.kassa_dgv.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.malin_adi,
            this.s_q,
            this.miqdar,
            this.c_s_q,
            this.bar_kod});
            this.kassa_dgv.Dock = System.Windows.Forms.DockStyle.Fill;
            this.kassa_dgv.GridColor = System.Drawing.Color.DarkBlue;
            this.kassa_dgv.Location = new System.Drawing.Point(3, 3);
            this.kassa_dgv.Name = "kassa_dgv";
            this.kassa_dgv.ReadOnly = true;
            this.kassa_dgv.RowHeadersVisible = false;
            this.kassa_dgv.RowHeadersWidth = 40;
            this.kassa_dgv.Size = new System.Drawing.Size(1180, 372);
            this.kassa_dgv.TabIndex = 23;
            this.kassa_dgv.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.kassa_dgv_CellContentClick);
            this.kassa_dgv.KeyDown += new System.Windows.Forms.KeyEventHandler(this.kassa_dgv_KeyDown);
            // 
            // malin_adi
            // 
            this.malin_adi.HeaderText = "Ad";
            this.malin_adi.Name = "malin_adi";
            this.malin_adi.ReadOnly = true;
            // 
            // s_q
            // 
            this.s_q.HeaderText = "Qiymət";
            this.s_q.Name = "s_q";
            this.s_q.ReadOnly = true;
            // 
            // miqdar
            // 
            this.miqdar.HeaderText = "Miqdar";
            this.miqdar.Name = "miqdar";
            this.miqdar.ReadOnly = true;
            // 
            // c_s_q
            // 
            this.c_s_q.HeaderText = "Cəm Qiymət";
            this.c_s_q.Name = "c_s_q";
            this.c_s_q.ReadOnly = true;
            // 
            // bar_kod
            // 
            this.bar_kod.HeaderText = "Ştrix Kod";
            this.bar_kod.Name = "bar_kod";
            this.bar_kod.ReadOnly = true;
            // 
            // cem_tableLayoutPanel5
            // 
            this.cem_tableLayoutPanel5.ColumnCount = 2;
            this.cem_tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 300F));
            this.cem_tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.cem_tableLayoutPanel5.Controls.Add(this.cem_passiv_label4, 0, 0);
            this.cem_tableLayoutPanel5.Controls.Add(this.cem_mebleg_aktiv_label, 1, 0);
            this.cem_tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cem_tableLayoutPanel5.Location = new System.Drawing.Point(3, 381);
            this.cem_tableLayoutPanel5.Name = "cem_tableLayoutPanel5";
            this.cem_tableLayoutPanel5.RowCount = 1;
            this.cem_tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.cem_tableLayoutPanel5.Size = new System.Drawing.Size(1180, 94);
            this.cem_tableLayoutPanel5.TabIndex = 24;
            // 
            // cem_passiv_label4
            // 
            this.cem_passiv_label4.AutoSize = true;
            this.cem_passiv_label4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cem_passiv_label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cem_passiv_label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.cem_passiv_label4.Location = new System.Drawing.Point(3, 0);
            this.cem_passiv_label4.Name = "cem_passiv_label4";
            this.cem_passiv_label4.Size = new System.Drawing.Size(294, 94);
            this.cem_passiv_label4.TabIndex = 23;
            this.cem_passiv_label4.Text = " Cəm məbləğ AZN:";
            this.cem_passiv_label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // cem_mebleg_aktiv_label
            // 
            this.cem_mebleg_aktiv_label.AutoSize = true;
            this.cem_mebleg_aktiv_label.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cem_mebleg_aktiv_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 40F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cem_mebleg_aktiv_label.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.cem_mebleg_aktiv_label.Location = new System.Drawing.Point(303, 0);
            this.cem_mebleg_aktiv_label.Name = "cem_mebleg_aktiv_label";
            this.cem_mebleg_aktiv_label.Size = new System.Drawing.Size(874, 94);
            this.cem_mebleg_aktiv_label.TabIndex = 22;
            this.cem_mebleg_aktiv_label.Text = "0";
            this.cem_mebleg_aktiv_label.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // skaner_tableLayoutPanel6
            // 
            this.skaner_tableLayoutPanel6.ColumnCount = 8;
            this.skaner_tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 300F));
            this.skaner_tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.skaner_tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
            this.skaner_tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.skaner_tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 180F));
            this.skaner_tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.skaner_tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.skaner_tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.skaner_tableLayoutPanel6.Controls.Add(this.skaner_textbox, 0, 0);
            this.skaner_tableLayoutPanel6.Controls.Add(this.qaliq_label_passiv_label1, 1, 0);
            this.skaner_tableLayoutPanel6.Controls.Add(this.qaliq_pul_aktiv_label, 2, 0);
            this.skaner_tableLayoutPanel6.Controls.Add(this.borca_yaz_alishi_button1, 3, 0);
            this.skaner_tableLayoutPanel6.Controls.Add(this.borc_yazilan_musteri_label1, 4, 0);
            this.skaner_tableLayoutPanel6.Controls.Add(this.label1, 5, 0);
            this.skaner_tableLayoutPanel6.Controls.Add(this.kassa_endirim_faizi_label2, 6, 0);
            this.skaner_tableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.skaner_tableLayoutPanel6.Location = new System.Drawing.Point(3, 481);
            this.skaner_tableLayoutPanel6.Name = "skaner_tableLayoutPanel6";
            this.skaner_tableLayoutPanel6.RowCount = 1;
            this.skaner_tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.skaner_tableLayoutPanel6.Size = new System.Drawing.Size(1180, 44);
            this.skaner_tableLayoutPanel6.TabIndex = 25;
            // 
            // skaner_textbox
            // 
            this.skaner_textbox.BackColor = System.Drawing.Color.Silver;
            this.skaner_textbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.skaner_textbox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.skaner_textbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.skaner_textbox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.skaner_textbox.Location = new System.Drawing.Point(3, 3);
            this.skaner_textbox.Name = "skaner_textbox";
            this.skaner_textbox.Size = new System.Drawing.Size(294, 32);
            this.skaner_textbox.TabIndex = 0;
            this.skaner_textbox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.skaner_textbox_KeyDown);
            this.skaner_textbox.KeyUp += new System.Windows.Forms.KeyEventHandler(this.skaner_textbox_KeyUp);
            // 
            // qaliq_label_passiv_label1
            // 
            this.qaliq_label_passiv_label1.AutoSize = true;
            this.qaliq_label_passiv_label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.qaliq_label_passiv_label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.qaliq_label_passiv_label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.qaliq_label_passiv_label1.Location = new System.Drawing.Point(303, 0);
            this.qaliq_label_passiv_label1.Name = "qaliq_label_passiv_label1";
            this.qaliq_label_passiv_label1.Size = new System.Drawing.Size(114, 44);
            this.qaliq_label_passiv_label1.TabIndex = 25;
            this.qaliq_label_passiv_label1.Text = "Qalıq:";
            this.qaliq_label_passiv_label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // qaliq_pul_aktiv_label
            // 
            this.qaliq_pul_aktiv_label.AutoSize = true;
            this.qaliq_pul_aktiv_label.Dock = System.Windows.Forms.DockStyle.Fill;
            this.qaliq_pul_aktiv_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.qaliq_pul_aktiv_label.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.qaliq_pul_aktiv_label.Location = new System.Drawing.Point(423, 0);
            this.qaliq_pul_aktiv_label.Name = "qaliq_pul_aktiv_label";
            this.qaliq_pul_aktiv_label.Size = new System.Drawing.Size(134, 44);
            this.qaliq_pul_aktiv_label.TabIndex = 26;
            this.qaliq_pul_aktiv_label.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // borca_yaz_alishi_button1
            // 
            this.borca_yaz_alishi_button1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.borca_yaz_alishi_button1.Location = new System.Drawing.Point(563, 3);
            this.borca_yaz_alishi_button1.Name = "borca_yaz_alishi_button1";
            this.borca_yaz_alishi_button1.Size = new System.Drawing.Size(94, 38);
            this.borca_yaz_alishi_button1.TabIndex = 27;
            this.borca_yaz_alishi_button1.Text = "Nisyə";
            this.borca_yaz_alishi_button1.UseVisualStyleBackColor = true;
            this.borca_yaz_alishi_button1.Click += new System.EventHandler(this.borca_yaz_alishi_button1_Click);
            // 
            // borc_yazilan_musteri_label1
            // 
            this.borc_yazilan_musteri_label1.AutoSize = true;
            this.borc_yazilan_musteri_label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.borc_yazilan_musteri_label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.borc_yazilan_musteri_label1.Location = new System.Drawing.Point(663, 0);
            this.borc_yazilan_musteri_label1.Name = "borc_yazilan_musteri_label1";
            this.borc_yazilan_musteri_label1.Size = new System.Drawing.Size(174, 44);
            this.borc_yazilan_musteri_label1.TabIndex = 28;
            this.borc_yazilan_musteri_label1.Text = ":::";
            this.borc_yazilan_musteri_label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(843, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 44);
            this.label1.TabIndex = 29;
            this.label1.Text = "Endirim faizi:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // kassa_endirim_faizi_label2
            // 
            this.kassa_endirim_faizi_label2.AutoSize = true;
            this.kassa_endirim_faizi_label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.kassa_endirim_faizi_label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 17F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kassa_endirim_faizi_label2.ForeColor = System.Drawing.Color.Red;
            this.kassa_endirim_faizi_label2.Location = new System.Drawing.Point(943, 0);
            this.kassa_endirim_faizi_label2.Name = "kassa_endirim_faizi_label2";
            this.kassa_endirim_faizi_label2.Size = new System.Drawing.Size(94, 44);
            this.kassa_endirim_faizi_label2.TabIndex = 30;
            this.kassa_endirim_faizi_label2.Text = "0";
            this.kassa_endirim_faizi_label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // mallar_axtarisi_tabPage
            // 
            this.mallar_axtarisi_tabPage.Controls.Add(this.SATİCİ_KASSASİ_MALLAR_tableLayoutPanel3);
            this.mallar_axtarisi_tabPage.Location = new System.Drawing.Point(4, 29);
            this.mallar_axtarisi_tabPage.Name = "mallar_axtarisi_tabPage";
            this.mallar_axtarisi_tabPage.Padding = new System.Windows.Forms.Padding(3);
            this.mallar_axtarisi_tabPage.Size = new System.Drawing.Size(1192, 534);
            this.mallar_axtarisi_tabPage.TabIndex = 1;
            this.mallar_axtarisi_tabPage.Text = "Mallar";
            this.mallar_axtarisi_tabPage.UseVisualStyleBackColor = true;
            // 
            // SATİCİ_KASSASİ_MALLAR_tableLayoutPanel3
            // 
            this.SATİCİ_KASSASİ_MALLAR_tableLayoutPanel3.ColumnCount = 1;
            this.SATİCİ_KASSASİ_MALLAR_tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.SATİCİ_KASSASİ_MALLAR_tableLayoutPanel3.Controls.Add(this.mallar_dgv_kassa, 0, 0);
            this.SATİCİ_KASSASİ_MALLAR_tableLayoutPanel3.Controls.Add(this.malSiyahisiText, 0, 1);
            this.SATİCİ_KASSASİ_MALLAR_tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.SATİCİ_KASSASİ_MALLAR_tableLayoutPanel3.Location = new System.Drawing.Point(3, 3);
            this.SATİCİ_KASSASİ_MALLAR_tableLayoutPanel3.Name = "SATİCİ_KASSASİ_MALLAR_tableLayoutPanel3";
            this.SATİCİ_KASSASİ_MALLAR_tableLayoutPanel3.RowCount = 2;
            this.SATİCİ_KASSASİ_MALLAR_tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.SATİCİ_KASSASİ_MALLAR_tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.SATİCİ_KASSASİ_MALLAR_tableLayoutPanel3.Size = new System.Drawing.Size(1186, 528);
            this.SATİCİ_KASSASİ_MALLAR_tableLayoutPanel3.TabIndex = 2;
            // 
            // mallar_dgv_kassa
            // 
            this.mallar_dgv_kassa.AllowUserToAddRows = false;
            this.mallar_dgv_kassa.AllowUserToDeleteRows = false;
            this.mallar_dgv_kassa.AllowUserToResizeRows = false;
            this.mallar_dgv_kassa.BackgroundColor = System.Drawing.Color.Gainsboro;
            this.mallar_dgv_kassa.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.mallar_dgv_kassa.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mallar_dgv_kassa.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.mallar_dgv_kassa.Location = new System.Drawing.Point(3, 3);
            this.mallar_dgv_kassa.MultiSelect = false;
            this.mallar_dgv_kassa.Name = "mallar_dgv_kassa";
            this.mallar_dgv_kassa.ReadOnly = true;
            this.mallar_dgv_kassa.RowHeadersVisible = false;
            this.mallar_dgv_kassa.Size = new System.Drawing.Size(1180, 472);
            this.mallar_dgv_kassa.TabIndex = 0;
            this.mallar_dgv_kassa.KeyDown += new System.Windows.Forms.KeyEventHandler(this.mallar_dgv_kassa_KeyDown);
            this.mallar_dgv_kassa.KeyUp += new System.Windows.Forms.KeyEventHandler(this.mallar_dgv_kassa_KeyUp);
            this.mallar_dgv_kassa.MouseClick += new System.Windows.Forms.MouseEventHandler(this.mallar_dgv_kassa_MouseClick);
            this.mallar_dgv_kassa.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.mallar_dgv_kassa_MouseDoubleClick);
            // 
            // malSiyahisiText
            // 
            this.malSiyahisiText.Dock = System.Windows.Forms.DockStyle.Fill;
            this.malSiyahisiText.Enabled = false;
            this.malSiyahisiText.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.malSiyahisiText.Location = new System.Drawing.Point(3, 481);
            this.malSiyahisiText.Name = "malSiyahisiText";
            this.malSiyahisiText.ReadOnly = true;
            this.malSiyahisiText.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.malSiyahisiText.Size = new System.Drawing.Size(1180, 32);
            this.malSiyahisiText.TabIndex = 1;
            // 
            // kassa_borclular_tabPage
            // 
            this.kassa_borclular_tabPage.Controls.Add(this.SATİCİ_KASSASİ_BORCLULAR_tableLayoutPanel3);
            this.kassa_borclular_tabPage.Location = new System.Drawing.Point(4, 29);
            this.kassa_borclular_tabPage.Name = "kassa_borclular_tabPage";
            this.kassa_borclular_tabPage.Size = new System.Drawing.Size(1192, 534);
            this.kassa_borclular_tabPage.TabIndex = 5;
            this.kassa_borclular_tabPage.Text = "Borclular";
            this.kassa_borclular_tabPage.UseVisualStyleBackColor = true;
            // 
            // SATİCİ_KASSASİ_BORCLULAR_tableLayoutPanel3
            // 
            this.SATİCİ_KASSASİ_BORCLULAR_tableLayoutPanel3.ColumnCount = 1;
            this.SATİCİ_KASSASİ_BORCLULAR_tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.SATİCİ_KASSASİ_BORCLULAR_tableLayoutPanel3.Controls.Add(this.borclular_dgv_kassa, 0, 0);
            this.SATİCİ_KASSASİ_BORCLULAR_tableLayoutPanel3.Controls.Add(this.borclular_axtar_tableLayoutPanel4, 0, 1);
            this.SATİCİ_KASSASİ_BORCLULAR_tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.SATİCİ_KASSASİ_BORCLULAR_tableLayoutPanel3.Location = new System.Drawing.Point(0, 0);
            this.SATİCİ_KASSASİ_BORCLULAR_tableLayoutPanel3.Name = "SATİCİ_KASSASİ_BORCLULAR_tableLayoutPanel3";
            this.SATİCİ_KASSASİ_BORCLULAR_tableLayoutPanel3.RowCount = 2;
            this.SATİCİ_KASSASİ_BORCLULAR_tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.SATİCİ_KASSASİ_BORCLULAR_tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.SATİCİ_KASSASİ_BORCLULAR_tableLayoutPanel3.Size = new System.Drawing.Size(1192, 534);
            this.SATİCİ_KASSASİ_BORCLULAR_tableLayoutPanel3.TabIndex = 6;
            // 
            // borclular_dgv_kassa
            // 
            this.borclular_dgv_kassa.AllowUserToAddRows = false;
            this.borclular_dgv_kassa.AllowUserToDeleteRows = false;
            this.borclular_dgv_kassa.AllowUserToOrderColumns = true;
            this.borclular_dgv_kassa.AllowUserToResizeRows = false;
            this.borclular_dgv_kassa.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.borclular_dgv_kassa.BackgroundColor = System.Drawing.Color.Gainsboro;
            this.borclular_dgv_kassa.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.borclular_dgv_kassa.Dock = System.Windows.Forms.DockStyle.Fill;
            this.borclular_dgv_kassa.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.borclular_dgv_kassa.Location = new System.Drawing.Point(3, 3);
            this.borclular_dgv_kassa.MultiSelect = false;
            this.borclular_dgv_kassa.Name = "borclular_dgv_kassa";
            this.borclular_dgv_kassa.ReadOnly = true;
            this.borclular_dgv_kassa.RowHeadersVisible = false;
            this.borclular_dgv_kassa.Size = new System.Drawing.Size(1186, 478);
            this.borclular_dgv_kassa.TabIndex = 2;
            this.borclular_dgv_kassa.KeyDown += new System.Windows.Forms.KeyEventHandler(this.borclular_dgv_kassa_KeyDown);
            this.borclular_dgv_kassa.KeyUp += new System.Windows.Forms.KeyEventHandler(this.borclular_dgv_kassa_KeyUp);
            this.borclular_dgv_kassa.MouseClick += new System.Windows.Forms.MouseEventHandler(this.borclular_dgv_kassa_MouseClick);
            this.borclular_dgv_kassa.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.borclular_dgv_kassa_MouseDoubleClick);
            // 
            // borclular_axtar_tableLayoutPanel4
            // 
            this.borclular_axtar_tableLayoutPanel4.ColumnCount = 4;
            this.borclular_axtar_tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 300F));
            this.borclular_axtar_tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 200F));
            this.borclular_axtar_tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 200F));
            this.borclular_axtar_tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.borclular_axtar_tableLayoutPanel4.Controls.Add(this.kassa_borclular_axtar_textBox, 0, 0);
            this.borclular_axtar_tableLayoutPanel4.Controls.Add(this.kassa_borclular_umumi_borc_aktiv_label4, 2, 0);
            this.borclular_axtar_tableLayoutPanel4.Controls.Add(this.borc_passiv_label2, 1, 0);
            this.borclular_axtar_tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.borclular_axtar_tableLayoutPanel4.Location = new System.Drawing.Point(3, 487);
            this.borclular_axtar_tableLayoutPanel4.Name = "borclular_axtar_tableLayoutPanel4";
            this.borclular_axtar_tableLayoutPanel4.RowCount = 1;
            this.borclular_axtar_tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.borclular_axtar_tableLayoutPanel4.Size = new System.Drawing.Size(1186, 44);
            this.borclular_axtar_tableLayoutPanel4.TabIndex = 3;
            // 
            // kassa_borclular_axtar_textBox
            // 
            this.kassa_borclular_axtar_textBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.kassa_borclular_axtar_textBox.Enabled = false;
            this.kassa_borclular_axtar_textBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kassa_borclular_axtar_textBox.Location = new System.Drawing.Point(3, 3);
            this.kassa_borclular_axtar_textBox.Name = "kassa_borclular_axtar_textBox";
            this.kassa_borclular_axtar_textBox.ReadOnly = true;
            this.kassa_borclular_axtar_textBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.kassa_borclular_axtar_textBox.Size = new System.Drawing.Size(294, 32);
            this.kassa_borclular_axtar_textBox.TabIndex = 3;
            // 
            // kassa_borclular_umumi_borc_aktiv_label4
            // 
            this.kassa_borclular_umumi_borc_aktiv_label4.AutoSize = true;
            this.kassa_borclular_umumi_borc_aktiv_label4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.kassa_borclular_umumi_borc_aktiv_label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kassa_borclular_umumi_borc_aktiv_label4.ForeColor = System.Drawing.Color.Red;
            this.kassa_borclular_umumi_borc_aktiv_label4.Location = new System.Drawing.Point(503, 0);
            this.kassa_borclular_umumi_borc_aktiv_label4.Name = "kassa_borclular_umumi_borc_aktiv_label4";
            this.kassa_borclular_umumi_borc_aktiv_label4.Size = new System.Drawing.Size(194, 44);
            this.kassa_borclular_umumi_borc_aktiv_label4.TabIndex = 5;
            this.kassa_borclular_umumi_borc_aktiv_label4.Text = ":::";
            this.kassa_borclular_umumi_borc_aktiv_label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // borc_passiv_label2
            // 
            this.borc_passiv_label2.AutoSize = true;
            this.borc_passiv_label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.borc_passiv_label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.borc_passiv_label2.ForeColor = System.Drawing.Color.Red;
            this.borc_passiv_label2.Location = new System.Drawing.Point(303, 0);
            this.borc_passiv_label2.Name = "borc_passiv_label2";
            this.borc_passiv_label2.Size = new System.Drawing.Size(194, 44);
            this.borc_passiv_label2.TabIndex = 4;
            this.borc_passiv_label2.Text = "ÜMUMİ BORC:";
            this.borc_passiv_label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // basliq_tableLayoutPanel2
            // 
            this.basliq_tableLayoutPanel2.ColumnCount = 3;
            this.basliq_tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 400F));
            this.basliq_tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 300F));
            this.basliq_tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.basliq_tableLayoutPanel2.Controls.Add(this.kassa_label, 1, 0);
            this.basliq_tableLayoutPanel2.Controls.Add(this.marketin_adi_label, 0, 0);
            this.basliq_tableLayoutPanel2.Controls.Add(this.kassa_alis_satis_rejimi_label4, 2, 0);
            this.basliq_tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.basliq_tableLayoutPanel2.Location = new System.Drawing.Point(3, 3);
            this.basliq_tableLayoutPanel2.Name = "basliq_tableLayoutPanel2";
            this.basliq_tableLayoutPanel2.RowCount = 1;
            this.basliq_tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.basliq_tableLayoutPanel2.Size = new System.Drawing.Size(1200, 64);
            this.basliq_tableLayoutPanel2.TabIndex = 20;
            // 
            // kassa_label
            // 
            this.kassa_label.AutoSize = true;
            this.kassa_label.Dock = System.Windows.Forms.DockStyle.Fill;
            this.kassa_label.Font = new System.Drawing.Font("Times New Roman", 22F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kassa_label.ForeColor = System.Drawing.Color.Navy;
            this.kassa_label.Location = new System.Drawing.Point(403, 0);
            this.kassa_label.Name = "kassa_label";
            this.kassa_label.Size = new System.Drawing.Size(294, 64);
            this.kassa_label.TabIndex = 15;
            this.kassa_label.Text = "KASSA";
            this.kassa_label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // marketin_adi_label
            // 
            this.marketin_adi_label.AutoSize = true;
            this.marketin_adi_label.Dock = System.Windows.Forms.DockStyle.Fill;
            this.marketin_adi_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.marketin_adi_label.ForeColor = System.Drawing.Color.Maroon;
            this.marketin_adi_label.Location = new System.Drawing.Point(3, 0);
            this.marketin_adi_label.Name = "marketin_adi_label";
            this.marketin_adi_label.Size = new System.Drawing.Size(394, 64);
            this.marketin_adi_label.TabIndex = 20;
            this.marketin_adi_label.Text = ":::";
            this.marketin_adi_label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // kassa_alis_satis_rejimi_label4
            // 
            this.kassa_alis_satis_rejimi_label4.AutoSize = true;
            this.kassa_alis_satis_rejimi_label4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.kassa_alis_satis_rejimi_label4.Font = new System.Drawing.Font("Consolas", 40F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kassa_alis_satis_rejimi_label4.ForeColor = System.Drawing.Color.Red;
            this.kassa_alis_satis_rejimi_label4.Location = new System.Drawing.Point(703, 0);
            this.kassa_alis_satis_rejimi_label4.Name = "kassa_alis_satis_rejimi_label4";
            this.kassa_alis_satis_rejimi_label4.Size = new System.Drawing.Size(494, 64);
            this.kassa_alis_satis_rejimi_label4.TabIndex = 21;
            this.kassa_alis_satis_rejimi_label4.Text = "KASSA";
            this.kassa_alis_satis_rejimi_label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // kassa_printDocument1
            // 
            this.kassa_printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.kassa_printDocument1_PrintPage);
            // 
            // Kassa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1206, 643);
            this.Controls.Add(this.satici_kassasi_esas_main_tableLayoutPanel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Kassa";
            this.ShowIcon = false;
            this.Text = "Kassa";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            //this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Kassa_FormClosing);
            this.Load += new System.EventHandler(this.Kassa_Load);
            this.satici_kassasi_esas_main_tableLayoutPanel1.ResumeLayout(false);
            this.kassa_tabControl.ResumeLayout(false);
            this.satici_kassasi_tabPage.ResumeLayout(false);
            this.SATİCİ_KASSASİ_KASSA_tableLayoutPanel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.kassa_dgv)).EndInit();
            this.cem_tableLayoutPanel5.ResumeLayout(false);
            this.cem_tableLayoutPanel5.PerformLayout();
            this.skaner_tableLayoutPanel6.ResumeLayout(false);
            this.skaner_tableLayoutPanel6.PerformLayout();
            this.mallar_axtarisi_tabPage.ResumeLayout(false);
            this.SATİCİ_KASSASİ_MALLAR_tableLayoutPanel3.ResumeLayout(false);
            this.SATİCİ_KASSASİ_MALLAR_tableLayoutPanel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.mallar_dgv_kassa)).EndInit();
            this.kassa_borclular_tabPage.ResumeLayout(false);
            this.SATİCİ_KASSASİ_BORCLULAR_tableLayoutPanel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.borclular_dgv_kassa)).EndInit();
            this.borclular_axtar_tableLayoutPanel4.ResumeLayout(false);
            this.borclular_axtar_tableLayoutPanel4.PerformLayout();
            this.basliq_tableLayoutPanel2.ResumeLayout(false);
            this.basliq_tableLayoutPanel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel satici_kassasi_esas_main_tableLayoutPanel1;
        private System.Windows.Forms.TabControl kassa_tabControl;
        private System.Windows.Forms.TabPage satici_kassasi_tabPage;
        private System.Windows.Forms.TableLayoutPanel SATİCİ_KASSASİ_KASSA_tableLayoutPanel4;
        private System.Windows.Forms.DataGridView kassa_dgv;
        private System.Windows.Forms.DataGridViewTextBoxColumn malin_adi;
        private System.Windows.Forms.DataGridViewTextBoxColumn s_q;
        private System.Windows.Forms.DataGridViewTextBoxColumn miqdar;
        private System.Windows.Forms.DataGridViewTextBoxColumn c_s_q;
        private System.Windows.Forms.DataGridViewTextBoxColumn bar_kod;
        private System.Windows.Forms.TableLayoutPanel cem_tableLayoutPanel5;
        private System.Windows.Forms.Label cem_passiv_label4;
        private System.Windows.Forms.Label cem_mebleg_aktiv_label;
        private System.Windows.Forms.TableLayoutPanel skaner_tableLayoutPanel6;
        private System.Windows.Forms.TextBox skaner_textbox;
        private System.Windows.Forms.Label qaliq_label_passiv_label1;
        private System.Windows.Forms.Label qaliq_pul_aktiv_label;
        private System.Windows.Forms.TabPage mallar_axtarisi_tabPage;
        private System.Windows.Forms.TableLayoutPanel SATİCİ_KASSASİ_MALLAR_tableLayoutPanel3;
        private System.Windows.Forms.DataGridView mallar_dgv_kassa;
        private System.Windows.Forms.TextBox malSiyahisiText;
        private System.Windows.Forms.TabPage kassa_borclular_tabPage;
        private System.Windows.Forms.TableLayoutPanel SATİCİ_KASSASİ_BORCLULAR_tableLayoutPanel3;
        private System.Windows.Forms.DataGridView borclular_dgv_kassa;
        private System.Windows.Forms.TableLayoutPanel borclular_axtar_tableLayoutPanel4;
        private System.Windows.Forms.TextBox kassa_borclular_axtar_textBox;
        private System.Windows.Forms.Label kassa_borclular_umumi_borc_aktiv_label4;
        private System.Windows.Forms.Label borc_passiv_label2;
        private System.Windows.Forms.TableLayoutPanel basliq_tableLayoutPanel2;
        private System.Windows.Forms.Label kassa_label;
        private System.Windows.Forms.Label marketin_adi_label;
        private System.Windows.Forms.Label kassa_alis_satis_rejimi_label4;
        private System.Drawing.Printing.PrintDocument kassa_printDocument1;
        private System.Windows.Forms.Button borca_yaz_alishi_button1;
        private System.Windows.Forms.Label borc_yazilan_musteri_label1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label kassa_endirim_faizi_label2;
    }
}