﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MagazaProqramiDEA
{
    public partial class BorcluSecimiForm : Form
    {
        Kassa kassa;
        public BorcluSecimiForm(Kassa kassa)
        {
            InitializeComponent();
            this.kassa = kassa;
        }

        private void BorcluSecimiForm_Load(object sender, EventArgs e)
        {
            List<string> borclu_musteriler = Baza.cedvelden_melumat_oxumaq_tek_sutun("borclular", "ad", " where aktiv=1   order by ad asc");
            if (borclu_musteriler.Count > 0)
            {
                borclularin_siyahisi_listBox1.Items.Clear();


                foreach (string item in borclu_musteriler)
                {
                    borclularin_siyahisi_listBox1.Items.Add(item);
                } borclularin_siyahisi_listBox1.SelectedIndex = 0;
            }
            else { Baza.msg("Borclular siyahısında heç kim yoxdur.\nYeni borclu qeydiyyatı edin və prosesi davam edin."); }

          
        }

        private void daxil_et_button1_Click(object sender, EventArgs e)
        {

            daxilEtDuymesiBasildi();

           

        }

        private void daxilEtDuymesiBasildi()
        {
            string borclu = "" + borclularin_siyahisi_listBox1.SelectedItem; secilenBorcluAdi = borclu;
            this.kassa.borclununAdiniGoster();

            this.Close();
        }

        public static string secilenBorcluAdi = "";

        private void borclularin_siyahisi_listBox1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            daxilEtDuymesiBasildi();
        }

        private void borclularin_siyahisi_listBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                daxilEtDuymesiBasildi();
            }
        }

    }
}
