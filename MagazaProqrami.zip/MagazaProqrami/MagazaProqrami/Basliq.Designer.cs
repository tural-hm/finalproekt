﻿namespace MagazaProqramiDEA
{
    partial class Basliq
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Basliq));
            this.CompShop = new System.Windows.Forms.TabControl();
            this.esas_tabPage1 = new System.Windows.Forms.TabPage();
            this.esas_tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.loqo_pictureBox1 = new System.Windows.Forms.PictureBox();
            this.istifadeciler_listBox1 = new System.Windows.Forms.ListBox();
            this.info_tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.huquq_label1 = new System.Windows.Forms.Label();
            this.veb_label1 = new System.Windows.Forms.Label();
            this.mail_label2 = new System.Windows.Forms.Label();
            this.mobil_label3 = new System.Windows.Forms.Label();
            this.muellif_yazisi_label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnlogin = new System.Windows.Forms.Button();
            this.txtpas = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.CompShop.SuspendLayout();
            this.esas_tabPage1.SuspendLayout();
            this.esas_tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.loqo_pictureBox1)).BeginInit();
            this.info_tableLayoutPanel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // CompShop
            // 
            this.CompShop.Controls.Add(this.esas_tabPage1);
            this.CompShop.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CompShop.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CompShop.Location = new System.Drawing.Point(0, 0);
            this.CompShop.Name = "CompShop";
            this.CompShop.SelectedIndex = 0;
            this.CompShop.Size = new System.Drawing.Size(1113, 559);
            this.CompShop.TabIndex = 0;
            // 
            // esas_tabPage1
            // 
            this.esas_tabPage1.Controls.Add(this.esas_tableLayoutPanel1);
            this.esas_tabPage1.Location = new System.Drawing.Point(4, 34);
            this.esas_tabPage1.Name = "esas_tabPage1";
            this.esas_tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.esas_tabPage1.Size = new System.Drawing.Size(1105, 521);
            this.esas_tabPage1.TabIndex = 0;
            this.esas_tabPage1.Text = "Mağaza Proqramı ";
            this.esas_tabPage1.UseVisualStyleBackColor = true;
            // 
            // esas_tableLayoutPanel1
            // 
            this.esas_tableLayoutPanel1.BackColor = System.Drawing.Color.DodgerBlue;
            this.esas_tableLayoutPanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("esas_tableLayoutPanel1.BackgroundImage")));
            this.esas_tableLayoutPanel1.ColumnCount = 3;
            this.esas_tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 300F));
            this.esas_tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.esas_tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 300F));
            this.esas_tableLayoutPanel1.Controls.Add(this.loqo_pictureBox1, 2, 0);
            this.esas_tableLayoutPanel1.Controls.Add(this.istifadeciler_listBox1, 0, 0);
            this.esas_tableLayoutPanel1.Controls.Add(this.info_tableLayoutPanel2, 1, 0);
            this.esas_tableLayoutPanel1.Controls.Add(this.label1, 1, 1);
            this.esas_tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.esas_tableLayoutPanel1.Location = new System.Drawing.Point(3, 3);
            this.esas_tableLayoutPanel1.Name = "esas_tableLayoutPanel1";
            this.esas_tableLayoutPanel1.RowCount = 2;
            this.esas_tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 300F));
            this.esas_tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.esas_tableLayoutPanel1.Size = new System.Drawing.Size(1099, 515);
            this.esas_tableLayoutPanel1.TabIndex = 0;
            // 
            // loqo_pictureBox1
            // 
            this.loqo_pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.loqo_pictureBox1.Image = global::MagazaProqramiDEA.Properties.Resources.loqo;
            this.loqo_pictureBox1.Location = new System.Drawing.Point(802, 3);
            this.loqo_pictureBox1.Name = "loqo_pictureBox1";
            this.loqo_pictureBox1.Size = new System.Drawing.Size(294, 294);
            this.loqo_pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.loqo_pictureBox1.TabIndex = 0;
            this.loqo_pictureBox1.TabStop = false;
            // 
            // istifadeciler_listBox1
            // 
            this.istifadeciler_listBox1.BackColor = System.Drawing.Color.PaleTurquoise;
            this.istifadeciler_listBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.istifadeciler_listBox1.ForeColor = System.Drawing.SystemColors.Menu;
            this.istifadeciler_listBox1.FormattingEnabled = true;
            this.istifadeciler_listBox1.ItemHeight = 25;
            this.istifadeciler_listBox1.Items.AddRange(new object[] {
            "Admin"});
            this.istifadeciler_listBox1.Location = new System.Drawing.Point(3, 3);
            this.istifadeciler_listBox1.Name = "istifadeciler_listBox1";
            this.istifadeciler_listBox1.Size = new System.Drawing.Size(294, 294);
            this.istifadeciler_listBox1.TabIndex = 1;
            this.istifadeciler_listBox1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.istifadeciler_listBox1_MouseClick);
            // 
            // info_tableLayoutPanel2
            // 
            this.info_tableLayoutPanel2.BackColor = System.Drawing.Color.Transparent;
            this.info_tableLayoutPanel2.ColumnCount = 1;
            this.info_tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.info_tableLayoutPanel2.Controls.Add(this.huquq_label1, 0, 3);
            this.info_tableLayoutPanel2.Controls.Add(this.veb_label1, 0, 0);
            this.info_tableLayoutPanel2.Controls.Add(this.mail_label2, 0, 1);
            this.info_tableLayoutPanel2.Controls.Add(this.mobil_label3, 0, 2);
            this.info_tableLayoutPanel2.Controls.Add(this.panel1, 0, 5);
            this.info_tableLayoutPanel2.Controls.Add(this.muellif_yazisi_label1, 0, 4);
            this.info_tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.info_tableLayoutPanel2.Location = new System.Drawing.Point(303, 3);
            this.info_tableLayoutPanel2.Name = "info_tableLayoutPanel2";
            this.info_tableLayoutPanel2.RowCount = 6;
            this.info_tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.info_tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.info_tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.info_tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.info_tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.info_tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.info_tableLayoutPanel2.Size = new System.Drawing.Size(493, 294);
            this.info_tableLayoutPanel2.TabIndex = 2;
            // 
            // huquq_label1
            // 
            this.huquq_label1.AutoSize = true;
            this.huquq_label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.huquq_label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.huquq_label1.Location = new System.Drawing.Point(3, 120);
            this.huquq_label1.Name = "huquq_label1";
            this.huquq_label1.Size = new System.Drawing.Size(487, 40);
            this.huquq_label1.TabIndex = 3;
            this.huquq_label1.Text = "Bütün hüquqlar qorunur";
            this.huquq_label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // veb_label1
            // 
            this.veb_label1.AutoSize = true;
            this.veb_label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.veb_label1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.veb_label1.Location = new System.Drawing.Point(3, 0);
            this.veb_label1.Name = "veb_label1";
            this.veb_label1.Size = new System.Drawing.Size(487, 40);
            this.veb_label1.TabIndex = 0;
            this.veb_label1.Text = "Web: Compinter.net";
            this.veb_label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // mail_label2
            // 
            this.mail_label2.AutoSize = true;
            this.mail_label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mail_label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mail_label2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.mail_label2.Location = new System.Drawing.Point(3, 40);
            this.mail_label2.Name = "mail_label2";
            this.mail_label2.Size = new System.Drawing.Size(487, 40);
            this.mail_label2.TabIndex = 1;
            this.mail_label2.Text = "E-mail: support@compinter.net";
            this.mail_label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // mobil_label3
            // 
            this.mobil_label3.AutoSize = true;
            this.mobil_label3.BackColor = System.Drawing.Color.Transparent;
            this.mobil_label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mobil_label3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.mobil_label3.Location = new System.Drawing.Point(3, 80);
            this.mobil_label3.Name = "mobil_label3";
            this.mobil_label3.Size = new System.Drawing.Size(487, 40);
            this.mobil_label3.TabIndex = 2;
            this.mobil_label3.Text = "Mobil: +99451 3490069";
            this.mobil_label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // muellif_yazisi_label1
            // 
            this.muellif_yazisi_label1.AutoSize = true;
            this.muellif_yazisi_label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.muellif_yazisi_label1.ForeColor = System.Drawing.SystemColors.Window;
            this.muellif_yazisi_label1.Location = new System.Drawing.Point(3, 160);
            this.muellif_yazisi_label1.Name = "muellif_yazisi_label1";
            this.muellif_yazisi_label1.Size = new System.Drawing.Size(487, 40);
            this.muellif_yazisi_label1.TabIndex = 4;
            this.muellif_yazisi_label1.Text = "Müəllif : CompNet";
            this.muellif_yazisi_label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.Controls.Add(this.btnlogin);
            this.panel1.Controls.Add(this.txtpas);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Location = new System.Drawing.Point(3, 203);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 3, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(487, 89);
            this.panel1.TabIndex = 4;
            this.panel1.Visible = false;
            // 
            // btnlogin
            // 
            this.btnlogin.Location = new System.Drawing.Point(168, 49);
            this.btnlogin.Name = "btnlogin";
            this.btnlogin.Size = new System.Drawing.Size(100, 36);
            this.btnlogin.TabIndex = 2;
            this.btnlogin.Text = "Daxil ol";
            this.btnlogin.UseVisualStyleBackColor = true;
            this.btnlogin.Click += new System.EventHandler(this.btnlogin_Click);
            // 
            // txtpas
            // 
            this.txtpas.Location = new System.Drawing.Point(110, 11);
            this.txtpas.Name = "txtpas";
            this.txtpas.PasswordChar = '*';
            this.txtpas.Size = new System.Drawing.Size(158, 32);
            this.txtpas.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(14, 14);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(90, 26);
            this.label2.TabIndex = 0;
            this.label2.Text = "Şifrə  .:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(303, 300);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 26);
            this.label1.TabIndex = 3;
            // 
            // Basliq
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1113, 559);
            this.Controls.Add(this.CompShop);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Basliq";
            this.Text = "Mağaza Proqramı (CompNet)";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Basliq_FormClosing);
            this.Load += new System.EventHandler(this.Basliq_Load);
            this.CompShop.ResumeLayout(false);
            this.esas_tabPage1.ResumeLayout(false);
            this.esas_tableLayoutPanel1.ResumeLayout(false);
            this.esas_tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.loqo_pictureBox1)).EndInit();
            this.info_tableLayoutPanel2.ResumeLayout(false);
            this.info_tableLayoutPanel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl CompShop;
        private System.Windows.Forms.TabPage esas_tabPage1;
        private System.Windows.Forms.TableLayoutPanel esas_tableLayoutPanel1;
        private System.Windows.Forms.PictureBox loqo_pictureBox1;
        private System.Windows.Forms.ListBox istifadeciler_listBox1;
        private System.Windows.Forms.TableLayoutPanel info_tableLayoutPanel2;
        private System.Windows.Forms.Label huquq_label1;
        private System.Windows.Forms.Label veb_label1;
        private System.Windows.Forms.Label mail_label2;
        private System.Windows.Forms.Label mobil_label3;
        private System.Windows.Forms.Label muellif_yazisi_label1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnlogin;
        private System.Windows.Forms.TextBox txtpas;
        private System.Windows.Forms.Label label2;
    }
}

